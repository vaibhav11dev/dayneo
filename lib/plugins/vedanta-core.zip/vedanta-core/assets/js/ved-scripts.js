(function ($) {
    "use strict";
    var Progressbar = function ($scope, $) {
        //Ved Advanced Progressbar
        $(".progress-bar").each(function () {
            $(this).appear(function () {
                var spy1 = $(this).attr("aria-valuenow");
                $(this).animate({
                    width: spy1 + "%"
                });
                $(this).parent(".progress").prev(".progress-title").find("span span").countTo({
                    from: 0,
                    to: spy1,
                    speed: 900,
                    refreshInterval: 30
                });
            });
        });
    };

    var Piechart = function ($scope, $) {
        //Ved Piechart
        $(".chart").each(function () {
            $(this).appear(function () {
                $(this).easyPieChart($.extend({
                    barColor: "#222222",
                    trackColor: "#eeeeee",
                    scaleColor: false,
                    lineCap: "square",
                    lineWidth: 3,
                    size: 180
                }, $(this).data("chart-options")));
            });
        });
    };

    var Recentwork = function ($scope, $) {
        //Recent Work	
        var f = $("#filters");
        var $container = $("#works-grid");
        /** @type {string} */
        var layout = "masonry";
        /** @type {string} */
        layout = $container.hasClass("works-grid-masonry") ? "masonry" : "fitRows";
        $("a", f).on("click", function () {
            var selector = $(this).attr("data-filter");
            return $(".current", f).removeClass("current"), $(this).addClass("current"), $container.isotope({
                filter: selector
            }), false;
        }).scroll();
        $(window).on("resize", function () {
            $container.imagesLoaded(function () {
                $container.isotope({
                    layoutMode: layout,
                    itemSelector: ".work-item"
                });
            });
        }).resize();
        $(window).on("resize", function () {
            setTimeout(function () {
                $(".post-masonry").masonry();
            }, 1E3);
        }).resize();
    };
    
    	/*===================================================================================*/
	/*  Deal Countdown timer
	/*===================================================================================*/
    var DealCountdown = function ($scope, $) {
	$( '.deal-countdown-timer' ).each( function() {
		var deal_countdown_text = vedanta_options.deal_countdown_text;

		// set the date we're counting down to
		var deal_time_diff = $(this).children('.deal-time-diff').text();
		var countdown_output = $(this).children('.deal-countdown');
		var target_date = ( new Date().getTime() ) + ( deal_time_diff * 1000 );

		// variables for time units
		var days, hours, minutes, seconds;

		// update the tag with id "countdown" every 1 second
		setInterval( function () {

			// find the amount of "seconds" between now and target
			var current_date = new Date().getTime();
			var seconds_left = (target_date - current_date) / 1000;

			// do some time calculations
			days = parseInt(seconds_left / 86400);
			seconds_left = seconds_left % 86400;

			hours = parseInt(seconds_left / 3600);
			seconds_left = seconds_left % 3600;

			minutes = parseInt(seconds_left / 60);
			seconds = parseInt(seconds_left % 60);

			// format countdown string + set tag value
			countdown_output.html( '<span data-value="' + days + '" class="days"><span class="value">' + days +  '</span><b>' + deal_countdown_text.days_text + '</b></span><span class="hours"><span class="value">' + hours + '</span><b>' + deal_countdown_text.hours_text + '</b></span><span class="minutes"><span class="value">'
			+ minutes + '</span><b>' + deal_countdown_text.mins_text + '</b></span><span class="seconds"><span class="value">' + seconds + '</span><b>' + deal_countdown_text.secs_text + '</b></span>' );

		}, 1000 );
	});
    };

    var Ved_Post_Popup = function ($scope, $) {
        jQuery('.ved-post-columns').magnificPopup({
            delegate: '.grouped_elements', // child items selector, by clicking on it popup will open
            type: 'image',
            gallery: {
                enabled:true
            }
          // other options
        });
    };

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/ved-adv-progressbar.default', Progressbar);
        elementorFrontend.hooks.addAction('frontend/element_ready/ved-piechart.default', Piechart);
        elementorFrontend.hooks.addAction('frontend/element_ready/ved-recent-work.default', Recentwork);
        elementorFrontend.hooks.addAction('frontend/element_ready/ved-post-block.default', Ved_Post_Popup);
        elementorFrontend.hooks.addAction('frontend/element_ready/ved-woo-product-deal.default', DealCountdown);
    });
}(jQuery));