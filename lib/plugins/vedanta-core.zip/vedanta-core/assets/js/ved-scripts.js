(function ($) {
	"use strict";
	var Progressbar = function ($scope, $) {
		//Ved Advanced Progressbar
		$(".progress-bar").each(function () {
			$(this).appear(function () {
				var spy1 = $(this).attr("aria-valuenow");
				$(this).animate({
					width: spy1 + "%"
				});
				$(this).parent(".progress").prev(".progress-title").find("span span").countTo({
					from: 0,
					to: spy1,
					speed: 900,
					refreshInterval: 30
				});
			});
		});
	};

	var Piechart = function ($scope, $) {
		//Ved Piechart
		$(".chart").each(function () {
			$(this).appear(function () {
				$(this).easyPieChart($.extend({
					barColor: "#222222",
					trackColor: "#eeeeee",
					scaleColor: false,
					lineCap: "square",
					lineWidth: 3,
					size: 180
				}, $(this).data("chart-options")));
			});
		});
	};

	var Recentwork = function ($scope, $) {
		//Recent Work	
		var f = $("#filters");
		var $container = $("#works-grid");
		/** @type {string} */
		var layout = "masonry";
		/** @type {string} */
		layout = $container.hasClass("works-grid-masonry") ? "masonry" : "fitRows";
		$("a", f).on("click", function () {
			var selector = $(this).attr("data-filter");
			return $(".current", f).removeClass("current"), $(this).addClass("current"), $container.isotope({
				filter: selector
			}), false;
		}).scroll();
		$(window).on("resize", function () {
			$container.imagesLoaded(function () {
				$container.isotope({
					layoutMode: layout,
					itemSelector: ".work-item"
				});
			});
		}).resize();
		$(window).on("resize", function () {
			setTimeout(function () {
				$(".post-masonry").masonry();
			}, 1E3);
		}).resize();
	};

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/ved-adv-progressbar.default', Progressbar);
		elementorFrontend.hooks.addAction('frontend/element_ready/ved-piechart.default', Piechart);
		elementorFrontend.hooks.addAction('frontend/element_ready/ved-recent-work.default', Recentwork);
	});
}(jQuery));