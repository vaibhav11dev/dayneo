<!--rename this file page_options.php to tab_page_portfolio.php-->
<!--this is actual page portfolio file-->
<div class="ved_metabox">
    <p><b><?php esc_html_e('Note: Portfolio options override all Layout options and work for only portfolio template','vedanta'); ?></b></p>
    <?php
    $types = get_terms('portfolio_category', 'hide_empty=0');
    $types_array[0] = 'All categories';
    if ($types) {
        foreach ($types as $type) {
            $types_array[$type->term_id] = $type->name;
        }
        $this->bigbo_multiple('portfolio_category', esc_html__('Portfolio Type', 'vedanta'), $types_array, esc_html__('Choose what portfolio category you want to display on this page.', 'vedanta')
        );
    }

    $this->bigbo_select('portfolio_filters', esc_html__('Show Portfolio Filters', 'vedanta'), array(
        'yes' => esc_html__('Show', 'vedanta'),
        'no' => esc_html__('Hide', 'vedanta')
            ), ''
    );
    ?>
</div>