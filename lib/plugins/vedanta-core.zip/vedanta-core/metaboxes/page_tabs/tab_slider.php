<div class="ved_metabox">
    <?php
    $this->bigbo_select( 'slider_type', esc_html__( 'Slider Type', 'vedanta' ), array(
	'no'	 => esc_html__( 'No Slider', 'vedanta' ),
	'layer'	 => esc_html__( 'LayerSlider', 'vedanta' ),
	'rev'	 => esc_html__( 'Revolution Slider', 'vedanta' ),
	'flex'	 => esc_html__( 'ThemeVedanta Slider', 'vedanta' ),
    ), ''
    );

    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

    if ( is_plugin_active( 'LayerSlider/layerslider.php' ) ) {
	    global $wpdb;
	    $slides_array[ 0 ]	 = esc_html__( 'Select a slider', 'vedanta' );
	    // Table name
	    $table_name		 = $wpdb->prefix . "layerslider";

	    // Get sliders
	    $sliders = $wpdb->get_results( "SELECT * FROM $table_name
                                                                    WHERE flag_hidden = '0' AND flag_deleted = '0'
                                                                    ORDER BY date_c ASC" );

	    if ( ! empty( $sliders ) ):
		    foreach ( $sliders as $key => $item ):
			    $slides[ $item->id ] = '';
		    endforeach;
	    endif;

	    if ( isset( $slides ) && $slides ) {
		    foreach ( $slides as $key => $val ) {
			    $slides_array[ $key ] = 'LayerSlider #' . ( $key );
		    }
	    }
	    $this->bigbo_select( 'slider', esc_html__( 'Select LayerSlider', 'vedanta' ), $slides_array, ''
	    );
    }

    if ( is_plugin_active( 'revslider/revslider.php' ) ) {
	    global $wpdb;
	    $revsliders[ 0 ] = esc_html__( 'Select a slider', 'vedanta' );
	    if ( function_exists( 'rev_slider_shortcode' ) ) {
		    $get_sliders = $wpdb->get_results( 'SELECT * FROM ' . $wpdb->prefix . 'revslider_sliders' );
		    if ( $get_sliders ) {
			    foreach ( $get_sliders as $slider ) {
				    $revsliders[ $slider->alias ] = $slider->title;
			    }
		    }
	    }
	    $this->bigbo_select( 'revslider', esc_html__( 'Select Revolution Slider', 'vedanta' ), $revsliders, ''
	    );
    }

    $slides_array		 = array();
    $slides			 = array();
    $slides_array[ 0 ]	 = esc_html__( 'Select a slider', 'vedanta' );
    $slides			 = get_terms( 'slide-page' );
    if ( $slides && ! isset( $slides->errors ) ) {
	    $slides = is_array( $slides ) ? $slides : unserialize( $slides );
	    foreach ( $slides as $key => $val ) {
		    $slides_array[ $val->slug ] = $val->name;
	    }
    }
    $this->bigbo_select( 'wooslider', esc_html__( 'Select ThemeVedanta Slider', 'vedanta' ), $slides_array, ''
    );
    ?>
</div>