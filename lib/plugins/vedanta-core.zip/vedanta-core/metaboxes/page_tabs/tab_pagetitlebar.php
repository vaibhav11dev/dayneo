<div class="ved_metabox">
    <?php
   $this->bigbo_select( 'enable_page_title', esc_html__( 'Enable Page Title Bar', 'vedanta' ), array(
	'default'		 => esc_html__( 'Default', 'vedanta' ),
	'on'	 => esc_html__( 'On', 'vedanta' ),
	'off'		 => esc_html__( 'Off', 'vedanta' ),
    ), ''
    );
    
    $this->bigbo_select( 'display_page_title', esc_html__( 'Page Title Bar', 'vedanta' ), array(
	'default'		 => esc_html__( 'Default', 'vedanta' ),
	'titlebar_breadcrumb'	 => esc_html__( 'Title + Breadcrumb', 'vedanta' ),
	'titlebar'		 => esc_html__( 'Only Title', 'vedanta' ),
	'breadcrumb'		 => esc_html__( 'Only Breadcrumb', 'vedanta' ),
    ), ''
    );

    $this->bigbo_text( 'page_title_bar_bg_color', esc_html__( 'Page Title Bar Background Color (Hex Code)', 'vedanta' ), '' );

    $this->bigbo_upload( 'page_title_bar_bg', esc_html__( 'Page Title Bar Background', 'vedanta' ) );

    $this->bigbo_select( 'page_title_bar_height', esc_html__( 'Page Title Bar Height', 'vedanta' ), array(
	'default'	 => esc_html__( 'Default', 'vedanta' ),
	'medium'	 => esc_html__( 'Medium', 'vedanta' ),
	'small'		 => esc_html__( 'Small', 'vedanta' ),
	'large'		 => esc_html__( 'Large', 'vedanta' ),
	'custom'	 => esc_html__( 'Custom', 'vedanta' ),
    ), ''
    );

    $this->bigbo_text( 'page_title_bar_height_custom', 'Custom Height', "All Height in vh and don't add suffix vh. ex: 70"
    );

    $this->bigbo_select( 'page_title_bar_parallax_bg', esc_html__( 'Parallax Background Image', 'vedanta' ), array(
	'default'	 => esc_html__( 'Default', 'vedanta' ),
	'yes'		 => esc_html__( 'Show', 'vedanta' ),
	'no'		 => esc_html__( 'Hide', 'vedanta' ),
    ), ''
    );
    ?>
</div>
