<div class='ved_metabox'>
    <?php
    $this->bigbo_select( 'po_featured_image', esc_html__( 'Show Featured Image', 'vedanta' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->bigbo_select( 'po_author', esc_html__( 'Show Author', 'vedanta' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->bigbo_select( 'po_sharing', esc_html__( 'Show Sharing Box', 'vedanta' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->bigbo_select( 'po_related_posts', esc_html__( 'Show Related Posts', 'vedanta' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->bigbo_text( 'project_url', esc_html__( 'Project URL', 'vedanta' ), ''
    );

    $this->bigbo_text( 'project_url_text', esc_html__( 'Project URL Text', 'vedanta' ), ''
    );

    $this->bigbo_text( 'link_icon_url', 'Portfolio Link URL', 'Leave blank as post URL'
    );

    $this->bigbo_select( 'link_icon_target', 'Open Link URL In New Window', array( 'no' => 'No', 'yes' => 'Yes' ), ''
    );
    ?>    
</div>