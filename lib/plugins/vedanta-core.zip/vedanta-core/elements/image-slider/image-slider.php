<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_Image_Slider extends Widget_Base {

    public function get_name() {
        return 'ved-image-slider';
    }

    public function get_title() {
        return __( 'Ved Image Slider', 'elementor' );
    }

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {

        /**
         * Image Slider Settings
         */
        $this->start_controls_section(
        'ved_section_image_slider_settings', [
            'label' => esc_html__( 'Image Slider Settings', 'vedanta' )
        ]
        );
        
        $this->add_control(
        'ved_image_slider_type', [
            'label'       => esc_html__( 'Slider Type', 'vedanta' ),
            'type'        => Controls_Manager::SELECT,
            'default'     => 'default',
            'label_block' => false,
            'options'     => [
                'default'   => esc_html__( 'Default', 'vedanta' ),
                'fade'      => esc_html__( 'Fade', 'vedanta' ),
                'backSlide' => esc_html__( 'BackSlide', 'vedanta' ),
                'goDown'    => esc_html__( 'GoDown', 'vedanta' ),
                'fadeUp'    => esc_html__( 'FadeUp', 'vedanta' ),
            ],
        ]
        );
        
        $this->add_control(
        'ved_image_slider_desk_items', [
            'label'   => __( 'Show Desktop Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_image_slider_tab_items', [
            'label'   => __( 'Show Tab Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_image_slider_mob_items', [
            'label'   => __( 'Show Mobile Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_image_slider_autoplay', [
            'label'        => __( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_image_slider_navigation', [
            'label'        => __( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );
        
        $this->add_control(
        'ved_image_slider_pagination', [
            'label'        => __( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        /**
         * Image Slider Slides
         */
        $this->start_controls_section(
        'ved_image_slider_slides', [
            'label' => esc_html__( 'Image Slider Slides', 'vedanta' ),
        ]
        );


        $this->add_control(
        'ved_image_slider_item', [
            'type'        => Controls_Manager::REPEATER,
            'default'     => [
                [ 'ved_image_slider_slide' => Utils::get_placeholder_image_src() ],
                [ 'ved_image_slider_slide' => Utils::get_placeholder_image_src() ],
                [ 'ved_image_slider_slide' => Utils::get_placeholder_image_src() ],
            ],
            'fields'      => [
                [
                    'name'    => 'ved_image_slider_slide',
                    'label'   => esc_html__( 'Slide', 'vedanta' ),
                    'type'    => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name'        => 'ved_image_slider_slide_text',
                    'label'       => esc_html__( 'Slide Text', 'vedanta' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'default'     => ''
                ],
                [
                    'name'         => 'ved_image_slider_enable_slide_link',
                    'label'        => __( 'Enable Slide Link', 'vedanta' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'default'      => 'true',
                    'label_on'     => esc_html__( 'Yes', 'vedanta' ),
                    'label_off'    => esc_html__( 'No', 'vedanta' ),
                    'return_value' => 'true',
                ],
                [
                    'name'          => 'ved_image_slider_slide_link',
                    'label'         => esc_html__( 'Slide Link', 'vedanta' ),
                    'type'          => Controls_Manager::URL,
                    'label_block'   => true,
                    'default'       => [
                        'url'         => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true,
                    'condition'     => [
                        'ved_image_slider_enable_slide_link' => 'true'
                    ]
                ]
            ],
            'title_field' => '{{ved_image_slider_slide_text}}',
        ]
        );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Image Slider Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
        'ved_section_image_slider_style_settings', [
            'label' => esc_html__( 'Image Slider Style', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_responsive_control(
        'ved_image_slider_container_padding', [
            'label'      => esc_html__( 'Padding', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-image-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_image_slider_container_margin', [
            'label'      => esc_html__( 'Margin', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-image-slider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_image_slider_border',
            'label'    => esc_html__( 'Border', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-image-slider',
        ]
        );

        $this->add_control(
        'ved_image_slider_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'vedanta' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [],
            'range'     => [
                'px' => [
                    'max' => 500,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-image-slider' => 'border-radius: {{SIZE}}px;',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'     => 'ved_image_slider_shadow',
            'selector' => '{{WRAPPER}} .ved-image-slider',
        ]
        );

        $this->end_controls_section();

        /**
         * -------------------------------------------
         * Tab Style (Image Slider Navigator Style)
         * -------------------------------------------
         */
        $this->start_controls_section(
        'ved_section_image_slider_custom_nav_settings', [
            'label' => esc_html__( 'Navigator Style', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_image_slider_custom_nav_size', [
            'label'     => esc_html__( 'Icon Size', 'vedanta' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [],
            'range'     => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-image-slider .owl-buttons i' => 'font-size: {{SIZE}}px;',
            ],
        ]
        );

        $this->add_control(
        'ved_image_slider_custom_nav_color', [
            'label'     => esc_html__( 'Icon Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-image-slider .owl-buttons i' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_image_slider_custom_nav_bg_size', [
            'label'     => esc_html__( 'Background Size', 'vedanta' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [],
            'range'     => [
                'px' => [
                    'max' => 80,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-prev' => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
                '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-next' => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
            ],
        ]
        );

        $this->add_control(
        'ved_image_slider_custom_nav_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'vedanta' ),
            'type'      => Controls_Manager::SLIDER,
            'default'   => [],
            'range'     => [
                'px' => [
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-prev' => 'border-radius: {{SIZE}}px;',
                '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-next' => 'border-radius: {{SIZE}}px;',
            ],
        ]
        );

        $this->add_control(
        'ved_image_slider_custom_nav_bg_color', [
            'label'     => esc_html__( 'Background Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-prev' => 'background: {{VALUE}};',
                '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-next' => 'background: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_image_slider_custom_nav_border',
            'label'    => esc_html__( 'Border', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-prev, {{WRAPPER}} .ved-image-slider .owl-buttons .owl-next',
        ]
        );

        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'     => 'ved_image_slider_custom_navl_shadow',
            'selector' => '{{WRAPPER}} .ved-image-slider .owl-buttons .owl-prev, {{WRAPPER}} .ved-image-slider .owl-buttons .owl-next',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings();
        
        // Slider Options
        $type = $settings[ 'ved_image_slider_type' ];
        $desk_items      = $settings[ 'ved_image_slider_desk_items' ];
        $tab_items      = $settings[ 'ved_image_slider_tab_items' ];
        $mob_items      = $settings[ 'ved_image_slider_mob_items' ];
        $autoplay = $settings[ 'ved_image_slider_autoplay' ];
        $navigation     = $settings[ 'ved_image_slider_navigation' ];
        $pagination   = $settings[ 'ved_image_slider_pagination' ];
        
        if ( $type != 'default' ) {
            ?>
            <div id="ved-image-slider-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-image-slider" data-carousel-options='{"transitionStyle": "<?php echo esc_attr( $type ); ?>"}'>
                <?php
            } else {
                ?>
                <div id="ved-image-slider-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-image-slider">
                    <?php
                }
                foreach ( $settings[ 'ved_image_slider_item' ] as $slides ) :
                    if ( 'true' == $slides[ 'ved_image_slider_enable_slide_link' ] ) :
                        $ved_slide_link = $slides[ 'ved_image_slider_slide_link' ][ 'url' ];
                        $target         = $slides[ 'ved_image_slider_slide_link' ][ 'is_external' ] ? 'target="_blank"' : '';
                        $nofollow       = $slides[ 'ved_image_slider_slide_link' ][ 'nofollow' ] ? 'rel="nofollow"' : '';
                        ?>
                        <a href="<?php echo esc_url( $ved_slide_link ); ?>" <?php echo esc_attr( $target ); ?> <?php echo esc_attr( $nofollow ); ?>>
                            <img src="<?php echo esc_url( $slides[ 'ved_image_slider_slide' ][ 'url' ] ); ?>" alt="<?php echo esc_attr( $slides[ 'ved_image_slider_slide_text' ] ); ?>">
                        </a>
                        <?php
                    endif;
                endforeach;
                ?>
            </div>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    $("#ved-image-slider-<?php echo esc_attr( $this->get_id() ); ?>.ved-image-slider").each(function () {
                        $(this).owlCarousel($.extend({
                            autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                            navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                            pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                            items: <?php echo $desk_items; ?>,
                            itemsDesktop: [1200, <?php echo $desk_items; ?>],
                            itemsTablet: [1199, <?php echo $tab_items; ?>],
                            itemsMobile: [480, <?php echo $mob_items; ?>],
                            navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']
                        }, $(this).data("carousel-options")));
                    });
                });
            </script>
            <?php
        }

        protected function content_template() {
            
        }

    }

    Plugin::instance()->widgets_manager->register_widget_type( new Widget_Image_Slider() );
    