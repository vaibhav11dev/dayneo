<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_ved_Adv_Tabs extends Widget_Base {

	public function get_name() {
		return 'ved-adv-tabs';
	}

	public function get_title() {
		return esc_html__( 'Ved Advanced Tabs', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-tabs';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {
		/**
		 * Advance Tabs Settings
		 */
		$this->start_controls_section(
		'ved_section_adv_tabs_settings', [
			'label' => esc_html__( 'General Settings', 'vedanta' )
		]
		);
		$this->add_control(
		'ved_adv_tab_layout', [
			'label'		 => esc_html__( 'Layout', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'ved-tabs-horizontal',
			'label_block'	 => false,
			'options'	 => [
				'ved-tabs-horizontal'	 => esc_html__( 'Horizontal', 'vedanta' ),
				'ved-tabs-vertical'	 => esc_html__( 'Vertical', 'vedanta' ),
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_icon_show', [
			'label'		 => esc_html__( 'Enable Icon', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'no',
			'return_value'	 => 'yes',
		]
		);
		$this->add_control(
		'ved_adv_tab_icon_position', [
			'label'		 => esc_html__( 'Icon Position', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'ved-tab-inline-icon',
			'label_block'	 => false,
			'options'	 => [
				'ved-tab-top-icon'	 => esc_html__( 'Stacked', 'vedanta' ),
				'ved-tab-inline-icon'	 => esc_html__( 'Inline', 'vedanta' ),
			],
			'condition'	 => [
				'ved_adv_tabs_icon_show' => 'yes'
			]
		]
		);
		$this->end_controls_section();

		/**
		 * Advance Tabs Content Settings
		 */
		$this->start_controls_section(
		'ved_section_adv_tabs_content_settings', [
			'label' => esc_html__( 'Content', 'vedanta' )
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab', [
			'type'		 => Controls_Manager::REPEATER,
			'seperator'	 => 'before',
			'default'	 => [
					[ 'ved_adv_tabs_tab_title' => esc_html__( 'Tab Title 1', 'vedanta' ) ],
					[ 'ved_adv_tabs_tab_title' => esc_html__( 'Tab Title 2', 'vedanta' ) ],
					[ 'ved_adv_tabs_tab_title' => esc_html__( 'Tab Title 3', 'vedanta' ) ],
			],
			'fields'	 => [
					[
					'name'		 => 'ved_adv_tabs_tab_show_as_default',
					'label'		 => __( 'Set as Default', 'vedanta' ),
					'type'		 => Controls_Manager::SWITCHER,
					'default'	 => 'inactive',
					'return_value'	 => 'active-default',
				],
					[
					'name'		 => 'ved_adv_tabs_icon_type',
					'label'		 => esc_html__( 'Icon Type', 'vedanta' ),
					'type'		 => Controls_Manager::CHOOSE,
					'label_block'	 => false,
					'options'	 => [
						'none'	 => [
							'title'	 => esc_html__( 'None', 'vedanta' ),
							'icon'	 => 'fa fa-ban',
						],
						'icon'	 => [
							'title'	 => esc_html__( 'Icon', 'vedanta' ),
							'icon'	 => 'fa fa-gear',
						],
						'image'	 => [
							'title'	 => esc_html__( 'Image', 'vedanta' ),
							'icon'	 => 'fa fa-picture-o',
						],
					],
					'default'	 => 'icon',
				],
					[
					'name'		 => 'ved_adv_tabs_tab_title_icon',
					'label'		 => esc_html__( 'Icon', 'vedanta' ),
					'type'		 => Controls_Manager::ICON,
					'default'	 => 'fa fa-home',
					'condition'	 => [
						'ved_adv_tabs_icon_type' => 'icon'
					]
				],
					[
					'name'		 => 'ved_adv_tabs_tab_title_image',
					'label'		 => esc_html__( 'Image', 'vedanta' ),
					'type'		 => Controls_Manager::MEDIA,
					'default'	 => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'condition'	 => [
						'ved_adv_tabs_icon_type' => 'image'
					]
				],
					[
					'name'		 => 'ved_adv_tabs_tab_title',
					'label'		 => esc_html__( 'Tab Title', 'vedanta' ),
					'type'		 => Controls_Manager::TEXT,
					'default'	 => esc_html__( 'Tab Title', 'vedanta' ),
					'dynamic'	 => [ 'active' => true ]
				],
					[
					'name'		 => 'ved_adv_tabs_text_type',
					'label'		 => __( 'Content Type', 'vedanta' ),
					'type'		 => Controls_Manager::SELECT,
					'options'	 => [
						'content'	 => __( 'Content', 'vedanta' ),
						'template'	 => __( 'Saved Templates', 'vedanta' ),
					],
					'default'	 => 'content',
				],
					[
					'name'		 => 'ved_primary_templates',
					'label'		 => __( 'Choose Template', 'vedanta' ),
					'type'		 => Controls_Manager::SELECT,
					'options'	 => ved_get_page_templates(),
					'condition'	 => [
						'ved_adv_tabs_text_type' => 'template',
					],
				],
					[
					'name'		 => 'ved_adv_tabs_tab_content',
					'label'		 => esc_html__( 'Tab Content', 'vedanta' ),
					'type'		 => Controls_Manager::WYSIWYG,
					'default'	 => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio, neque qui velit. Magni dolorum quidem ipsam eligendi, totam, facilis laudantium cum accusamus ullam voluptatibus commodi numquam, error, est. Ea, consequatur.', 'vedanta' ),
					'dynamic'	 => [ 'active' => true ],
					'condition'	 => [
						'ved_adv_tabs_text_type' => 'content',
					],
				],
			],
			'title_field'	 => '{{ved_adv_tabs_tab_title}}',
		]
		);
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Advance Tabs Generel Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_tabs_style_settings', [
			'label'	 => esc_html__( 'General', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_tabs_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs',
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_adv_tabs_box_shadow',
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs',
		]
		);
		$this->end_controls_section();
		/**
		 * -------------------------------------------
		 * Tab Style Advance Tabs Content Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_tabs_tab_style_settings', [
			'label'	 => esc_html__( 'Tab Title', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_adv_tabs_tab_title_typography',
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li',
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_title_width', [
			'label'		 => __( 'Title Min Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'size_units'	 => [ 'px', 'em' ],
			'range'		 => [
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
					'step'	 => 1,
				],
				'em'	 => [
					'min'	 => 0,
					'max'	 => 50,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs.ved-tabs-vertical .ved-tabs-nav > ul' => 'min-width: {{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_adv_tab_layout' => 'ved-tabs-vertical'
			]
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_icon_size', [
			'label'		 => __( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 16,
				'unit'	 => 'px',
			],
			'size_units'	 => [ 'px' ],
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 200,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li i'		 => 'font-size: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li img'	 => 'width: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_icon_gap', [
			'label'		 => __( 'Icon Gap', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 10,
				'unit'	 => 'px',
			],
			'size_units'	 => [ 'px' ],
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tab-inline-icon li i, {{WRAPPER}} .ved-tab-inline-icon li img' => 'margin-right: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .ved-tab-top-icon li i, {{WRAPPER}} .ved-tab-top-icon li img'	 => 'margin-bottom: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->start_controls_tabs( 'ved_adv_tabs_header_tabs' );
		// Normal State Tab
		$this->start_controls_tab( 'ved_adv_tabs_header_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );
		$this->add_control(
		'ved_adv_tabs_tab_color', [
			'label'		 => esc_html__( 'Tab Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_icon_color', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li i' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_tabs_icon_show' => 'yes'
			]
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_tabs_tab_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li',
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_tab();
		// Hover State Tab
		$this->start_controls_tab( 'ved_adv_tabs_header_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );
		$this->add_control(
		'ved_adv_tabs_tab_color_hover', [
			'label'		 => esc_html__( 'Tab Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#eee',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:hover' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_text_color_hover', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:hover' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_icon_color_hover', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:hover .fa' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_tabs_icon_show' => 'yes'
			]
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_tabs_tab_border_hover',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:hover',
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_border_radius_hover', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_tab();
		// Active State Tab
		$this->start_controls_tab( 'ved_adv_tabs_header_active', [ 'label' => esc_html__( 'Active', 'vedanta' ) ] );
		$this->add_control(
		'ved_adv_tabs_tab_color_active', [
			'label'		 => esc_html__( 'Tab Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active'		 => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active-default'	 => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_text_color_active', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active'		 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active-default'	 => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_icon_color_active', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active .fa'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active-default .fa' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_tabs_icon_show' => 'yes'
			]
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_tabs_tab_border_active',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active, {{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active-default',
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_tab_border_radius_active', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active'		 => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li.active-default'	 => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Advance Tabs Content Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_tabs_tab_content_style_settings', [
			'label'	 => esc_html__( 'Content', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_control(
		'adv_tabs_content_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'adv_tabs_content_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_adv_tabs_content_typography',
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane',
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_content_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_adv_tabs_content_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_tabs_content_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane',
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_adv_tabs_content_shadow',
			'selector'	 => '{{WRAPPER}} .ved-advance-tabs .ved-tabs-content .ved-tab-pane',
			'separator'	 => 'before'
		]
		);
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Advance Tabs Caret Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_tabs_tab_caret_style_settings', [
			'label'	 => esc_html__( 'Caret', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_caret_show', [
			'label'		 => esc_html__( 'Show Caret on Active Tab', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'no',
			'return_value'	 => 'yes',
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_caret_size', [
			'label'		 => esc_html__( 'Caret Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 10
			],
			'range'		 => [
				'px' => [
					'max' => 100,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:after'			 => 'border-width: {{SIZE}}px; bottom: -{{SIZE}}px',
				'{{WRAPPER}} .ved-advance-tabs.ved-tabs-vertical .ved-tabs-nav > ul li:after'	 => 'right: -{{SIZE}}px; top: calc(50% - {{SIZE}}px) !important;',
			],
			'condition'	 => [
				'ved_adv_tabs_tab_caret_show' => 'yes'
			]
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_caret_color', [
			'label'		 => esc_html__( 'Caret Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-advance-tabs .ved-tabs-nav > ul li:after'			 => 'border-top-color: {{VALUE}};',
				'{{WRAPPER}} .ved-advance-tabs.ved-tabs-vertical .ved-tabs-nav > ul li:after'	 => 'border-top-color: transparent; border-left-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_tabs_tab_caret_show' => 'yes'
			]
		]
		);
		$this->end_controls_section();
	}

	protected function render() {

		$settings		 = $this->get_settings_for_display();
		$ved_find_default_tab	 = array();
		$ved_adv_tab_id		 = 1;
		$ved_adv_tab_content_id	 = 1;
		?>
		<div id="ved-advance-tabs-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-advance-tabs <?php echo esc_attr( $settings[ 'ved_adv_tab_layout' ] ); ?>">
			<div class="ved-tabs-nav">
				<ul class="<?php echo esc_attr( $settings[ 'ved_adv_tab_icon_position' ] ); ?>">
		<?php foreach ( $settings[ 'ved_adv_tabs_tab' ] as $tab ) : ?>
						<li class="<?php echo esc_attr( $tab[ 'ved_adv_tabs_tab_show_as_default' ] ); ?>"><?php if ( $settings[ 'ved_adv_tabs_icon_show' ] === 'yes' ) :
				if ( $tab[ 'ved_adv_tabs_icon_type' ] === 'icon' ) :
					?>
									<i class="<?php echo esc_attr( $tab[ 'ved_adv_tabs_tab_title_icon' ] ); ?>"></i>
				<?php elseif ( $tab[ 'ved_adv_tabs_icon_type' ] === 'image' ) : ?>
									<img src="<?php echo esc_url( $tab[ 'ved_adv_tabs_tab_title_image' ][ 'url' ] ); ?>">
				<?php endif; ?>
			<?php endif; ?> <span class="ved-tab-title"><?php echo esc_html($tab[ 'ved_adv_tabs_tab_title' ]); ?></span></li>
		<?php endforeach; ?>
				</ul>
			</div>
			<div class="ved-tabs-content">
		<?php foreach ( $settings[ 'ved_adv_tabs_tab' ] as $tab ) : $ved_find_default_tab[] = $tab[ 'ved_adv_tabs_tab_show_as_default' ]; ?>
					<div class="ved-tab-pane clearfix <?php echo esc_attr( $tab[ 'ved_adv_tabs_tab_show_as_default' ] ); ?>">
			<?php if ( 'content' == $tab[ 'ved_adv_tabs_text_type' ] ) : ?>
				<?php echo do_shortcode( $tab[ 'ved_adv_tabs_tab_content' ] ); ?>
			<?php elseif ( 'template' == $tab[ 'ved_adv_tabs_text_type' ] ) : ?>
				<?php
				if ( ! empty( $tab[ 'ved_primary_templates' ] ) ) {
					$ved_template_id = $tab[ 'ved_primary_templates' ];
					$ved_frontend	 = new Frontend;
					echo $ved_frontend->get_builder_content( $ved_template_id, true );
				}
				?>
			<?php endif; ?>
					</div>
		<?php endforeach; ?>
			</div>
		</div>
		<script>
			jQuery(document).ready(function ($) {
				$('#ved-advance-tabs-<?php echo esc_attr( $this->get_id() ); ?> .ved-tabs-nav ul li').each(function (index) {
					if ($(this).hasClass('active-default')) {
						$('#ved-advance-tabs-<?php echo esc_attr( $this->get_id() ); ?> .ved-tabs-nav > ul li').removeClass('active').addClass('inactive');
						$(this).removeClass('inactive');
					} else {
						if (index == 0) {
							$(this).removeClass('inactive').addClass('active');

						}
					}

				});
				$('#ved-advance-tabs-<?php echo esc_attr( $this->get_id() ); ?> .ved-tabs-content div').each(function (index) {
					if ($(this).hasClass('active-default')) {
						$('#ved-advance-tabs-<?php echo esc_attr( $this->get_id() ); ?> .ved-tabs-content > div').removeClass('active');
					} else {
						if (index == 0) {
							$(this).removeClass('inactive').addClass('active');
						}
					}

				});
				$('#ved-advance-tabs-<?php echo esc_attr( $this->get_id() ); ?> .ved-tabs-nav ul li').click(function () {

					var currentTabIndex = $(this).index();
					var tabsContainer = $(this).closest('.ved-advance-tabs');
					var tabsNav = $(tabsContainer).children('.ved-tabs-nav').children('ul').children('li');
					var tabsContent = $(tabsContainer).children('.ved-tabs-content').children('div');

					$(this).parent('li').addClass('active');

					$(tabsNav).removeClass('active active-default').addClass('inactive');
					$(this).addClass('active').removeClass('inactive');

					$(tabsContent).removeClass('active').addClass('inactive');
					$(tabsContent).eq(currentTabIndex).addClass('active').removeClass('inactive');

					$(tabsContent).each(function (index) {
						$(this).removeClass('active-default');
					});

				});
			});
		</script>
		<?php
	}

	protected function content_template() {
		
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_ved_Adv_Tabs() );
