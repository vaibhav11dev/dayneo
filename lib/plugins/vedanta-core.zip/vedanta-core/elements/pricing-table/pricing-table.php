<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Ved_Pricing_Table extends Widget_Base {

	public function get_name() {
		return 'ved-pricing-table';
	}

	public function get_title() {
		return esc_html__( 'Ved Pricing Table', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {

		/**
		 * Pricing Table Settings
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_settings', [
			'label' => esc_html__( 'Settings', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_style', [
			'label'		 => esc_html__( 'Pricing Style', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'style-1',
			'label_block'	 => false,
			'options'	 => [
				'style-1'	 => esc_html__( 'Default', 'vedanta' ),
				'style-2'	 => esc_html__( 'Pricing Style 2', 'vedanta' ),
				'style-3'	 => esc_html__( 'Pricing Style 3', 'vedanta' ),
				'style-4'	 => esc_html__( 'Pricing Style 4', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_title', [
			'label'		 => esc_html__( 'Title', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( 'Business', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_sub_title', [
			'label'		 => esc_html__( 'Sub Title', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( 'plan for bussines', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_pricing_table_style_2_icon_enabled', [
			'label'		 => esc_html__( 'List Icon', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'return_value'	 => 'show',
			'default'	 => 'show',
			'condition'	 => [
				'ved_pricing_table_style' => 'style-2'
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_style_2_icon', [
			'label'		 => esc_html__( 'Icon', 'vedanta' ),
			'type'		 => Controls_Manager::ICON,
			'default'	 => 'fa fa-home',
			'condition'	 => [
				'ved_pricing_table_style' => 'style-2'
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_style_4_image', [
			'label'		 => esc_html__( 'Header Image', 'vedanta' ),
			'type'		 => Controls_Manager::MEDIA,
			'default'	 => [
				'url' => Utils::get_placeholder_image_src(),
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-image' => 'background-image: url({{URL}});',
			],
			'condition'	 => [
				'ved_pricing_table_style' => 'style-4'
			]
		]
		);

		$this->end_controls_section();

		/**
		 * Pricing Table Price
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_price', [
			'label' => esc_html__( 'Price', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_price', [
			'label'		 => esc_html__( 'Price', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( '99', 'vedanta' )
		]
		);
		$this->add_control(
		'ved_pricing_table_onsale', [
			'label'		 => __( 'On Sale?', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'no',
			'label_on'	 => __( 'Yes', 'vedanta' ),
			'label_off'	 => __( 'No', 'vedanta' ),
			'return_value'	 => 'yes',
		]
		);
		$this->add_control(
		'ved_pricing_table_onsale_price', [
			'label'		 => esc_html__( 'Sale Price', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( '89', 'vedanta' ),
			'condition'	 => [
				'ved_pricing_table_onsale' => 'yes'
			]
		]
		);
		$this->add_control(
		'ved_pricing_table_price_cur', [
			'label'		 => esc_html__( 'Price Currency', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( '$', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_pricing_table_price_cur_placement', [
			'label'		 => esc_html__( 'Currency Placement', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'left',
			'label_block'	 => false,
			'options'	 => [
				'left'	 => esc_html__( 'Left', 'vedanta' ),
				'right'	 => esc_html__( 'Right', 'vedanta' ),
			],
		]
		);

		/**
		 * Condition: 'ved_pricing_table_style' => 'style-3'
		 */
		$this->add_control(
		'ved_pricing_table_style_3_price_position', [
			'label'		 => esc_html__( 'Pricing Position', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'bottom',
			'label_block'	 => false,
			'options'	 => [
				'top'	 => esc_html__( 'On Top', 'vedanta' ),
				'bottom' => esc_html__( 'At Bottom', 'vedanta' ),
			],
			'condition'	 => [
				'ved_pricing_table_style' => 'style-3'
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_price_period', [
			'label'		 => esc_html__( 'Price Period (per)', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( 'mo', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_period_separator', [
			'label'		 => esc_html__( 'Period Separator', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( '/', 'vedanta' )
		]
		);

		$this->end_controls_section();

		/**
		 * Pricing Table Feature
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_feature', [
			'label' => esc_html__( 'Feature', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_items', [
			'type'		 => Controls_Manager::REPEATER,
			'seperator'	 => 'before',
			'default'	 => [
					[ 'ved_pricing_table_item' => '5GB Disk Space' ],
					[ 'ved_pricing_table_item' => '15 Email Addresses' ],
					[ 'ved_pricing_table_item' => '5 Domains' ],
					[ 'ved_pricing_table_item' => '50 Subdomains' ],
					[ 'ved_pricing_table_item' => 'Email Support' ]
			],
			'fields'	 => [
					[
					'name'		 => 'ved_pricing_table_item',
					'label'		 => esc_html__( 'List Item', 'vedanta' ),
					'type'		 => Controls_Manager::TEXT,
					'label_block'	 => true,
					'default'	 => esc_html__( 'Pricing table list item', 'vedanta' )
				],
					[
					'name'		 => 'ved_pricing_table_list_icon',
					'label'		 => esc_html__( 'List Icon', 'vedanta' ),
					'type'		 => Controls_Manager::ICON,
					'label_block'	 => false,
					'default'	 => '',
				],
					[
					'name'		 => 'ved_pricing_table_icon_mood',
					'label'		 => esc_html__( 'Item Active?', 'vedanta' ),
					'type'		 => Controls_Manager::SWITCHER,
					'return_value'	 => 'yes',
					'default'	 => 'yes',
				],
					[
					'name'		 => 'ved_pricing_table_list_icon_color',
					'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
					'type'		 => Controls_Manager::COLOR,
					'default'	 => '',
				]
			],
			'title_field'	 => '{{ved_pricing_table_item}}',
		]
		);

		$this->end_controls_section();

		/**
		 * Pricing Table Footer
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_footerr', [
			'label' => esc_html__( 'Footer', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_button_icon', [
			'label'	 => esc_html__( 'Button Icon', 'vedanta' ),
			'type'	 => Controls_Manager::ICON,
		]
		);

		$this->add_control(
		'ved_pricing_table_button_icon_alignment', [
			'label'		 => esc_html__( 'Icon Position', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'left',
			'options'	 => [
				'left'	 => esc_html__( 'Before', 'vedanta' ),
				'right'	 => esc_html__( 'After', 'vedanta' ),
			],
			'condition'	 => [
				'ved_pricing_table_button_icon!' => '',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_button_icon_indent', [
			'label'		 => esc_html__( 'Icon Spacing', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'max' => 60,
				],
			],
			'condition'	 => [
				'ved_pricing_table_button_icon!' => '',
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-button i.fa-icon-left'	 => 'margin-right: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing-button i.fa-icon-right'	 => 'margin-left: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_btn', [
			'label'		 => esc_html__( 'Button Text', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => true,
			'default'	 => esc_html__( 'Purchase', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_pricing_table_btn_link', [
			'label'		 => esc_html__( 'Button Link', 'vedanta' ),
			'type'		 => Controls_Manager::URL,
			'label_block'	 => true,
			'default'	 => [
				'url'		 => '#',
				'is_external'	 => '',
			],
			'show_external'	 => true,
		]
		);

		$this->end_controls_section();

		/**
		 * Pricing Table Rebon
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_featured', [
			'label' => esc_html__( 'Ribbon', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_pricing_table_featured', [
			'label'		 => esc_html__( 'Featured?', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'return_value'	 => 'yes',
			'default'	 => 'no',
		]
		);

		$this->add_control(
		'ved_pricing_table_featured_styles', [
			'label'		 => esc_html__( 'Ribbon Style', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'ribbon-1',
			'options'	 => [
				'ribbon-1'	 => esc_html__( 'Style 1', 'vedanta' ),
				'ribbon-2'	 => esc_html__( 'Style 2', 'vedanta' ),
				'ribbon-3'	 => esc_html__( 'Style 3', 'vedanta' ),
			],
			'condition'	 => [
				'ved_pricing_table_featured' => 'yes',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_featured_tag_text', [
			'label'		 => esc_html__( 'Featured Tag Text', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( 'Featured', 'vedanta' ),
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.featured:before'	 => 'content: "{{VALUE}}";',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.featured:before'	 => 'content: "{{VALUE}}";',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.featured:before'	 => 'content: "{{VALUE}}";',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.featured:before'	 => 'content: "{{VALUE}}";',
			],
			'condition'	 => [
				'ved_pricing_table_featured_styles'	 => [ 'ribbon-2', 'ribbon-3' ],
				'ved_pricing_table_featured'		 => 'yes'
			]
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Pricing Table Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_style_settings', [
			'label'	 => esc_html__( 'Pricing Table Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_pricing_table_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-item' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_featured_bg_color', [
			'label'		 => esc_html__( 'Featured Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.featured .ved-pricing-header' => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_style' => 'style-4'
			]
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_container_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_container_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_pricing_table_border',
			'label'		 => esc_html__( 'Border Type', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-pricing .ved-pricing-item',
		]
		);

		$this->add_control(
		'ved_pricing_table_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 2,
			],
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-item' => 'border-radius: {{SIZE}}px;',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_pricing_table_shadow',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-item',
			],
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_icon_margin', [
			'label'		 => esc_html__( 'Icon Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .price-tag:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_content_alignment', [
			'label'		 => esc_html__( 'Content Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'left'	 => [
					'title'	 => esc_html__( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => esc_html__( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => esc_html__( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				],
			],
			'default'	 => 'center',
			'prefix_class'	 => 'ved-pricing-content-align-',
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_content_button_alignment', [
			'label'		 => esc_html__( 'Button Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'left'	 => [
					'title'	 => esc_html__( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => esc_html__( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => esc_html__( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				],
			],
			'default'	 => 'center',
			'prefix_class'	 => 'ved-pricing-button-align-',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Style (Header)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_header_style_settings', [
			'label'	 => esc_html__( 'Header', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_pricing_table_title_heading', [
			'label'	 => esc_html__( 'Title Style', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_pricing_table_title_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .ved-pricing-header .title'				 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item:hover .ved-pricing-header:after'	 => 'background: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_style_2_title_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-header' => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item .ved-pricing-header' => 'background: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_style' => [ 'style-2', 'style-4' ]
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_style_1_title_line_color', [
			'label'		 => esc_html__( 'Line Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#f5f5f5',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item .ved-pricing-header:after' => 'background: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_style' => [ 'style-1' ]
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_style_3_title_line_color', [
			'label'		 => esc_html__( 'Line Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#f5f5f5',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item .ved-pricing-header:after' => 'background: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_style' => [ 'style-3' ]
			]
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_title_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .header .title',
		]
		);

		$this->add_control(
		'ved_pricing_table_subtitle_heading', [
			'label'		 => esc_html__( 'Subtitle Style', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before',
		]
		);

		$this->add_control(
		'ved_pricing_table_subtitle_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .ved-pricing-header .subtitle' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_subtitle_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .header .subtitle',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Style (Pricing)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_title_style_settings', [
			'label'	 => esc_html__( 'Pricing', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_pricing_table_price_tag_onsale_heading', [
			'label'		 => esc_html__( 'Original Price', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before'
		]
		);

		$this->add_control(
		'ved_pricing_table_pricing_onsale_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .muted-price' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_price_tag_onsale_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .muted-price',
		]
		);

		$this->add_control(
		'ved_pricing_table_price_tag_heading', [
			'label'		 => esc_html__( 'Sale Price', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before'
		]
		);

		$this->add_control(
		'ved_pricing_table_pricing_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .price-tag' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_price_tag_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .price-tag',
		]
		);


		$this->add_control(
		'ved_pricing_table_price_currency_heading', [
			'label'		 => esc_html__( 'Currency', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before'
		]
		);

		$this->add_control(
		'ved_pricing_table_pricing_curr_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .price-tag .price-currency' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_price_cur_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .price-currency',
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_price_cur_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .price-currency' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_pricing_period_heading', [
			'label'		 => esc_html__( 'Pricing Period', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before'
		]
		);

		$this->add_control(
		'ved_pricing_table_pricing_period_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .price-period' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_price_preiod_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .price-period',
		]
		);

		$this->end_controls_section();


		/**
		 * -------------------------------------------
		 * Style (Feature List)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_style_featured_list_settings', [
			'label'	 => esc_html__( 'Feature List', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_pricing_table_list_item_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing-item .ved-pricing-body ul li' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_list_item_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing-item .body ul li',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Pricing Table Featured Tag Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_style_3_featured_tag_settings', [
			'label'		 => esc_html__( 'Ribbon', 'vedanta' ),
			'tab'		 => Controls_Manager::TAB_STYLE,
			'condition'	 => [
				'ved_pricing_table_featured' => 'yes'
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_style_1_featured_bar_color', [
			'label'		 => esc_html__( 'Line Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#00C853',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-1:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-1:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-1:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-1:before'	 => 'background: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_featured'		 => 'yes',
				'ved_pricing_table_featured_styles'	 => 'ribbon-1'
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_style_1_featured_bar_height', [
			'label'		 => esc_html__( 'Line Height', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 3
			],
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-1:before'	 => 'height: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-1:before'	 => 'height: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-1:before'	 => 'height: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-1:before'	 => 'height: {{SIZE}}px;',
			],
			'condition'	 => [
				'ved_pricing_table_featured'		 => 'yes',
				'ved_pricing_table_featured_styles'	 => 'ribbon-1'
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_featured_tag_font_size', [
			'label'		 => esc_html__( 'Font Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 10
			],
			'range'		 => [
				'px' => [
					'max' => 18,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-2:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-2:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-2:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-2:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-3:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-3:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-3:before'	 => 'font-size: {{SIZE}}px;',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-3:before'	 => 'font-size: {{SIZE}}px;',
			],
			'condition'	 => [
				'ved_pricing_table_featured'		 => 'yes',
				'ved_pricing_table_featured_styles'	 => [ 'ribbon-2', 'ribbon-3' ]
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_featured_tag_text_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-2:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-2:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-2:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-2:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-3:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-3:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-3:before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-3:before'	 => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_featured'		 => 'yes',
				'ved_pricing_table_featured_styles'	 => [ 'ribbon-2', 'ribbon-3' ]
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_featured_tag_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-2:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-2:after'	 => 'border-bottom-color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-1 .ved-pricing-item.ribbon-3:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-2:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-2:after'	 => 'border-bottom-color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item.ribbon-3:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-2:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-2:after'	 => 'border-bottom-color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-3 .ved-pricing-item.ribbon-3:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-2:before'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-2:after'	 => 'border-bottom-color: {{VALUE}};',
				'{{WRAPPER}} .ved-pricing.style-4 .ved-pricing-item.ribbon-3:before'	 => 'background: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_featured'		 => 'yes',
				'ved_pricing_table_featured_styles'	 => [ 'ribbon-2', 'ribbon-3' ]
			],
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Pricing Table Icon Style)
		 * Condition: 'ved_pricing_table_style' => 'style-2'
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_icon_settings', [
			'label'		 => esc_html__( 'Icon Settings', 'vedanta' ),
			'tab'		 => Controls_Manager::TAB_STYLE,
			'condition'	 => [
				'ved_pricing_table_style' => 'style-2'
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_bg_show', [
			'label'		 => __( 'Show Background', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'yes',
			'label_on'	 => __( 'Show', 'vedanta' ),
			'label_off'	 => __( 'Hide', 'vedanta' ),
			'return_value'	 => 'yes',
		]
		);

		/**
		 * Condition: 'ved_pricing_table_icon_bg_show' => 'yes'
		 */
		$this->add_control(
		'ved_pricing_table_icon_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon' => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_icon_bg_show' => 'yes'
			]
		]
		);

		/**
		 * Condition: 'ved_pricing_table_icon_bg_show' => 'yes'
		 */
		$this->add_control(
		'ved_pricing_table_icon_bg_hover_color', [
			'label'		 => esc_html__( 'Background Hover Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item:hover .ved-pricing-icon .icon' => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_icon_bg_show' => 'yes'
			],
			'separator'	 => 'after',
		]
		);


		$this->add_control(
		'ved_pricing_table_icon_settings', [
			'label'		 => esc_html__( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 30
			],
			'range'		 => [
				'px' => [
					'max' => 100,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon i' => 'font-size: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_area_width', [
			'label'		 => esc_html__( 'Icon Area Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 80
			],
			'range'		 => [
				'px' => [
					'max' => 200,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon' => 'width: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_area_height', [
			'label'		 => esc_html__( 'Icon Area Height', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 80
			],
			'range'		 => [
				'px' => [
					'max' => 200,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon' => 'height: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_line_height', [
			'label'		 => esc_html__( 'Icon Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 80
			],
			'range'		 => [
				'px' => [
					'max' => 300,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon i' => 'line-height: {{SIZE}}px;',
			],
		]
		);



		$this->add_control(
		'ved_pricing_table_icon_color', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon i' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_hover_color', [
			'label'		 => esc_html__( 'Icon Hover Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item:hover .ved-pricing-icon .icon i' => 'color: {{VALUE}};',
			],
			'separator'	 => 'after'
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_pricing_table_icon_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon',
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_border_hover_color', [
			'label'		 => esc_html__( 'Hover Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item:hover .ved-pricing-icon .icon' => 'border-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_pricing_table_icon_border_border!' => ''
			]
		]
		);

		$this->add_control(
		'ved_pricing_table_icon_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 50,
			],
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing.style-2 .ved-pricing-item .ved-pricing-icon .icon' => 'border-radius: {{SIZE}}%;',
			],
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Button Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_pricing_table_btn_style_settings', [
			'label'	 => esc_html__( 'Button', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_btn_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_pricing_table_btn_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_pricing_table_btn_typography',
			'selector'	 => '{{WRAPPER}} .ved-pricing .ved-pricing-button',
		]
		);

		$this->start_controls_tabs( 'ved_cta_button_tabs' );

		// Normal State Tab
		$this->start_controls_tab( 'ved_pricing_table_btn_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );

		$this->add_control(
		'ved_pricing_table_btn_normal_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_btn_normal_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#23b6ac',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button' => 'background: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_pricing_table_btn_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-pricing .ved-pricing-button',
		]
		);

		$this->add_control(
		'ved_pricing_table_btn_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'default'	 => [
				'size' => 25,
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button' => 'border-radius: {{SIZE}}px;',
			],
		]
		);

		$this->end_controls_tab();

		// Hover State Tab
		$this->start_controls_tab( 'ved_pricing_table_btn_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );

		$this->add_control(
		'ved_pricing_table_btn_hover_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button:hover' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_btn_hover_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#23b6ac',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button:hover' => 'background: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_pricing_table_btn_hover_border_color', [
			'label'		 => esc_html__( 'Border Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-pricing .ved-pricing-button:hover' => 'border-color: {{VALUE}};',
			],
		]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_cta_button_shadow',
			'selector'	 => '{{WRAPPER}} .ved-pricing .ved-pricing-button',
			'separator'	 => 'before'
		]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings		 = $this->get_settings();
		$pricing_table_image	 = $this->get_settings( 'ved_pricing_table_image' );
		$pricing_table_image_url = Group_Control_Image_Size::get_attachment_image_src( $pricing_table_image[ 'id' ], 'thumbnail', $settings );
		$target			 = $settings[ 'ved_pricing_table_btn_link' ][ 'is_external' ] ? 'target="_blank"' : '';
		$nofollow		 = $settings[ 'ved_pricing_table_btn_link' ][ 'nofollow' ] ? 'rel="nofollow"' : '';
		if ( 'yes' === $settings[ 'ved_pricing_table_featured' ] ) : $featured_class = 'featured ' . $settings[ 'ved_pricing_table_featured_styles' ];
		else : $featured_class = '';
		endif;

		if ( 'yes' === $settings[ 'ved_pricing_table_onsale' ] ) {
			if ( $settings[ 'ved_pricing_table_price_cur_placement' ] == 'left' ) {
				$pricing = '<del class="muted-price"><span class="muted-price-currency">' . $settings[ 'ved_pricing_table_price_cur' ] . '</span>' . $settings[ 'ved_pricing_table_price' ] . '</del> <span class="price-currency">' . $settings[ 'ved_pricing_table_price_cur' ] . '</span>' . $settings[ 'ved_pricing_table_onsale_price' ];
			} else if ( $settings[ 'ved_pricing_table_price_cur_placement' ] == 'right' ) {
				$pricing = '<del class="muted-price">' . $settings[ 'ved_pricing_table_price' ] . '<span class="muted-price-currency">' . $settings[ 'ved_pricing_table_price_cur' ] . '</span></del> ' . $settings[ 'ved_pricing_table_onsale_price' ] . '<span class="price-currency">' . $settings[ 'ved_pricing_table_price_cur' ] . '</span>';
			}
		} else {
			if ( $settings[ 'ved_pricing_table_price_cur_placement' ] == 'left' ) {
				$pricing = '<span class="price-currency">' . $settings[ 'ved_pricing_table_price_cur' ] . '</span>' . $settings[ 'ved_pricing_table_price' ];
			} else if ( $settings[ 'ved_pricing_table_price_cur_placement' ] == 'right' ) {
				$pricing = $settings[ 'ved_pricing_table_price' ] . '<span class="price-currency">' . $settings[ 'ved_pricing_table_price_cur' ] . '</span>';
			}
		}
		?>
		<?php if ( 'style-1' === $settings[ 'ved_pricing_table_style' ] ) : ?>
			<div class="ved-pricing style-1">
				<div class="ved-pricing-item <?php echo esc_attr( $featured_class ); ?>">
					<div class="ved-pricing-header">
						<h2 class="title"><?php echo esc_html($settings[ 'ved_pricing_table_title' ]); ?></h2>
						<em class="subtitle"><?php echo esc_html($settings[ 'ved_pricing_table_sub_title' ]); ?></em>
					</div>
					<div class="ved-pricing-tag">
						<span class="price-tag"><?php echo esc_html($pricing); ?></span>
						<span class="price-period"><?php echo esc_html($settings[ 'ved_pricing_table_period_separator' ]); ?> <?php echo esc_html($settings[ 'ved_pricing_table_price_period' ]); ?></span>
					</div>
					<div class="ved-pricing-body">
						<ul>
			<?php
			foreach ( $settings[ 'ved_pricing_table_items' ] as $item ) :
				if ( 'yes' === $item[ 'ved_pricing_table_icon_mood' ] ) : $icon_mood = '';
				else : $icon_mood = 'disable-item';
				endif;
				?>
								<li class="<?php echo esc_attr( $icon_mood ); ?>">
				<?php if ( 'show' === $settings[ 'ved_pricing_table_style_2_icon_enabled' ] ) : ?>
										<span class="li-icon" style="color:<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon_color' ] ); ?>"><i class="<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon' ] ); ?>"></i></span>
				<?php endif; ?>
				<?php echo esc_html($item[ 'ved_pricing_table_item' ]); ?>
								</li>
			<?php endforeach; ?>
						</ul>
					</div>
					<div class="ved-pricing-footer">
						<a href="<?php echo esc_url( $settings[ 'ved_pricing_table_btn_link' ][ 'url' ] ); ?>" <?php echo esc_html($target); ?> <?php echo esc_html($nofollow); ?> class="ved-pricing-button">
			<?php if ( 'left' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-left"></i>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
			<?php elseif ( 'right' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-right"></i>
			<?php endif; ?>
						</a>
					</div>
				</div>
			</div>
		<?php elseif ( 'style-2' === $settings[ 'ved_pricing_table_style' ] ) : ?>
			<div class="ved-pricing style-2">
				<div class="ved-pricing-item <?php echo esc_attr( $featured_class ); ?>">
					<div class="ved-pricing-icon">
						<span class="icon" style="background:<?php if ( 'yes' != $settings[ 'ved_pricing_table_icon_bg_show' ] ) : echo 'none';
			endif; ?>;"><i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_style_2_icon' ] ); ?>"></i></span>
					</div>
					<div class="ved-pricing-header">
						<h2 class="title"><?php echo esc_html($settings[ 'ved_pricing_table_title' ]); ?></h2>
						<em class="subtitle"><?php echo esc_html($settings[ 'ved_pricing_table_sub_title' ]); ?></em>
					</div>
					<div class="ved-pricing-tag">
						<span class="price-tag"><?php echo esc_html($pricing); ?></span>
						<span class="price-period"><?php echo esc_html($settings[ 'ved_pricing_table_period_separator' ]); ?> <?php echo esc_html($settings[ 'ved_pricing_table_price_period' ]); ?></span>
					</div>
					<div class="ved-pricing-body">
						<ul>
			<?php
			foreach ( $settings[ 'ved_pricing_table_items' ] as $item ) :
				if ( 'yes' === $item[ 'ved_pricing_table_icon_mood' ] ) : $icon_mood = '';
				else : $icon_mood = 'disable-item';
				endif;
				?>
								<li class="<?php echo esc_attr( $icon_mood ); ?>">
				<?php if ( 'show' === $settings[ 'ved_pricing_table_style_2_icon_enabled' ] ) : ?>
										<span class="li-icon" style="color:<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon_color' ] ); ?>"><i class="<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon' ] ); ?>"></i></span>
				<?php endif; ?>
				<?php echo esc_html($item[ 'ved_pricing_table_item' ]); ?>
								</li>
			<?php endforeach; ?>
						</ul>
					</div>
					<div class="ved-pricing-footer">
						<a href="<?php echo esc_url( $settings[ 'ved_pricing_table_btn_link' ][ 'url' ] ); ?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> class="ved-pricing-button">
			<?php if ( 'left' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-left"></i>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
			<?php elseif ( 'right' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-right"></i>
			<?php endif; ?>
						</a>
					</div>
				</div>
			</div>
		<?php elseif ( 'style-3' === $settings[ 'ved_pricing_table_style' ] ) : ?>
			<div class="ved-pricing style-3">
				<div class="ved-pricing-item <?php echo esc_attr( $featured_class ); ?>">
			<?php if ( 'top' === $settings[ 'ved_pricing_table_style_3_price_position' ] ) : ?>
						<div class="ved-pricing-tag on-top">
							<span class="price-tag"><?php echo esc_html($pricing); ?></span>
							<span class="price-period"><?php echo esc_html($settings[ 'ved_pricing_table_period_separator' ]); ?> <?php echo esc_html($settings[ 'ved_pricing_table_price_period' ]); ?></span>
						</div>
			<?php endif; ?>
					<div class="ved-pricing-header">
						<h2 class="title"><?php echo esc_html($settings[ 'ved_pricing_table_title' ]); ?></h2>
						<em class="subtitle"><?php echo esc_html($settings[ 'ved_pricing_table_sub_title' ]); ?></em>
					</div>
					<div class="ved-pricing-body">
						<ul>
			<?php
			foreach ( $settings[ 'ved_pricing_table_items' ] as $item ) :
				if ( 'yes' === $item[ 'ved_pricing_table_icon_mood' ] ) : $icon_mood = '';
				else : $icon_mood = 'disable-item';
				endif;
				?>
								<li class="<?php echo esc_attr( $icon_mood ); ?>">
				<?php if ( 'show' === $settings[ 'ved_pricing_table_style_2_icon_enabled' ] ) : ?>
										<span class="li-icon" style="color:<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon_color' ] ); ?>"><i class="<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon' ] ); ?>"></i></span>
				<?php endif; ?>
				<?php echo $item[ 'ved_pricing_table_item' ]; ?>
								</li>
			<?php endforeach; ?>
						</ul>
					</div>
							<?php if ( 'bottom' === $settings[ 'ved_pricing_table_style_3_price_position' ] ) : ?>
						<div class="ved-pricing-tag">
							<span class="price-tag"><?php echo esc_html($pricing); ?></span>
							<span class="price-period"><?php echo esc_html($settings[ 'ved_pricing_table_period_separator' ]); ?> <?php echo esc_html($settings[ 'ved_pricing_table_price_period' ]); ?></span>
						</div>
								<?php endif; ?>
					<div class="ved-pricing-footer">
						<a href="<?php echo esc_url( $settings[ 'ved_pricing_table_btn_link' ][ 'url' ] ); ?>" <?php echo esc_html($target); ?> <?php echo esc_html($nofollow); ?> class="ved-pricing-button">
								<?php if ( 'left' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-left"></i>
								<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
			<?php elseif ( 'right' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-right"></i>
							<?php endif; ?>
						</a>
					</div>
				</div>
			</div>
						<?php elseif ( 'style-4' === $settings[ 'ved_pricing_table_style' ] ) : ?>
			<div class="ved-pricing style-4">
				<div class="ved-pricing-item <?php echo esc_attr( $featured_class ); ?>">
					<div class="ved-pricing-image">
						<div class="ved-pricing-tag">
							<span class="price-tag"><?php echo esc_html($pricing); ?></span>
							<span class="price-period"><?php echo esc_html($settings[ 'ved_pricing_table_period_separator' ]); ?> <?php echo esc_html($settings[ 'ved_pricing_table_price_period' ]); ?></span>
						</div>
					</div>
					<div class="ved-pricing-header">
						<h2 class="title"><?php echo esc_html($settings[ 'ved_pricing_table_title' ]); ?></h2>
						<em class="subtitle"><?php echo esc_html($settings[ 'ved_pricing_table_sub_title' ]); ?></em>
					</div>
					<div class="ved-pricing-body">
						<ul>
			<?php
			foreach ( $settings[ 'ved_pricing_table_items' ] as $item ) :
				if ( 'yes' === $item[ 'ved_pricing_table_icon_mood' ] ) : $icon_mood = '';
				else : $icon_mood = 'disable-item';
				endif;
				?>
								<li class="<?php echo esc_attr( $icon_mood ); ?>">
								<?php if ( 'show' === $settings[ 'ved_pricing_table_style_2_icon_enabled' ] ) : ?>
										<span class="li-icon" style="color:<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon_color' ] ); ?>"><i class="<?php echo esc_attr( $item[ 'ved_pricing_table_list_icon' ] ); ?>"></i></span>
								<?php endif; ?>
								<?php echo esc_html($item[ 'ved_pricing_table_item' ]); ?>
								</li>
								<?php endforeach; ?>
						</ul>
					</div>
					<div class="ved-pricing-footer">
						<a href="<?php echo esc_url( $settings[ 'ved_pricing_table_btn_link' ][ 'url' ] ); ?>" <?php echo esc_html($target); ?> <?php echo esc_html($nofollow); ?> class="ved-pricing-button">
							<?php if ( 'left' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-left"></i>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
			<?php elseif ( 'right' == $settings[ 'ved_pricing_table_button_icon_alignment' ] ) : ?>
				<?php echo $settings[ 'ved_pricing_table_btn' ]; ?>
								<i class="<?php echo esc_attr( $settings[ 'ved_pricing_table_button_icon' ] ); ?> fa-icon-right"></i>
							<?php endif; ?>
						</a>
					</div>
				</div>
			</div>
						<?php endif; ?>
						<?php
					}

					protected function content_template() {
						?>


				<?php
			}

		}

		Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Pricing_Table() );
		