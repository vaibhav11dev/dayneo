<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_ved_Tooltip extends Widget_Base {

	public function get_name() {
		return 'ved-tooltip';
	}

	public function get_title() {
		return esc_html__( 'Ved Tooltip', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-alert';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {
		/**
		 * Tooltip Settings
		 */
		$this->start_controls_section(
		'ved_section_tooltip_settings', [
			'label' => esc_html__( 'Content Settings', 'vedanta' )
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_type', [
			'label'		 => esc_html__( 'Content Type', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'icon'		 => [
					'title'	 => esc_html__( 'Icon', 'vedanta' ),
					'icon'	 => 'fa fa-info',
				],
				'text'		 => [
					'title'	 => esc_html__( 'Text', 'vedanta' ),
					'icon'	 => 'fa fa-text-width',
				],
				'image'		 => [
					'title'	 => esc_html__( 'Image', 'vedanta' ),
					'icon'	 => 'fa fa-image',
				],
				'shortcode'	 => [
					'title'	 => esc_html__( 'Shortcode', 'vedanta' ),
					'icon'	 => 'fa fa-code',
				],
			],
			'default'	 => 'text',
		]
		);
		$this->add_control(
		'ved_tooltip_content', [
			'label'		 => esc_html__( 'Content', 'vedanta' ),
			'type'		 => Controls_Manager::WYSIWYG,
			'label_block'	 => true,
			'default'	 => esc_html__( 'Hover Me!', 'vedanta' ),
			'condition'	 => [
				'ved_tooltip_type' => [ 'text' ]
			],
			'dynamic'	 => [ 'active' => true ]
		]
		);
		$this->add_control(
		'ved_tooltip_content_tag', [
			'label'		 => esc_html__( 'Content Tag', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'span',
			'label_block'	 => false,
			'options'	 => [
				'h1'	 => esc_html__( 'H1', 'vedanta' ),
				'h2'	 => esc_html__( 'H2', 'vedanta' ),
				'h3'	 => esc_html__( 'H3', 'vedanta' ),
				'h4'	 => esc_html__( 'H4', 'vedanta' ),
				'h5'	 => esc_html__( 'H5', 'vedanta' ),
				'h6'	 => esc_html__( 'H6', 'vedanta' ),
				'div'	 => esc_html__( 'DIV', 'vedanta' ),
				'span'	 => esc_html__( 'SPAN', 'vedanta' ),
				'p'	 => esc_html__( 'P', 'vedanta' ),
			],
			'condition'	 => [
				'ved_tooltip_type' => 'text'
			]
		]
		);
		$this->add_control(
		'ved_tooltip_shortcode_content', [
			'label'		 => esc_html__( 'Shortcode', 'vedanta' ),
			'type'		 => Controls_Manager::TEXTAREA,
			'label_block'	 => true,
			'default'	 => esc_html__( '[shortcode-here]', 'vedanta' ),
			'condition'	 => [
				'ved_tooltip_type' => [ 'shortcode' ]
			]
		]
		);
		$this->add_control(
		'ved_tooltip_icon_content', [
			'label'		 => esc_html__( 'Icon', 'vedanta' ),
			'type'		 => Controls_Manager::ICON,
			'default'	 => 'fa fa-home',
			'condition'	 => [
				'ved_tooltip_type' => [ 'icon' ]
			]
		]
		);
		$this->add_control(
		'ved_tooltip_img_content', [
			'label'		 => esc_html__( 'Image', 'vedanta' ),
			'type'		 => Controls_Manager::MEDIA,
			'default'	 => [
				'url' => Utils::get_placeholder_image_src(),
			],
			'condition'	 => [
				'ved_tooltip_type' => [ 'image' ]
			]
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_content_alignment', [
			'label'		 => esc_html__( 'Content Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'left'		 => [
					'title'	 => esc_html__( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center'	 => [
					'title'	 => esc_html__( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'		 => [
					'title'	 => esc_html__( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				],
				'justify'	 => [
					'title'	 => esc_html__( 'Justified', 'vedanta' ),
					'icon'	 => 'fa fa-align-justify',
				],
			],
			'default'	 => 'left',
			'prefix_class'	 => 'ved-tooltip-align-',
		]
		);
		$this->add_control(
		'ved_tooltip_enable_link', [
			'label'		 => esc_html__( 'Enable Link', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'false',
			'return_value'	 => 'yes',
			'condition'	 => [
				'ved_tooltip_type!' => [ 'shortcode' ]
			]
		]
		);
		$this->add_control(
		'ved_tooltip_link', [
			'label'		 => esc_html__( 'Button Link', 'vedanta' ),
			'type'		 => Controls_Manager::URL,
			'label_block'	 => true,
			'default'	 => [
				'url'		 => '#',
				'is_external'	 => '',
			],
			'show_external'	 => true,
			'condition'	 => [
				'ved_tooltip_enable_link' => 'yes'
			]
		]
		);
		$this->end_controls_section();

		/**
		 * Tooltip Hover Content Settings
		 */
		$this->start_controls_section(
		'ved_section_tooltip_hover_content_settings', [
			'label' => esc_html__( 'Tooltip Settings', 'vedanta' )
		]
		);
		$this->add_control(
		'ved_tooltip_hover_content', [
			'label'		 => esc_html__( 'Content', 'vedanta' ),
			'type'		 => Controls_Manager::WYSIWYG,
			'label_block'	 => true,
			'default'	 => esc_html__( 'Tooltip Content Here', 'vedanta' ),
			'dynamic'	 => [ 'active' => true ]
		]
		);
		$this->add_control(
		'ved_tooltip_hover_dir', [
			'label'		 => esc_html__( 'Hover Direction', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'right',
			'label_block'	 => false,
			'options'	 => [
				'left'	 => esc_html__( 'Left', 'vedanta' ),
				'right'	 => esc_html__( 'Right', 'vedanta' ),
				'top'	 => esc_html__( 'Top', 'vedanta' ),
				'bottom' => esc_html__( 'Bottom', 'vedanta' ),
			],
		]
		);
		$this->add_control(
		'ved_tooltip_hover_speed', [
			'label'		 => esc_html__( 'Hover Speed', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => false,
			'default'	 => esc_html__( '300', 'vedanta' ),
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip:hover .ved-tooltip-text.ved-tooltip-top'	 => 'animation-duration: {{SIZE}}ms;',
				'{{WRAPPER}} .ved-tooltip:hover .ved-tooltip-text.ved-tooltip-left'	 => 'animation-duration: {{SIZE}}ms;',
				'{{WRAPPER}} .ved-tooltip:hover .ved-tooltip-text.ved-tooltip-bottom'	 => 'animation-duration: {{SIZE}}ms;',
				'{{WRAPPER}} .ved-tooltip:hover .ved-tooltip-text.ved-tooltip-right'	 => 'animation-duration: {{SIZE}}ms;',
			]
		]
		);
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Tooltip Content
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_tooltip_style_settings', [
			'label'	 => esc_html__( 'Content Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_max_width', [
			'label'		 => esc_html__( 'Content Max Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
					'step'	 => 5,
				],
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
			],
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip' => 'max-width: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_control(
		'ved_tooltip_icon_size', [
			'label'		 => esc_html__( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 200,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-content i' => 'font-size: {{SIZE}}px;',
			],
			'condition'	 => [
				'ved_tooltip_type' => [ 'icon' ]
			],
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_content_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_content_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->start_controls_tabs( 'ved_tooltip_content_style_tabs' );
		// Normal State Tab
		$this->start_controls_tab( 'ved_tooltip_content_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );
		$this->add_control(
		'ved_tooltip_content_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_tooltip_content_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-tooltip a'	 => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_tooltip_shadow',
			'selector'	 => '{{WRAPPER}} .ved-tooltip',
			'separator'	 => 'before'
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_tooltip_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-tooltip',
		]
		);
		$this->end_controls_tab();

		// Hover State Tab
		$this->start_controls_tab( 'ved_tooltip_content_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );
		$this->add_control(
		'ved_tooltip_content_hover_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip:hover' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_tooltip_content_hover_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip:hover'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-tooltip:hover a'	 => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_tooltip_hover_shadow',
			'selector'	 => '{{WRAPPER}} .ved-tooltip:hover',
			'separator'	 => 'before'
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_tooltip_hover_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-tooltip:hover',
		]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_tooltip_content_typography',
			'selector'	 => '{{WRAPPER}} .ved-tooltip',
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_content_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Tooltip Hover Content
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_tooltip_hover_style_settings', [
			'label'	 => esc_html__( 'Tooltip Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_hover_width', [
			'label'		 => esc_html__( 'Tooltip Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => '150'
			],
			'range'		 => [
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
					'step'	 => 5,
				],
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
			],
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text' => 'width: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_hover_max_width', [
			'label'		 => esc_html__( 'Tooltip Max Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => '150'
			],
			'range'		 => [
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
					'step'	 => 5,
				],
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
			],
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text' => 'max-width: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_hover_content_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_hover_content_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_control(
		'ved_tooltip_hover_content_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#555',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_tooltip_hover_content_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_tooltip_hover_content_typography',
			'selector'	 => '{{WRAPPER}} .ved-tooltip .ved-tooltip-text',
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_tooltip_box_shadow',
			'selector'	 => '{{WRAPPER}} .ved-tooltip .ved-tooltip-text',
		]
		);
		$this->add_responsive_control(
		'ved_tooltip_arrow_size', [
			'label'		 => esc_html__( 'Arrow Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 5,
				'unit'	 => 'px',
			],
			'size_units'	 => [ 'px' ],
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text:after'			 => 'border-width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-left::after'	 => 'top: calc( 50% - {{SIZE}}{{UNIT}} );',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-right::after'	 => 'top: calc( 50% - {{SIZE}}{{UNIT}} );',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-top::after'	 => 'left: calc( 50% - {{SIZE}}{{UNIT}} );',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-bottom::after'	 => 'left: calc( 50% - {{SIZE}}{{UNIT}} );',
			],
		]
		);
		$this->add_control(
		'ved_tooltip_arrow_color', [
			'label'		 => esc_html__( 'Arrow Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#555',
			'selectors'	 => [
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-top:after'	 => 'border-top-color: {{VALUE}};',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-bottom:after'	 => 'border-bottom-color: {{VALUE}};',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-left:after'	 => 'border-left-color: {{VALUE}};',
				'{{WRAPPER}} .ved-tooltip .ved-tooltip-text.ved-tooltip-right:after'	 => 'border-right-color: {{VALUE}};',
			],
		]
		);
		$this->end_controls_section();
	}

	protected function render() {

		$settings	 = $this->get_settings_for_display();
		$target		 = $settings[ 'ved_tooltip_link' ][ 'is_external' ] ? 'target="_blank"' : '';
		$nofollow	 = $settings[ 'ved_tooltip_link' ][ 'nofollow' ] ? 'rel="nofollow"' : '';
		?>
		<div class="ved-tooltip">
		<?php if ( $settings[ 'ved_tooltip_type' ] === 'text' ) : ?>
				<<?php echo esc_attr( $settings[ 'ved_tooltip_content_tag' ] ); ?> class="ved-tooltip-content"><?php if ( $settings[ 'ved_tooltip_enable_link' ] === 'yes' ) : ?><a href="<?php echo esc_url( $settings[ 'ved_tooltip_link' ][ 'url' ] ); ?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> ><?php endif; ?><?php echo esc_html__( $settings[ 'ved_tooltip_content' ], 'vedanta' ); ?><?php if ( $settings[ 'ved_tooltip_enable_link' ] === 'yes' ) : ?></a><?php endif; ?></<?php echo esc_attr( $settings[ 'ved_tooltip_content_tag' ] ); ?>>
				<span class="ved-tooltip-text ved-tooltip-<?php echo esc_attr( $settings[ 'ved_tooltip_hover_dir' ] ) ?>"><?php echo  esc_html($settings[ 'ved_tooltip_hover_content' ] ); ?></span>
		<?php elseif ( $settings[ 'ved_tooltip_type' ] === 'icon' ) : ?>
				<span class="ved-tooltip-content"><?php if ( $settings[ 'ved_tooltip_enable_link' ] === 'yes' ) : ?><a href="<?php echo esc_url( $settings[ 'ved_tooltip_link' ][ 'url' ] ); ?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> ><?php endif; ?><i class="<?php echo esc_attr( $settings[ 'ved_tooltip_icon_content' ] ); ?>"></i><?php if ( $settings[ 'ved_tooltip_enable_link' ] === 'yes' ) : ?></a><?php endif; ?></span>
				<span class="ved-tooltip-text ved-tooltip-<?php echo esc_attr( $settings[ 'ved_tooltip_hover_dir' ] ) ?>"><?php echo  esc_html($settings[ 'ved_tooltip_hover_content' ] ); ?></span>
		<?php elseif ( $settings[ 'ved_tooltip_type' ] === 'image' ) : ?>
				<span class="ved-tooltip-content"><?php if ( $settings[ 'ved_tooltip_enable_link' ] === 'yes' ) : ?><a href="<?php echo esc_url( $settings[ 'ved_tooltip_link' ][ 'url' ] ); ?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> ><?php endif; ?><img src="<?php echo esc_url( $settings[ 'ved_tooltip_img_content' ][ 'url' ] ); ?>" alt="<?php echo esc_attr( $settings[ 'ved_tooltip_hover_content' ] ); ?>"><?php if ( $settings[ 'ved_tooltip_enable_link' ] === 'yes' ) : ?></a><?php endif; ?></span>
				<span class="ved-tooltip-text ved-tooltip-<?php echo esc_attr( $settings[ 'ved_tooltip_hover_dir' ] ) ?>"><?php echo  esc_html($settings[ 'ved_tooltip_hover_content' ] ); ?></span>
		<?php elseif ( $settings[ 'ved_tooltip_type' ] === 'shortcode' ) : ?>
				<div class="ved-tooltip-content"><?php echo do_shortcode( $settings[ 'ved_tooltip_shortcode_content' ] ); ?></div>
				<span class="ved-tooltip-text ved-tooltip-<?php echo esc_attr( $settings[ 'ved_tooltip_hover_dir' ] ) ?>"><?php echo  esc_html($settings[ 'ved_tooltip_hover_content' ] ); ?></span>
		<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_ved_Tooltip() );
