<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_Woo_Cat_Slider extends Widget_Base {

    public $base;

    public function get_name() {
        return 'ved-woo-cats-slider';
    }

    public function get_title() {
        return esc_html__( 'Ved Category Slider', 'vedanta' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Select Categories', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_title', [
            'label'       => esc_html__( 'Title', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Menu Title Here', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_enable_img', [
            'label'   => esc_html__( 'Display Category Image?', 'vedanta' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ]
        );
        
        $this->add_control(
        'ved_woo_cats_slider_show_subcat', [
            'label'   => __( 'Show No SubCategories', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 10,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_item', [
            'type'        => Controls_Manager::REPEATER,
            'fields'      => [
                [
                    'name'    => 'ved_woo_cats_slider_image',
                    'label'   => __( 'Choose Category Image', 'vedanta' ),
                    'type'    => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name'        => 'ved_woo_cats_slider_main',
                    'label'       => esc_html__( 'Main Category', 'vedanta' ),
                    'type'        => Controls_Manager::SELECT2,
                    'label_block' => false,
                    'multiple'    => false,
                    'options'     => ved_woocommerce_product_categories_by_id(),
                ],
            ],
            'title_field' => 'Category Item',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_woo_cat_selector_settings', [
            'label' => esc_html__( 'Category Slider Settings', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_items', [
            'label'   => __( 'Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_autoplay', [
            'label'        => __( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_navigation', [
            'label'        => __( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_pagination', [
            'label'        => __( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();

        // Category Item Options
        $cat_title      = $settings[ 'ved_woo_cats_slider_title' ];
        $cat_enable_img = $settings[ 'ved_woo_cats_slider_enable_img' ];

        // Slider Options
        $items      = $settings[ 'ved_woo_cats_slider_items' ];
        $autoplay   = $settings[ 'ved_woo_cats_slider_autoplay' ];
        $navigation = $settings[ 'ved_woo_cats_slider_navigation' ];
        $pagination = $settings[ 'ved_woo_cats_slider_pagination' ];

        if ( isset( $cat_title ) && $cat_title ) {
            ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $cat_title ); ?></h3>
            </div>
        <?php }
        ?>
        <div id="ved-woo-cats-slider-<?php echo esc_attr( $this->get_id() ); ?>" class="row">
            <div class="ved-woo-cats-slider">
                <?php
                foreach ( $settings[ 'ved_woo_cats_slider_item' ] as $cat_item ) :
                    $cat_image = $cat_item[ 'ved_woo_cats_slider_image' ];
                    $cat_id    = $cat_item[ 'ved_woo_cats_slider_main' ];
                    $cat_name  = get_the_category_by_ID( $cat_id );
                    $cat_link  = get_category_link( $cat_id );
                    ?>
                    <div class="item">
                        <?php
                        if ( $cat_enable_img ) {
                            ?>
                            <div class="cat-img">
                                <a class="cat-img" href="<?php echo esc_url( $cat_link ); ?>" title="<?php echo esc_attr( $cat_name ); ?>">
                                    <img src="<?php echo esc_url( $cat_image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $cat_name ); ?>" height="auto" width="auto"/>
                                </a>
                            </div>
                        <?php } ?>
                        <div class="category-desc">
                            <h2 class="categoryName">
                                <a class="cat_name" href="<?php echo esc_url( $cat_link ); ?>"  title="<?php echo esc_attr( $cat_name ); ?>"><?php echo esc_html( $cat_name ); ?></a>
                            </h2>
                            <div class="content-cate">
                                <div class="sub-cat">
                                    <ul>
                                        <?php
                                        $args           = array(
                                            'child_of'   => $cat_id,
                                            'taxonomy'   => 'product_cat',
                                            'hide_empty' => true,
                                        );
                                        $sub_categories = get_categories( $args );
                                        
                                        $subcat_no = count( $sub_categories );
                                        $subcat_limit = $settings[ 'ved_woo_cats_slider_show_subcat' ];
                                        if($subcat_limit > $subcat_no) {
                                            $loop = $subcat_no;
                                        } else {
                                            $loop = $subcat_limit;
                                        }
                                        
                                        for ( $i=0; $i<$loop; $i++ ) {
                                            $sub_cat = get_term( $sub_categories[$i], 'product_cat' );
                                            ?>
                                            <li>
                                                <a href="<?php echo esc_url( get_category_link( $sub_cat ) ); ?>" title="<?php echo esc_attr( $sub_cat->name ); ?>"><i class="ti-arrow-right"></i><?php echo esc_html( $sub_cat->name ); ?></a>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                var category_sld = $("#ved-woo-cats-slider-<?php echo esc_attr( $this->get_id() ); ?> .ved-woo-cats-slider");
                category_sld.owlCarousel({
                    autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                    navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                    pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                    items: <?php echo $items; ?>,
                    loop:false,
                    navigationText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                    itemsDesktop : [1199,3],
                    itemsDesktopSmall : [992,3],
                    itemsTablet: [768,3],
                    itemsTabletSmall: [700,2] ,
                    itemsMobile : [320,2]
                });
            });
        </script>
        <?php
    }

    protected function _content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Woo_Cat_Slider() );
