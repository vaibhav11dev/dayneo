<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_Woo_Product_Tab extends Widget_Base {

    public $base;

    public function get_name() {
        return 'ved-woo-product-tab';
    }

    public function get_title() {
        return esc_html__( 'Ved Product Tab', 'vedanta' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Ved Product element', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_head_title', [
            'label'       => esc_html__( 'Heading Title', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Featured Product', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_product_style', [
            'label'   => esc_html__( 'Style', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Single Row', 'vedanta' ),
                'style2' => esc_html__( 'Double Row', 'vedanta' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_column', [
            'label'   => esc_html__( 'Columns', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'default' => '4',
            'options' => [
                '2' => esc_html__( '2', 'vedanta' ),
                '3' => esc_html__( '3', 'vedanta' ),
                '4' => esc_html__( '4', 'vedanta' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_count', [
            'label'   => __( 'Products Count', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_show_tab', [
            'label'     => esc_html__( 'Show Tab', 'vedanta' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'vedanta' ),
            'label_off' => esc_html__( 'No', 'vedanta' ),
            'default'   => 'yes',
        ]
        );

        $this->add_control(
        'ved_product_rating', [
            'label'     => esc_html__( 'Show Review', 'vedanta' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'vedanta' ),
            'label_off' => esc_html__( 'No', 'vedanta' ),
            'default'   => 'yes',
        ]
        );

        $this->add_control(
        'ved_product_tab', [
            'label'     => esc_html__( 'Product Tabs', 'vedanta' ),
            'type'      => Controls_Manager::REPEATER,
            'separator' => 'before',
            'default'   => [
                [
                    'product_title'   => esc_html__( 'On Sell', 'vedanta' ),
                    'product_content' => 'recent',
                ],
                [
                    'product_title'   => esc_html__( 'Hot Sell', 'vedanta' ),
                    'product_content' => 'featured',
                ],
                [
                    'product_title'   => esc_html__( 'Best Sell', 'vedanta' ),
                    'product_content' => 'best_sell',
                ],
            ],
            'fields'    => [
                [
                    'name'        => 'product_title',
                    'label'       => esc_html__( 'Title', 'vedanta' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                ],
                [
                    'name'    => 'product_content',
                    'label'   => esc_html__( 'Product Attribute', 'vedanta' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'recent',
                    'options' => [
                        'recent'    => esc_html__( 'Recent Product', 'vedanta' ),
                        'featured'  => esc_html__( 'Featured Product', 'vedanta' ),
                        'best_sell' => esc_html__( 'Popular Product', 'vedanta' ),
                        'on_sell'   => esc_html__( 'Sale Product', 'vedanta' ),
                        'top_rate'  => esc_html__( 'Top Rated Products', 'vedanta' ),
                    ],
                ],
            ],
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_product_tab_slider_settings', [
            'label' => esc_html__( 'Product Tab Slider Settings', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_items', [
            'label'   => __( 'Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_autoplay', [
            'label'        => __( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_navigation', [
            'label'        => __( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_pagination', [
            'label'        => __( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'section_style', [
            'label' => esc_html__( 'Style', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );
        $this->add_control(
        'tab_title_color', [
            'label'     => esc_html__( 'Tab Title color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-nav-tab .nav-link' => 'color: {{VALUE}};'
            ],
        ]
        );
        $this->add_control(
        'tab_title_hover_color', [
            'label'     => esc_html__( 'Tab Title Active & Hover color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-nav-tab .nav-link.active, .ved-nav-tab .nav-link:hover' => 'color: {{VALUE}};'
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'tab_title_typography',
            'selector' => '{{WRAPPER}} .ved-nav-tab .nav-item .nav-link',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings        = $this->get_settings();

        // Slider Options
        $items      = $settings[ 'ved_product_tab_slider_items' ];
        $autoplay   = $settings[ 'ved_product_tab_slider_autoplay' ];
        $navigation = $settings[ 'ved_product_tab_slider_navigation' ];
        $pagination = $settings[ 'ved_product_tab_slider_pagination' ];

        $style     = $settings[ 'ved_product_style' ];
        $product_tab     = $settings[ 'ved_product_tab' ];
        $head_title      = $settings[ 'ved_head_title' ];
        $columns         = $settings[ 'ved_product_column' ];
        $product_count   = $settings[ 'ved_product_count' ];
        $show_tab        = $settings[ 'ved_show_tab' ];
        $product_classes = ( ($settings[ 'ved_product_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
        ?>
        <div id="ved-woo-product-tab-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-product-tab <?php echo esc_attr( $product_classes ); ?>">
            <div class="sec-head-style">
                <h3 class="page-heading text-uppercase"><?php echo esc_html( $head_title ); ?></h3>
                <?php
                if ( $show_tab && is_array( $product_tab ) && count( $product_tab ) > 0 ):
                    $rand_id = 'ved-tabs-' . mt_rand( 10000, 99999 ) . '-';
                    ?>
                    <ul class="nav nav-tabs ved-nav-tab" role="tablist">
                        <?php
                        foreach ( $product_tab as $key => $product_tabs ):
                            $active = ($key == 0) ? 'active' : '';
                            ?>
                            <li class="nav-item <?php echo esc_attr( $active ) ?>">
                                <a class="nav-link"  data-toggle="tab" href="#<?php echo esc_attr( $rand_id . $key ); ?>" role="tab" ><?php echo esc_html( $product_tabs[ 'product_title' ] ); ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <div class="clearfix"></div>
            </div>
            <div class="tab-content" data-column="<?php echo esc_attr( $columns ) ?>">
                <?php
                switch ( $style ) {
                    case 'style1':
                        require VEDANTA_CORE_PATH . 'includes/style/tab/style1.php';
                        break;

                    case 'style2':
                        require VEDANTA_CORE_PATH . 'includes/style/tab/style2.php';
                        break;
                }
                ?>
            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                var ved_tab_sld = $("#ved-woo-product-tab-<?php echo esc_attr( $this->get_id() ); ?> .ved-tab-product-slider,#ved-woo-product-tab-<?php echo esc_attr( $this->get_id() ); ?> .ved-tab-single-product-slider .multi-columns-row.products");
                ved_tab_sld.owlCarousel({
                    autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                    navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                    pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                    items: <?php echo $items; ?>,
                    loop:false,
                    navigationText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                    itemsDesktop : [1199,3],
                    itemsDesktopSmall : [992,3],
                    itemsTablet: [768,3],
                    itemsTabletSmall: [767,2] ,
                    itemsMobile : [320,2]               
                });
            });
        </script>
            <?php
            }

            protected function _content_template() {
                
            }

        }

        Plugin::instance()->widgets_manager->register_widget_type( new Widget_Woo_Product_Tab() );
        