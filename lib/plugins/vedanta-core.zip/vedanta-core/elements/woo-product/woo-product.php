<?php
namespace Elementor;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_Woo_Product extends Widget_Base {

    public function get_name() {
        return 'ved-woo-product';
    }

    public function get_title() {
        return esc_html__( 'Ved Product', 'vedanta' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {

        // Content Controls
        $this->start_controls_section(
        'ved_section_product_grid_settings', [
            'label' => esc_html__( 'Product Settings', 'vedanta' )
        ]
        );

        $this->add_control(
        'ved_product_title', [
            'label'       => esc_html__( 'Heading Title', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Recent Product', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_product_type', [
            'label'   => esc_html__( 'Layout Type', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'slider',
            'options' => [
                'grid'   => esc_html__( 'grid', 'vedanta' ),
                'slider' => esc_html__( 'Slider', 'vedanta' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_filter', [
            'label'   => esc_html__( 'Filter By', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'recent',
            'options' => [
                'recent'       => esc_html__( 'Recent Product', 'vedanta' ),
                'featured'     => esc_html__( 'Featured Product', 'vedanta' ),
                'best_sell' => esc_html__( 'Popular Product', 'vedanta' ),
                'on_sell'         => esc_html__( 'Sale Product', 'vedanta' ),
                'top_rate'          => esc_html__( 'Top Rated Products', 'vedanta' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_column', [
            'label'   => esc_html__( 'Columns', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'default' => '4',
            'options' => [
                '2' => esc_html__( '2', 'vedanta' ),
                '3' => esc_html__( '3', 'vedanta' ),
                '4' => esc_html__( '4', 'vedanta' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_count', [
            'label'   => __( 'Products Count', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_categories', [
            'label'       => esc_html__( 'Product Categories', 'vedanta' ),
            'type'        => Controls_Manager::SELECT2,
            'label_block' => true,
            'multiple'    => true,
            'options'     => ved_woocommerce_product_categories(),
        ]
        );

        $this->add_control(
        'ved_product_rating', [
            'label'        => esc_html__( 'Show Product Rating?', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_product_slider_settings', [
            'label' => esc_html__( 'Product Slider Settings', 'vedanta' ),
            'condition'    => [
                'ved_product_type' => 'slider',
            ]
        ]
        );

        $this->add_control(
        'ved_product_slider_items', [
            'label'   => __( 'Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_slider_autoplay', [
            'label'        => __( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_slider_navigation', [
            'label'        => __( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_slider_pagination', [
            'label'        => __( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_product_grid_typography', [
            'label' => esc_html__( 'Color &amp; Typography', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_product_title_heading', [
            'label' => __( 'Product Title', 'vedanta' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_product_title_color', [
            'label'     => esc_html__( 'Product Title Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-woo-product .woocommerce .woocommerce-loop-product__title .woocommerce-loop-product__link' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_product_title_typography',
            'selector' => '{{WRAPPER}} .ved-woo-product .woocommerce .woocommerce-loop-product__title .woocommerce-loop-product__link',
        ]
        );

        $this->add_control(
        'ved_product_price_heading', [
            'label' => __( 'Product Price', 'vedanta' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );


        $this->add_control(
        'ved_product_price_color', [
            'label'     => esc_html__( 'Product Price Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-woo-product .woocommerce .price' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_product_price_typography',
            'selector' => '{{WRAPPER}} .ved-woo-product .woocommerce .price',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings();
        
        // Slider Options
        $items      = $settings[ 'ved_product_slider_items' ];
        $autoplay   = $settings[ 'ved_product_slider_autoplay' ];
        $navigation = $settings[ 'ved_product_slider_navigation' ];
        $pagination = $settings[ 'ved_product_slider_pagination' ];

        $product_filter  = $settings[ 'ved_product_filter' ];
        $product_count   = $settings[ 'ved_product_count' ];
        $columns         = $settings[ 'ved_product_column' ];
        $product_classes = ( ($settings[ 'ved_product_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
        $product_layout  = ( ($settings[ 'ved_product_type' ] == 'slider') ? "ved-woo-product-slider" : "ved-woo-product-grid" );

        $category               = $get_product_categories = $settings[ 'ved_product_categories' ]; // get custom field value
        if ( $get_product_categories >= 1 ) {
            $category_ids = implode( ', ', $get_product_categories );
        } else {
            $category_ids = '';
        }
        ?>

        <?php if ( isset( $settings[ 'ved_product_title' ] ) && $settings[ 'ved_product_title' ] ) { ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $settings[ 'ved_product_title' ] ); ?></h3>
            </div>
        <?php } ?>

        <div id="ved-woo-product-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-product <?php echo esc_attr( $product_layout ); ?> <?php echo esc_attr( $product_classes ); ?>">

            <?php
            switch ( $product_filter ) {
                case 'recent':
                    echo do_shortcode( "[recent_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category_ids\"]" );
                    break;

                case 'featured':
                    echo do_shortcode( "[featured_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" );
                    break;

                case 'best_sell':
                    echo do_shortcode( "[best_selling_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" );
                    break;

                case 'on_sell':
                    echo do_shortcode( "[sale_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" );
                    break;

                case 'top_rate':
                    echo do_shortcode( "[top_rated_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" );
                    break;
            }
            ?>

            <div class="clearfix"></div>
        </div>
        <?php
        if ( $settings[ 'ved_product_type' ] == 'slider' ) :
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                    var wooproduct_sld = $("#ved-woo-product-<?php echo esc_attr( $this->get_id() ); ?>.ved-woo-product-slider .multi-columns-row.products");
                    wooproduct_sld.owlCarousel({
                        autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                        navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                        pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                        items: <?php echo $items; ?>,
                        loop:false,
                        navigationText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                        itemsDesktop : [1199,3],
                        itemsDesktopSmall : [992,3],
                        itemsTablet: [768,3],
                        itemsTabletSmall: [767,2] ,
                        itemsMobile : [320,2]             
                    });
            });
        </script>
        <?php
        endif;
    }

    protected function content_template() {
        ?>


        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Woo_Product() );
