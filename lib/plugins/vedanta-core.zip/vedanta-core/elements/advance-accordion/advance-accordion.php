<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Ved_Adv_Accordion extends Widget_Base {

	public function get_name() {
		return 'ved-adv-accordion';
	}

	public function get_title() {
		return esc_html__( 'Ved Advanced Accordion', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-accordion';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {
		/**
		 * Advance Accordion Settings
		 */
		$this->start_controls_section(
		'ved_section_adv_accordion_settings', [
			'label' => esc_html__( 'General Settings', 'vedanta' )
		]
		);
		$this->add_control(
		'ved_adv_accordion_type', [
			'label'		 => esc_html__( 'Accordion Type', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'accordion',
			'label_block'	 => false,
			'options'	 => [
				'accordion'	 => esc_html__( 'Accordion', 'vedanta' ),
				'toggle'	 => esc_html__( 'Toggle', 'vedanta' ),
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_icon_show', [
			'label'		 => esc_html__( 'Enable Toggle Icon', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'yes',
			'return_value'	 => 'yes',
		]
		);
		$this->add_control(
		'ved_adv_accordion_icon', [
			'label'		 => esc_html__( 'Toggle Icon', 'vedanta' ),
			'type'		 => Controls_Manager::ICON,
			'default'	 => 'fa fa-angle-right',
			'include'	 => [
				'fa fa-angle-right',
				'fa fa-angle-double-right',
				'fa fa-chevron-right',
				'fa fa-chevron-circle-right',
				'fa fa-arrow-right',
				'fa fa-long-arrow-right',
			],
			'condition'	 => [
				'ved_adv_accordion_icon_show' => 'yes'
			]
		]
		);
		$this->add_control(
		'ved_adv_accordion_toggle_speed', [
			'label'		 => esc_html__( 'Toggle Speed (ms)', 'vedanta' ),
			'type'		 => Controls_Manager::NUMBER,
			'label_block'	 => false,
			'default'	 => 300,
		]
		);
		$this->end_controls_section();
		/**
		 * Advance Accordion Content Settings
		 */
		$this->start_controls_section(
		'ved_section_adv_accordion_content_settings', [
			'label' => esc_html__( 'Content Settings', 'vedanta' )
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab', [
			'type'		 => Controls_Manager::REPEATER,
			'seperator'	 => 'before',
			'default'	 => [
					[ 'ved_adv_accordion_tab_title' => esc_html__( 'Accordion Tab Title 1', 'vedanta' ) ],
					[ 'ved_adv_accordion_tab_title' => esc_html__( 'Accordion Tab Title 2', 'vedanta' ) ],
					[ 'ved_adv_accordion_tab_title' => esc_html__( 'Accordion Tab Title 3', 'vedanta' ) ],
			],
			'fields'	 => [
					[
					'name'		 => 'ved_adv_accordion_tab_default_active',
					'label'		 => esc_html__( 'Active as Default', 'vedanta' ),
					'type'		 => Controls_Manager::SWITCHER,
					'default'	 => 'no',
					'return_value'	 => 'yes',
				],
					[
					'name'		 => 'ved_adv_accordion_tab_icon_show',
					'label'		 => esc_html__( 'Enable Tab Icon', 'vedanta' ),
					'type'		 => Controls_Manager::SWITCHER,
					'default'	 => 'no',
					'return_value'	 => 'yes',
				],
					[
					'name'		 => 'ved_adv_accordion_tab_title_icon',
					'label'		 => esc_html__( 'Icon', 'vedanta' ),
					'type'		 => Controls_Manager::ICON,
					'default'	 => 'fa fa-plus',
					'condition'	 => [
						'ved_adv_accordion_tab_icon_show' => 'yes'
					]
				],
					[
					'name'		 => 'ved_adv_accordion_tab_title',
					'label'		 => esc_html__( 'Tab Title', 'vedanta' ),
					'type'		 => Controls_Manager::TEXT,
					'default'	 => esc_html__( 'Tab Title', 'vedanta' ),
					'dynamic'	 => [ 'active' => true ]
				],
					[
					'name'		 => 'ved_adv_accordion_text_type',
					'label'		 => __( 'Content Type', 'vedanta' ),
					'type'		 => Controls_Manager::SELECT,
					'options'	 => [
						'content'	 => __( 'Content', 'vedanta' ),
						'template'	 => __( 'Saved Templates', 'vedanta' ),
					],
					'default'	 => 'content',
				],
					[
					'name'		 => 'ved_primary_templates',
					'label'		 => __( 'Choose Template', 'vedanta' ),
					'type'		 => Controls_Manager::SELECT,
					'options'	 => ved_get_page_templates(),
					'condition'	 => [
						'ved_adv_accordion_text_type' => 'template',
					],
				],
					[
					'name'		 => 'ved_adv_accordion_tab_content',
					'label'		 => esc_html__( 'Tab Content', 'vedanta' ),
					'type'		 => Controls_Manager::WYSIWYG,
					'default'	 => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio, neque qui velit. Magni dolorum quidem ipsam eligendi, totam, facilis laudantium cum accusamus ullam voluptatibus commodi numquam, error, est. Ea, consequatur.', 'vedanta' ),
					'dynamic'	 => [ 'active' => true ],
					'condition'	 => [
						'ved_adv_accordion_text_type' => 'content',
					],
				],
			],
			'title_field'	 => '{{ved_adv_accordion_tab_title}}',
		]
		);
		$this->end_controls_section();
		/**
		 * -------------------------------------------
		 * Tab Style Advance Accordion Generel Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_accordion_style_settings', [
			'label'	 => esc_html__( 'General Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_accordion_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion',
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_adv_accordion_box_shadow',
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion',
		]
		);
		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style Advance Accordion Content Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_accordions_tab_style_settings', [
			'label'	 => esc_html__( 'Tab Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_adv_accordion_tab_title_typography',
			'scheme'	 => Scheme_Typography::TYPOGRAPHY_1,
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header',
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_icon_size', [
			'label'		 => __( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 11,
				'unit'	 => 'px',
			],
			'size_units'	 => [ 'px' ],
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header .fa' => 'font-size: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_icon_gap', [
			'label'		 => __( 'Icon Gap', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 10,
				'unit'	 => 'px',
			],
			'size_units'	 => [ 'px' ],
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header .fa' => 'margin-right: {{SIZE}}{{UNIT}};',
			]
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->start_controls_tabs( 'ved_adv_accordion_header_tabs' );
		// Normal State Tab
		$this->start_controls_tab( 'ved_adv_accordion_header_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );
		$this->add_control(
		'ved_adv_accordion_tab_color', [
			'label'		 => esc_html__( 'Tab Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab_icon_color', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header .fa' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_tabs_icon_show' => 'yes'
			]
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_accordion_tab_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header',
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_tab();
		// Hover State Tab
		$this->start_controls_tab( 'ved_adv_accordion_header_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );
		$this->add_control(
		'ved_adv_accordion_tab_color_hover', [
			'label'		 => esc_html__( 'Tab Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header:hover' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab_text_color_hover', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header:hover' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab_icon_color_hover', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header:hover .fa' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_accordion_toggle_icon_show' => 'yes'
			]
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_accordion_tab_border_hover',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header:hover',
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_border_radius_hover', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_tab();
		// Active State Tab
		$this->start_controls_tab( 'ved_adv_accordion_header_active', [ 'label' => esc_html__( 'Active', 'vedanta' ) ] );
		$this->add_control(
		'ved_adv_accordion_tab_color_active', [
			'label'		 => esc_html__( 'Tab Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header.active' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab_text_color_active', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header.active' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'ved_adv_accordion_tab_icon_color_active', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header.active .fa' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_accordion_toggle_icon_show' => 'yes'
			]
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_accordion_tab_border_active',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header.active',
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_tab_border_radius_active', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		/**
		 * -------------------------------------------
		 * Tab Style Advance Accordion Content Style
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_adv_accordion_tab_content_style_settings', [
			'label'	 => esc_html__( 'Content Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_control(
		'adv_accordion_content_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content' => 'background-color: {{VALUE}};',
			],
		]
		);
		$this->add_control(
		'adv_accordion_content_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777;',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content' => 'color: {{VALUE}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_adv_accordion_content_typography',
			'scheme'	 => Scheme_Typography::TYPOGRAPHY_3,
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content',
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_content_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_responsive_control(
		'ved_adv_accordion_content_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_adv_accordion_content_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content',
		]
		);
		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_adv_accordion_content_shadow',
			'selector'	 => '{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-content',
			'separator'	 => 'before'
		]
		);
		$this->end_controls_section();

		/**
		 * Advance Accordion Caret Settings
		 */
		$this->start_controls_section(
		'ved_section_adv_accordion_caret_settings', [
			'label'	 => esc_html__( 'Toggle Caret Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_responsive_control(
		'ved_adv_accordion_tab_toggle_icon_size', [
			'label'		 => __( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 11,
				'unit'	 => 'px',
			],
			'size_units'	 => [ 'px' ],
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
					'step'	 => 1,
				]
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header .fa-toggle' => 'font-size: {{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_adv_accordion_icon_show' => 'yes'
			]
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_toggle_color', [
			'label'		 => esc_html__( 'Caret Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header .fa-toggle' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_accordion_icon_show' => 'yes'
			]
		]
		);
		$this->add_control(
		'ved_adv_tabs_tab_toggle_active_color', [
			'label'		 => esc_html__( 'Caret Color (Active)', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list .ved-accordion-header.active .fa-toggle'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-adv-accordion .ved-accordion-list:hover .ved-accordion-header .fa-toggle'	 => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_adv_accordion_icon_show' => 'yes'
			]
		]
		);
		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		?>
		<div class="ved-adv-accordion" id="ved-adv-accordion-<?php echo esc_attr( $this->get_id() ); ?>">
		<?php foreach ( $settings[ 'ved_adv_accordion_tab' ] as $tab ) : ?>
				<div class="ved-accordion-list">
					<div class="ved-accordion-header<?php if ( $tab[ 'ved_adv_accordion_tab_default_active' ] == 'yes' ) : echo ' active-default';
			endif; ?>">
						<span><?php if ( $tab[ 'ved_adv_accordion_tab_icon_show' ] === 'yes' ) : ?><i class="<?php echo esc_attr( $tab[ 'ved_adv_accordion_tab_title_icon' ] ); ?> fa-accordion-icon"></i><?php endif; ?>  <?php echo esc_html($tab[ 'ved_adv_accordion_tab_title' ]); ?></span> <?php if ( $settings[ 'ved_adv_accordion_icon_show' ] === 'yes' ) : ?><i class="<?php echo esc_attr( $settings[ 'ved_adv_accordion_icon' ] ); ?> fa-toggle"></i> <?php endif; ?>
					</div>
					<div class="ved-accordion-content clearfix<?php if ( $tab[ 'ved_adv_accordion_tab_default_active' ] == 'yes' ) : echo ' active-default';
			endif; ?>">
			<?php if ( 'content' == $tab[ 'ved_adv_accordion_text_type' ] ) : ?>
							<p><?php echo do_shortcode( $tab[ 'ved_adv_accordion_tab_content' ] ); ?></p>
			<?php
			elseif ( 'template' == $tab[ 'ved_adv_accordion_text_type' ] ) :
				if ( ! empty( $tab[ 'ved_primary_templates' ] ) ) {
					$ved_template_id = $tab[ 'ved_primary_templates' ];
					$ved_frontend	 = new Frontend;
					echo $ved_frontend->get_builder_content( $ved_template_id, true );
				}
			endif;
			?>
					</div>
				</div>
		<?php endforeach; ?>
		</div>
		<script>
			jQuery(document).ready(function ($) {
				var $vedAdvAccordion = $('#ved-adv-accordion-<?php echo esc_attr( $this->get_id() ); ?>');
				var $vedAccordionList = $vedAdvAccordion.find('.ved-accordion-list');
				var $vedAccordionListHeader = $vedAdvAccordion.find('.ved-accordion-list .ved-accordion-header');
				var $vedAccordioncontent = $vedAdvAccordion.find('.ved-accordion-content');
				$vedAccordionList.each(function (i) {
					if ($(this).find('.ved-accordion-header').hasClass('active-default')) {
						$(this).find('.ved-accordion-header').addClass('active');
						$(this).find('.ved-accordion-content').addClass('active').css('display', 'block').slideDown(<?php echo esc_attr( $settings[ 'ved_adv_accordion_toggle_speed' ] ); ?>);
					}
				});
		<?php if ( 'accordion' == $settings[ 'ved_adv_accordion_type' ] ) : ?>
					$vedAccordionListHeader.on('click', function () {
						// Check if 'active' class is already exists
						if ($(this).hasClass('active')) {
							$(this).removeClass('active');
							$(this).next('.ved-accordion-content').removeClass('active').slideUp(<?php echo esc_attr( $settings[ 'ved_adv_accordion_toggle_speed' ] ); ?>);
						} else {
							$vedAccordionListHeader.removeClass('active');
							$vedAccordionListHeader.next('.ved-accordion-content').removeClass('active').slideUp(<?php echo esc_attr( $settings[ 'ved_adv_accordion_toggle_speed' ] ); ?>);

							$(this).toggleClass('active');
							$(this).next('.ved-accordion-content').slideToggle(<?php echo esc_attr( $settings[ 'ved_adv_accordion_toggle_speed' ] ); ?>, function () {
								$(this).toggleClass('active');
							});
						}
					});
					<?php endif; ?>
					<?php if ( 'toggle' == $settings[ 'ved_adv_accordion_type' ] ) : ?>
					$vedAccordionListHeader.on('click', function () {
						// Check if 'active' class is already exists
						if ($(this).hasClass('active')) {
							$(this).removeClass('active');
							$(this).next('.ved-accordion-content').removeClass('active').slideUp(<?php echo esc_attr( $settings[ 'ved_adv_accordion_toggle_speed' ] ); ?>);
						} else {
							$(this).toggleClass('active');
							$(this).next('.ved-accordion-content').slideToggle(<?php echo esc_attr( $settings[ 'ved_adv_accordion_toggle_speed' ] ); ?>, function () {
								$(this).toggleClass('active');
							});
						}
					});
		<?php endif; ?>
			});
		</script>
		<?php
	}

	protected function content_template() {
		
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Adv_Accordion() );
