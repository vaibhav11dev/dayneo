<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Ved_Piechart extends Widget_Base {

	public function get_name() {
		return 'ved-piechart';
	}

	public function get_title() {
		return __( 'Ved Piechart', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-counter-circle';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
		'ved_section_piechart', [
			'label' => __( 'Piechart', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_piechart_title', [
			'label'		 => __( 'Title', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'dynamic'	 => [
				'active' => true,
			],
			'placeholder'	 => __( 'Enter your title', 'vedanta' ),
			'default'	 => __( 'Branding', 'vedanta' ),
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_piechart_content', [
			'label'		 => __( 'Content', 'elementor' ),
			'type'		 => Controls_Manager::TEXTAREA,
			'dynamic'	 => [
				'active' => true,
			],
			'rows'		 => '10',
			'default'	 => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
		]
		);

		$this->add_control(
		'ved_piechart_percent', [
			'label'		 => __( 'Percentage', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 50,
				'unit'	 => '%',
			],
			'label_block'	 => true,
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_piechart_section_styling', [
			'label'	 => __( 'Piechart Styling', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_bar_color', [
			'label'		 => __( 'Bar color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#10c9c3',
		]
		);

//        $this->add_control(
//            'ved_piechart_track_color',
//            [
//                'label' => __('Track color', 'vedanta'),
//                'type' => Controls_Manager::COLOR,
//                'default' => '#dddddd',
//            ]
//        );

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_piechart_section_title', [
			'label'	 => __( 'Piechart Title', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_title_color', [
			'label'		 => __( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-piechart .chart-title h4' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_piechart_title_typography',
			'selector'	 => '{{WRAPPER}} .ved-piechart .chart-title h4',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_piechart_section_content', [
			'label'	 => __( 'Piechart Content', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_content_color', [
			'label'		 => __( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-piechart .chart-title p' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_piechart_content_typography',
			'selector'	 => '{{WRAPPER}} .ved-piechart .chart-title p',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_piechart_section_percentage', [
			'label'	 => __( 'Piechart Percentage', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_percentage_color', [
			'label'		 => __( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-piechart .chart-text' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_piechart_percentage_typography',
			'selector'	 => '{{WRAPPER}} .ved-piechart .chart-text',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		?>
		<div class="ved-piechart">
			<div class="pie-chart">
				<div class="chart" data-percent="<?php echo esc_attr($settings[ 'ved_piechart_percent' ][ 'size' ]); ?>" data-chart-options='{"barColor":"<?php echo esc_attr($settings[ 'ved_piechart_bar_color' ]); ?>"}'>
					<div class="chart-text"><?php echo esc_attr($settings[ 'ved_piechart_percent' ][ 'size' ]); ?>%</div>
				</div>
				<div class="chart-title">
					<h4><?php echo esc_html($settings[ 'ved_piechart_title' ]); ?></h4>
					<p><?php echo $settings[ 'ved_piechart_content' ]; ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Piechart() );
