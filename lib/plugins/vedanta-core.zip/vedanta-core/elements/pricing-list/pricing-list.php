<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_Ved_Pricing_List extends Widget_Base {

    public function get_name() {
	return 'ved-pricing-list';
    }

    public function get_title() {
	return esc_html__( 'Ved Pricing List', 'vedanta' );
    }

    public function get_icon() {
	return 'eicon-price-list';
    }

    public function get_categories() {
	return [ 'vedanta' ];
    }

    protected function _register_controls() {
	$this->start_controls_section(
	'ved_section_list', [
	    'label'	 => esc_html__( 'Pricing List', 'vedanta' ),
	    'tab'	 => Controls_Manager::TAB_CONTENT,
	]
	);

	$repeater = new Repeater();
        
        $repeater->add_control(
        'ved_featured', [
            'label'        => esc_html__( 'Featured?', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'no',
        ]
        );

        $repeater->add_control(
        'ved_featured_tag_text', [
            'label'       => esc_html__( 'Featured Tag Text', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => false,
            'default'     => esc_html__( 'Featured', 'vedanta' ),
            'condition'   => [
                'ved_featured'        => 'yes'
            ]
        ]
        );

	$repeater->add_control(
	'ved_price', [
	    'label'	 => esc_html__( 'Price', 'vedanta' ),
	    'type'	 => Controls_Manager::TEXT,
	]
	);

	$repeater->add_control(
	'ved_title', [
	    'label'		 => esc_html__( 'Title & Description', 'vedanta' ),
	    'type'		 => Controls_Manager::TEXT,
	    'default'	 => '',
	    'label_block'	 => 'true',
	]
	);

	$repeater->add_control(
	'ved_item_description', [
	    'label'		 => esc_html__( 'Description', 'vedanta' ),
	    'type'		 => Controls_Manager::TEXTAREA,
	    'default'	 => '',
	    'show_label'	 => false,
	]
	);

	$repeater->add_control(
	'ved_image', [
	    'label'		 => esc_html__( 'Image', 'vedanta' ),
	    'type'		 => Controls_Manager::MEDIA,
	    'default'	 => [],
	]
	);

	$repeater->add_control(
	'ved_link', [
	    'label'		 => esc_html__( 'Link', 'vedanta' ),
	    'type'		 => Controls_Manager::URL,
	    'default'	 => [ 'url' => '#' ],
	]
	);

	$this->add_control(
	'ved_price_list', [
	    'label'		 => esc_html__( 'List Items', 'vedanta' ),
	    'type'		 => Controls_Manager::REPEATER,
	    'fields'	 => $repeater->get_controls(),
	    'default'	 => [
		[
                    'ved_featured' => 'no',
		    'ved_title'		 => esc_html__( 'First item on the list', 'vedanta' ),
		    'ved_item_description'	 => esc_html__( 'I am item content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'vedanta' ),
		    'ved_price'		 => '$20',
		    'ved_link'		 => [ 'url' => '#' ],
		],
		[
                    'ved_featured' => 'no',
		    'ved_title'		 => esc_html__( 'Second item on the list', 'vedanta' ),
		    'ved_item_description'	 => esc_html__( 'I am item content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'vedanta' ),
		    'ved_price'		 => '$9',
		    'ved_link'		 => [ 'url' => '#' ],
		],
		[
                    'ved_featured' => 'no',
		    'ved_title'		 => esc_html__( 'Third item on the list', 'vedanta' ),
		    'ved_item_description'	 => esc_html__( 'I am item content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'vedanta' ),
		    'ved_price'		 => '$32',
		    'ved_link'		 => [ 'url' => '#' ],
		],
	    ],
	    'title_field'	 => '{{{ ved_title }}}',
	]
	);
	$this->end_controls_section();

	$this->start_controls_section(
	'ved_section_list_style', [
	    'label'	 => esc_html__( 'List', 'vedanta' ),
	    'tab'	 => Controls_Manager::TAB_STYLE,
	]
	);

	$this->add_control(
	'ved_heading_title', [
	    'label'	 => esc_html__( 'Title & Price', 'vedanta' ),
	    'type'	 => Controls_Manager::HEADING,
	]
	);

	$this->add_control(
	'ved_heading_color', [
	    'label'		 => esc_html__( 'Color', 'vedanta' ),
	    'type'		 => Controls_Manager::COLOR,
            'default'	 => '#222222',
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-header' => 'color: {{VALUE}};',
	    ],
	]
	);

	$this->add_group_control(
	Group_Control_Typography::get_type(), [
	    'name'		 => 'heading_typography',
	    'selector'	 => '{{WRAPPER}} .ved-price-list-header',
	]
	);

	$this->add_control(
	'ved_heading_item_description', [
	    'label'		 => esc_html__( 'Description', 'vedanta' ),
	    'type'		 => Controls_Manager::HEADING,
	    'separator'	 => 'before',
	]
	);

	$this->add_control(
	'ved_description_color', [
	    'label'		 => esc_html__( 'Color', 'vedanta' ),
	    'type'		 => Controls_Manager::COLOR,
	    'default'	 => '#777777',
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-description' => 'color: {{VALUE}};',
	    ],
	]
	);

	$this->add_group_control(
	Group_Control_Typography::get_type(), [
	    'name'		 => 'description_typography',
	    'selector'	 => '{{WRAPPER}} .ved-price-list-description',
	]
	);

	$this->add_control(
	'ved_heading_separator', [
	    'label'		 => esc_html__( 'Separator', 'vedanta' ),
	    'type'		 => Controls_Manager::HEADING,
	    'separator'	 => 'before',
	]
	);

	$this->add_control(
	'ved_separator_style', [
	    'label'		 => esc_html__( 'Style', 'vedanta' ),
	    'type'		 => Controls_Manager::SELECT,
	    'options'	 => [
		'solid'	 => esc_html__( 'Solid', 'vedanta' ),
		'dotted' => esc_html__( 'Dotted', 'vedanta' ),
		'dashed' => esc_html__( 'Dashed', 'vedanta' ),
		'double' => esc_html__( 'Double', 'vedanta' ),
		'none'	 => esc_html__( 'None', 'vedanta' ),
	    ],
	    'default'	 => 'dotted',
	    'render_type'	 => 'template',
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-separator' => 'border-bottom-style: {{VALUE}}',
	    ],
	]
	);

	$this->add_control(
	'ved_separator_weight', [
	    'label'		 => esc_html__( 'Weight', 'vedanta' ),
	    'type'		 => Controls_Manager::SLIDER,
	    'range'		 => [
		'px' => [
		    'max' => 10,
		],
	    ],
	    'condition'	 => [
		'ved_separator_style!' => 'none',
	    ],
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-separator' => 'border-bottom-width: {{SIZE}}{{UNIT}}',
	    ],
	    'default'	 => [
		'size' => 2,
	    ],
	]
	);

	$this->add_control(
	'ved_separator_color', [
	    'label'		 => esc_html__( 'Color', 'vedanta' ),
	    'type'		 => Controls_Manager::COLOR,
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-separator' => 'border-bottom-color: {{VALUE}};',
	    ],
	    'condition'	 => [
		'ved_separator_style!' => 'none',
	    ],
	]
	);

	$this->add_control(
	'ved_separator_spacing', [
	    'label'		 => esc_html__( 'Spacing', 'vedanta' ),
	    'type'		 => Controls_Manager::SLIDER,
	    'range'		 => [
		'px' => [
		    'max' => 40,
		],
	    ],
	    'condition'	 => [
		'ved_separator_style!' => 'none',
	    ],
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-separator' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
	    ],
	]
	);

	$this->end_controls_section();

	$this->start_controls_section(
	'ved_section_image_style', [
	    'label'		 => esc_html__( 'Image', 'vedanta' ),
	    'tab'		 => Controls_Manager::TAB_STYLE,
	    'show_label'	 => false,
	]
	);

	$this->add_group_control(
	Group_Control_Image_Size::get_type(), [
	    'name'		 => 'image_size',
	    'default'	 => 'thumbnail',
	]
	);

	$this->add_control(
	'ved_border_radius', [
	    'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
	    'type'		 => Controls_Manager::DIMENSIONS,
	    'size_units'	 => [ 'px', '%' ],
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	    ],
	]
	);

	$this->add_control(
	'ved_image_spacing', [
	    'label'		 => esc_html__( 'Spacing', 'vedanta' ),
	    'type'		 => Controls_Manager::SLIDER,
	    'range'		 => [
		'px' => [
		    'max' => 50,
		],
	    ],
	    'selectors'	 => [
		'body.rtl {{WRAPPER}} .ved-price-list-image'					 => 'padding-left: calc({{SIZE}}{{UNIT}}/2);',
		'body.rtl {{WRAPPER}} .ved-price-list-image + .ved-price-list-text'		 => 'padding-right: calc({{SIZE}}{{UNIT}}/2);',
		'body:not(.rtl) {{WRAPPER}} .ved-price-list-image'				 => 'padding-right: calc({{SIZE}}{{UNIT}}/2);',
		'body:not(.rtl) {{WRAPPER}} .ved-price-list-image + .ved-price-list-text'	 => 'padding-left: calc({{SIZE}}{{UNIT}}/2);',
	    ],
	    'default'	 => [
		'size' => 20,
	    ],
	]
	);

	$this->end_controls_section();

	$this->start_controls_section(
	'ved_section_item_style', [
	    'label'		 => esc_html__( 'Item', 'vedanta' ),
	    'tab'		 => Controls_Manager::TAB_STYLE,
	    'show_label'	 => false,
	]
	);

	$this->add_control(
	'ved_row_gap', [
	    'label'		 => esc_html__( 'Rows Gap', 'vedanta' ),
	    'type'		 => Controls_Manager::SLIDER,
	    'range'		 => [
		'px'	 => [
		    'max' => 50,
		],
		'em'	 => [
		    'max'	 => 5,
		    'step'	 => 0.1,
		],
	    ],
	    'size_units'	 => [ 'px', 'em' ],
	    'selectors'	 => [
		'{{WRAPPER}} .ved-price-list li:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
	    ],
	    'default'	 => [
		'size' => 20,
	    ],
	]
	);

	$this->add_control(
	'ved_vertical_align', [
	    'label'			 => esc_html__( 'Vertical Align', 'vedanta' ),
	    'type'			 => Controls_Manager::SELECT,
	    'options'		 => [
		'top'	 => esc_html__( 'Top', 'vedanta' ),
		'bottom' => esc_html__( 'Bottom', 'vedanta' ),
		'center' => esc_html__( 'Center', 'vedanta' ),
	    ],
	    'selectors'		 => [
		'{{WRAPPER}} .ved-price-list-item' => 'align-items: {{VALUE}};',
	    ],
	    'selectors_dictionary'	 => [
		'top'	 => 'flex-start',
		'bottom' => 'flex-end',
	    ],
	    'default'		 => 'top',
	]
	);

	$this->end_controls_section();
    }

    private function render_image( $item, $instance ) {
	$image_id	 = $item[ 'ved_image' ][ 'id' ];
	$image_size	 = $instance[ 'image_size_size' ];
	if ( 'custom' === $image_size ) {
	    $image_src = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'image_size', $instance );
	} else {
	    $image_src	 = wp_get_attachment_image_src( $image_id, $image_size );
	    $image_src	 = $image_src[ 0 ];
	}

	return sprintf( '<img src="%s" alt="%s" />', $image_src, $item[ 'ved_title' ] );
    }

    private function render_item_header( $item ) {
	$url = $item[ 'ved_link' ][ 'url' ];

	$item_id = $item[ '_id' ];
        
    $feature_wrap = '';
    if($item[ 'ved_featured' ] == 'yes') {
       $feature_wrap = '<div class="featured-highlight"><span class="highlight-box"><b>'.$item['ved_featured_tag_text'].'</b></span>';
    }

	if ( $url ) {
	    $unique_link_id = 'item-link-' . $item_id;

	    $this->add_render_attribute( $unique_link_id, [
		'href'	 => $url,
		'class'	 => 'ved-price-list-item',
	    ] );

	    if ( $item[ 'ved_link' ][ 'is_external' ] ) {
		$this->add_render_attribute( $unique_link_id, 'target', '_blank' );
	    }

	    return '<li>'.$feature_wrap.'<a ' . $this->get_render_attribute_string( $unique_link_id ) . '>';
	} else {
	    return '<li class="ved-price-list-item">'.$feature_wrap;
	}
    }

    private function render_item_footer( $item ) {
        $feature_wrap = '';
    if($item[ 'ved_featured' ] == 'yes') {
       $feature_wrap = '</div>';
    }
	if ( $item[ 'ved_link' ][ 'url' ] ) {
	    return '</a>'.$feature_wrap.'</li>';
	} else {
	    return $feature_wrap.'</li>';
	}
    }

    protected function render() {
	$settings = $this->get_settings();
	?>

	<ul class="ved-price-list">

	    <?php foreach ( $settings[ 'ved_price_list' ] as $item ) : ?>
		<?php if ( ! empty( $item[ 'ved_title' ] ) || ! empty( $item[ 'ved_price' ] ) || ! empty( $item[ 'ved_item_description' ] ) ) : ?>
		    <?php echo $this->render_item_header( $item ); ?>
			<?php if ( ! empty( $item[ 'ved_image' ][ 'url' ] ) ) : ?>
		        <div class="ved-price-list-image">
			<?php echo $this->render_image( $item, $settings ); ?>
		        </div>
		<?php endif; ?>

		    <div class="ved-price-list-text">
			    <?php if ( ! empty( $item[ 'ved_title' ] ) || ! empty( $item[ 'ved_price' ] ) ) : ?>
		    	<div class="ved-price-list-header">
				<?php if ( ! empty( $item[ 'ved_title' ] ) ) : ?>
				    <span class="ved-price-list-title"><?php echo $item[ 'ved_title' ]; ?></span>
				<?php endif; ?>
				<?php if ( 'none' != $settings[ 'ved_separator_style' ] ) : ?>
				    <span class="ved-price-list-separator"></span>
				<?php endif; ?>
				<?php if ( ! empty( $item[ 'ved_price' ] ) ) : ?>
				    <span class="ved-price-list-price"><?php echo $item[ 'ved_price' ]; ?></span>
			    <?php endif; ?>
		    	</div>
			<?php endif; ?>
			<?php if ( ! empty( $item[ 'ved_item_description' ] ) ) : ?>
		    	<p class="ved-price-list-description"><?php echo $item[ 'ved_item_description' ]; ?></p>
		    <?php endif; ?>
		    </div>
		    <?php echo $this->render_item_footer( $item ); ?>
		<?php endif; ?>
	<?php endforeach; ?>

	</ul>

	<?php
    }

    protected function _content_template() {
            
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Pricing_List() );
