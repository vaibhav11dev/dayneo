<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_Woo_Product_Deal extends Widget_Base {

    public $base;

    public function get_name() {
        return 'ved-woo-product-deal';
    }

    public function get_title() {
        return esc_html__( 'Ved Product Deal', 'vedanta' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Ved Product element', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_product_deal_title', [
            'label'       => esc_html__( 'Heading Title', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Deal Of The Day', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_product_deal_count', [
            'label'   => esc_html__( 'No of Products', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_deal_show_savings', [
            'label'        => esc_html__( 'Show Savings Details', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Enable', 'vedanta' ),
            'label_off'    => esc_html__( 'Disable', 'vedanta' ),
            'return_value' => true,
            'default'      => true,
        ]
        );

        $this->add_control(
        'ved_product_deal_savings_in', [
            'label'   => esc_html__( 'Savings in', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'amount'     => esc_html__( 'Amount', 'vedanta' ),
                'percentage' => esc_html__( 'Percentage', 'vedanta' ),
            ],
            'default' => 'percentage',
        ]
        );

        $this->add_control(
        'ved_product_deal_savings_text', [
            'label' => esc_html__( 'Savings Text', 'vedanta' ),
            'type'  => Controls_Manager::TEXT,
        ]
        );

        $this->add_control(
        'ved_product_deal_product_choice', [
            'label'   => esc_html__( 'Product Choice', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'recent'   => esc_html__( 'Recent', 'vedanta' ),
                'random'   => esc_html__( 'Random', 'vedanta' ),
                'specific' => esc_html__( 'Specific', 'vedanta' ),
            ],
            'default' => 'recent',
        ]
        );

        $this->add_control(
        'ved_product_deal_product_id', [
            'label'       => esc_html__( 'Product id or SKUs', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'placeholder' => esc_html__( 'Enter IDs/SKUs separate by comma(,).', 'vedanta' ),
            'condition'   => [
                'ved_product_deal_product_choice' => 'specific',
            ],
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_product_deal_slider_settings', [
            'label' => esc_html__( 'Product Deal Slider Settings', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_product_deal_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_deal_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_product_deal_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_deal_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_deal_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_deal_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_deal_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();
    }

    private function vedanta_woo_product_deal( $args = array() ) {

        $defaults = array(
            'show_savings'  => true,
            'savings_in'    => 'amount',
            'savings_text'  => esc_html__( 'Save', 'vedanta' ),
        );

        if ( isset( $args[ 'product_choice' ] ) ) {
            switch ( $args[ 'product_choice' ] ) {
                case 'random':
                    $args[ 'orderby' ]  = 'rand';
                    break;
                case 'recent':
                    $args[ 'orderby' ]  = 'date';
                    $args[ 'order' ]    = 'DESC';
                    break;
                case 'specific':
                    $args[ 'orderby' ]  = 'post__in';
                    $args[ 'ids' ]      = $args[ 'product_id' ];
                    $args[ 'post__in' ] = array_map( 'trim', explode( ',', $args[ 'product_id' ] ) );
                    break;
            }
        }

        $args     = wp_parse_args( array( 'per_page' => $args[ 'no_of_product' ] ), $args );
        $args     = wp_parse_args( $args, $defaults );
        $products = vedanta_sale_products( $args );

        extract( $args );

        if ( $products->have_posts() ) {

            while ( $products->have_posts() ) : $products->the_post();
                if ( $show_savings ) : ?>
                    <div class="savings">
                        <span class="savings-text">
                            <?php
                                global $product;
                                echo sprintf( '%s %s', $savings_text, vedanta_get_savings_on_sale( $product, $savings_in ) );
                            ?>
                        </span>
                    </div>

                <?php endif; ?>

                <div class="onsale-products">
                    <?php ved_get_template_part( 'woocommerce/content', 'onsale-product' ); ?>
                </div>

                <?php
                endwhile;

                woocommerce_reset_loop();
                wp_reset_postdata();
            }
        }

    protected function render() {
                $settings = $this->get_settings();

                // Slider Options
                $desk_items      = $settings[ 'ved_product_deal_desk_items' ];
				$desk_small_items      = $settings[ 'ved_product_deal_desk_small_items' ];
				$tab_items      = $settings[ 'ved_product_deal_tab_items' ];
				$mob_items      = $settings[ 'ved_product_deal_mob_items' ];
                $autoplay   = $settings[ 'ved_product_deal_slider_autoplay' ];
                $navigation = $settings[ 'ved_product_deal_slider_navigation' ];
                $pagination = $settings[ 'ved_product_deal_slider_pagination' ];

                $deal_args = array(
                    'no_of_product'   => isset( $settings[ 'ved_product_deal_count' ] ) ? $settings[ 'ved_product_deal_count' ] : '4',
                    'show_savings'   => isset( $settings[ 'ved_product_deal_show_savings' ] ) ? $settings[ 'ved_product_deal_show_savings' ] : '',
                    'savings_in'     => isset( $settings[ 'ved_product_deal_savings_in' ] ) ? $settings[ 'ved_product_deal_savings_in' ] : '',
                    'savings_text'   => isset( $settings[ 'ved_product_deal_savings_text' ] ) ? $settings[ 'ved_product_deal_savings_text' ] : '',
                    'product_choice' => isset( $settings[ 'ved_product_deal_product_choice' ] ) ? $settings[ 'ved_product_deal_product_choice' ] : '',
                    'product_id'     => isset( $settings[ 'ved_product_deal_product_id' ] ) ? $settings[ 'ved_product_deal_product_id' ] : '',
                );
                
        if ( isset( $settings[ 'ved_product_deal_title' ] ) && $settings[ 'ved_product_deal_title' ] ) {
        ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $settings[ 'ved_product_deal_title' ] ); ?></h3>
            </div>
        <?php } ?>

        <div id="ved-woo-product-deal-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-product-deal">
            <?php $this->vedanta_woo_product_deal( $deal_args ); ?>
        </div>

        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                var ved_deal_sld = $("#ved-woo-product-deal-<?php echo esc_attr( $this->get_id() ); ?>");
                ved_deal_sld.owlCarousel({
                    autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                    navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                    pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                    items: <?php echo $desk_items; ?>,
                    loop: false,
                    navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                    itemsDesktop : [1200,3],
                    itemsDesktopSmall : [1199,<?php echo $desk_small_items; ?>],
                    itemsTablet: [991,<?php echo $tab_items; ?>],
                    itemsTabletSmall: [767,<?php echo $mob_items; ?>] ,
                    itemsMobile : [320,<?php echo $mob_items; ?>]
                });
            });
        </script>
        <?php
    }

    protected function _content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Woo_Product_Deal() );
