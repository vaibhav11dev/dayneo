<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class Widget_Ved_Recent_Work extends Widget_Base {

	public function get_name() {
		return 'ved-recent-work';
	}

	public function get_title() {
		return __( 'Ved Recent Work', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
		'ved_section_recent_work_filters', [
			'label' => __( 'Recent Work Settings', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_recent_work_filter', [
			'label'		 => esc_html__( 'Display Filter', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'label_on'	 => __( 'yes', 'vedanta' ),
			'label_off'	 => __( 'no', 'vedanta' ),
			'default'	 => 'yes',
			'return_value'	 => 'yes',
		]
		);

		$this->add_control(
		'ved_recent_work_column', [
			'label'		 => esc_html__( 'Number of Column', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'options'	 => [
				'2'	 => 'Two Column',
				'3'	 => 'Three Column',
				'4'	 => 'Four Column',
			],
			'default'	 => '3',
		]
		);

		$this->add_control(
		'ved_recent_work_style', [
			'label'		 => esc_html__( 'Style', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'options'	 => [
				'grid_no_space'	 => 'Grid No Space',
				'grid'		 => 'Grid',
			],
			'default'	 => 'grid_no_space',
		]
		);

		$this->add_control(
		'ved_recent_work_count', [
			'label'		 => __( 'Number of Recent Works', 'vedanta' ),
			'type'		 => Controls_Manager::NUMBER,
			'default'	 => '4'
		]
		);


		$this->add_control(
		'ved_ved_posts_count_offset', [
			'label'		 => __( 'Recent Work Offset', 'vedanta' ),
			'type'		 => Controls_Manager::NUMBER,
			'default'	 => '0'
		]
		);

		$this->add_control(
		'ved_ved_posts_count_orderby', [
			'label'		 => __( 'Order By', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'options'	 => ved_get_post_orderby_options(),
			'default'	 => 'date',
		]
		);

		$this->add_control(
		'ved_ved_posts_count_order', [
			'label'		 => __( 'Order', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'options'	 => [
				'asc'	 => 'Ascending',
				'desc'	 => 'Descending'
			],
			'default'	 => 'desc',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_recent_work_layout', [
			'label' => __( 'Layout Settings', 'vedanta' )
		]
		);

		$this->add_group_control(
		Group_Control_Image_Size::get_type(), [
			'name'		 => 'image',
			'exclude'	 => [ 'custom' ],
			'default'	 => 'large',
		]
		);

		$this->add_control(
		'ved_show_title', [
			'label'		 => __( 'Show Title', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'options'	 => [
				'1'	 => [
					'title'	 => __( 'Yes', 'vedanta' ),
					'icon'	 => 'fa fa-check',
				],
				'0'	 => [
					'title'	 => __( 'No', 'vedanta' ),
					'icon'	 => 'fa fa-ban',
				]
			],
			'default'	 => '1'
		]
		);

		$this->add_control(
		'ved_show_categories', [
			'label'		 => __( 'Show categories', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'options'	 => [
				'1'	 => [
					'title'	 => __( 'Yes', 'vedanta' ),
					'icon'	 => 'fa fa-check',
				],
				'0'	 => [
					'title'	 => __( 'No', 'vedanta' ),
					'icon'	 => 'fa fa-ban',
				]
			],
			'default'	 => '1'
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_recent_work_style', [
			'label'	 => __( 'Recent Work Block Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);


		$this->add_control(
		'ved_recent_work_overlay_color', [
			'label'		 => __( 'Recent Work Overlay Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .work-overlay' => 'background-color: {{VALUE}}',
			]
		]
		);

		$this->add_responsive_control(
		'ved_recent_work_alignment', [
			'label'		 => __( 'Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'options'	 => [
				'left'	 => [
					'title'	 => __( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => __( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => __( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				]
			],
			'default'	 => 'left',
			'selectors'	 => [
				'{{WRAPPER}} .work-caption' => 'text-align: {{VALUE}};',
			]
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_typography', [
			'label'	 => __( 'Color & Typography', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_recent_work_title_style', [
			'label'		 => __( 'Title Style', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before',
		]
		);



		$this->add_control(
		'ved_recent_work_title_color', [
			'label'		 => __( 'Title Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .work-title' => 'color: {{VALUE}};',
			]
		]
		);



		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_recent_work_title_typography',
			'label'		 => __( 'Typography', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .work-title',
		]
		);

		$this->add_control(
		'ved_recent_work_categories_style', [
			'label'		 => __( 'Categories Style', 'vedanta' ),
			'type'		 => Controls_Manager::HEADING,
			'separator'	 => 'before',
		]
		);

		$this->add_control(
		'ved_recent_work_categories_color', [
			'label'		 => __( 'Categories Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .work-category' => 'color: {{VALUE}};',
			]
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_recent_work_categories_typography',
			'label'		 => __( 'Typography', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .work-category',
		]
		);


		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_recent_work_filter', [
			'label'		 => __( 'Filter Style', 'vedanta' ),
			'tab'		 => Controls_Manager::TAB_STYLE,
			'condition'	 => [
				'ved_recent_work_filter' => 'yes'
			]
		]
		);

		$this->add_responsive_control(
		'ved_recent_work_filter_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .filters' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_recent_work_filter_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .filters' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);
		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_recent_work_filter_typography',
			'selector'	 => '{{WRAPPER}} .filters li',
		]
		);

		$this->add_responsive_control(
		'ved_recent_work_filter_alignment', [
			'label'		 => __( 'Button Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'options'	 => [
				'left'	 => [
					'title'	 => __( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => __( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => __( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				]
			],
			'default'	 => 'center',
			'selectors'	 => [
				'{{WRAPPER}} .filters' => 'text-align: {{VALUE}};',
			]
		]
		);

		$this->start_controls_tabs( 'ved_recent_work_filter_tabs' );

		// Normal State Tab
		$this->start_controls_tab( 'ved_recent_work_filter_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );

		$this->add_control(
		'ved_recent_work_filter_normal_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .filters li a' => 'color: {{VALUE}};',
			],
		]
		);

		$this->end_controls_tab();

		// Hover State Tab
		$this->start_controls_tab( 'ved_recent_work_filter_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );

		$this->add_control(
		'ved_recent_work_filter_hover_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .filters li a:hover' => 'color: {{VALUE}};',
			],
		]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		$recent_work_args = ved_get_recent_work_settings( $settings );

		$recent_works = ved_get_post_data( $recent_work_args );

		$all_terms = get_terms( 'portfolio_category' );
		if ( is_array( $all_terms ) && ! empty( $all_terms ) && $settings[ 'ved_recent_work_filter' ] == 'yes' ):
			?>
			<div class="row">
				<div class="col-sm-12">
					<ul id="filters" class="portfolio-tabs filters">
						<li><a href="#" class="current" data-filter="*"><?php echo __( 'All', 'vedanta' ); ?></a></li>
			<?php foreach ( $all_terms as $term ): ?>
							<li><a data-filter=".<?php echo esc_attr($term->slug); ?>" href="#"><?php echo esc_html($term->name); ?></a></li>
			<?php endforeach; ?>
					</ul>
				</div>
			</div>
		<?php endif; ?>

		<div class="works-grid-wrapper">

		<?php
		$portfolio_style = '';
		if ( $settings[ 'ved_recent_work_style' ] == 'grid' ) {
			$portfolio_style = 'works-grid-gutter';
		}
		if ( $settings[ 'ved_recent_work_column' ] == '3' || $settings[ 'ved_recent_work_column' ] == '4' ) {
			$portfolio_style .= ' works-grid-' . $settings[ 'ved_recent_work_column' ];
		}
		?>

			<div id="works-grid" class="works-grid <?php echo esc_attr($portfolio_style); ?>">
		<?php
		if ( count( $recent_works ) ) :
			foreach ( $recent_works as $recent_work ) {
				setup_postdata( $recent_works );

				if ( has_post_thumbnail( $recent_work->ID ) ) {

					$item_classes	 = '';
					$item_cats	 = get_the_terms( $recent_work->ID, 'portfolio_category' );
					if ( $item_cats ):
						foreach ( $item_cats as $item_cat ) {
							$item_classes .= urldecode( $item_cat->slug ) . ' ';
						}
					endif;
					?>
							<article class="work-item <?php echo esc_attr($item_classes); ?>">
								<div class="work-wrapper">
                                                                    <img alt="<?php echo esc_attr(get_the_title( $recent_work->ID )); ?>" src="<?php echo esc_url(get_the_post_thumbnail_url( $recent_work->ID, $settings[ 'image_size' ] )) ?>">
									<div class="work-overlay">
										<div class="work-caption">
						<?php if ( $settings[ 'ved_show_title' ] ) { ?>
												<h6 class="work-title"><?php echo esc_html(get_the_title( $recent_work->ID )); ?></h6>
							<?php
						}
						if ( $settings[ 'ved_show_categories' ] ) {
							?>
												<span class="work-category"><?php echo $item_classes; ?></span>
							<?php
						}
						?>
										</div>
									</div>
									<a href="<?php echo the_permalink( $recent_work->ID ); ?>" class="work-link"></a>
								</div>
							</article>
							<?php
						}
					}

					/* Restore original Post Data */
					wp_reset_postdata();
				endif;
				?>

			</div>

		</div>

		<?php
	}

	protected function content_template() {
		?>

								<?php
							}

						}

						Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Recent_Work() );
						