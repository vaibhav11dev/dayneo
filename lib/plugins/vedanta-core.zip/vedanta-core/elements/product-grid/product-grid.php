<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_ved_Product_Grid extends Widget_Base {

	public function get_name() {
		return 'ved-woocommerce';
	}

	public function get_title() {
		return esc_html__( 'Ved Product Grid', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {

		// Content Controls
		$this->start_controls_section(
		'ved_section_product_grid_settings', [
			'label' => esc_html__( 'Product Settings', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_product_grid_product_filter', [
			'label'		 => esc_html__( 'Filter By', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'recent-products',
			'options'	 => [
				'recent-products'	 => esc_html__( 'Recent Products', 'vedanta' ),
				'featured-products'	 => esc_html__( 'Featured Products', 'vedanta' ),
				'best-selling-products'	 => esc_html__( 'Best Selling Products', 'vedanta' ),
				'sale-products'		 => esc_html__( 'Sale Products', 'vedanta' ),
				'top-products'		 => esc_html__( 'Top Rated Products', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_product_grid_column', [
			'label'		 => esc_html__( 'Columns', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => '4',
			'options'	 => [
				'2'	 => esc_html__( '2', 'vedanta' ),
				'3'	 => esc_html__( '3', 'vedanta' ),
				'4'	 => esc_html__( '4', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_product_grid_products_count', [
			'label'		 => __( 'Products Count', 'vedanta' ),
			'type'		 => Controls_Manager::NUMBER,
			'default'	 => 4,
			'min'		 => 1,
			'max'		 => 1000,
			'step'		 => 1,
		]
		);

		$this->add_control(
		'ved_product_grid_categories', [
			'label'		 => esc_html__( 'Product Categories', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT2,
			'label_block'	 => true,
			'multiple'	 => true,
			'options'	 => ved_woocommerce_product_categories(),
		]
		);

		$this->add_control(
		'ved_product_grid_rating', [
			'label'		 => esc_html__( 'Show Product Rating?', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'return_value'	 => 'yes',
			'default'	 => 'yes',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_product_grid_typography', [
			'label'	 => esc_html__( 'Color &amp; Typography', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_product_grid_product_title_heading', [
			'label'	 => __( 'Product Title', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_product_grid_product_title_color', [
			'label'		 => esc_html__( 'Product Title Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-product-grid .woocommerce .woocommerce-loop-product__title .woocommerce-loop-product__link' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_product_grid_product_title_typography',
			'selector'	 => '{{WRAPPER}} .ved-product-grid .woocommerce .woocommerce-loop-product__title .woocommerce-loop-product__link',
		]
		);

		$this->add_control(
		'ved_product_grid_product_price_heading', [
			'label'	 => __( 'Product Price', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);


		$this->add_control(
		'ved_product_grid_product_price_color', [
			'label'		 => esc_html__( 'Product Price Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-product-grid .woocommerce .price' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_product_grid_product_price_typography',
			'selector'	 => '{{WRAPPER}} .ved-product-grid .woocommerce .price',
		]
		);

		$this->add_control(
		'ved_product_grid_product_rating_heading', [
			'label'	 => __( 'Star Rating', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_product_grid_product_rating_color', [
			'label'		 => esc_html__( 'Rating Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#f2b01e',
			'selectors'	 => [
				'{{WRAPPER}} .ved-product-grid .woocommerce .star-rating::before'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} .ved-product-grid .woocommerce .star-rating span::before'	 => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_product_grid_product_rating_typography',
			'selector'	 => '{{WRAPPER}} .ved-product-grid .woocommerce .star-rating',
		]
		);

		$this->add_control(
		'ved_product_grid_sale_badge_heading', [
			'label'	 => __( 'Sale Badge', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_product_grid_sale_badge_color', [
			'label'		 => esc_html__( 'Sale Badge Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-product-grid:not(.ved-product-no-style) .onsale' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_product_grid_sale_badge_background', [
			'label'		 => esc_html__( 'Sale Badge Background', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#ff2a13',
			'selectors'	 => [
				'{{WRAPPER}} .ved-product-grid:not(.ved-product-no-style) .onsale' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_product_grid_sale_badge_typography',
			'selector'	 => '{{WRAPPER}} .ved-product-grid:not(.ved-product-no-style) .onsale',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings();

		$product_count		 = $this->get_settings( 'ved_product_grid_products_count' );
		$columns		 = $this->get_settings( 'ved_product_grid_column' );
		$show_rating		 = ( ($settings[ 'ved_product_grid_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
		$product_grid_classes	 = $show_rating;

		$category = $get_product_categories = $settings[ 'ved_product_grid_categories' ]; // get custom field value
		if ( $get_product_categories >= 1 ) {
			$category_ids = implode( ', ', $get_product_categories );
		} else {
			$category_ids = '';
		}
		?>



		<div id="ved-product-grid-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-product-grid <?php echo esc_attr($product_grid_classes); ?>">

		<?php if ( ($settings[ 'ved_product_grid_product_filter' ]) == 'recent-products' ) : ?>

			<?php echo do_shortcode( "[recent_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category_ids\"]" ) ?>

		<?php elseif ( ($settings[ 'ved_product_grid_product_filter' ]) == 'featured-products' ) : ?>

			<?php echo do_shortcode( "[featured_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" ) ?>

		<?php elseif ( ($settings[ 'ved_product_grid_product_filter' ]) == 'best-selling-products' ) : ?>

			<?php echo do_shortcode( "[best_selling_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" ) ?>

		<?php elseif ( ($settings[ 'ved_product_grid_product_filter' ]) == 'sale-products' ) : ?>

			<?php echo do_shortcode( "[sale_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" ) ?>

		<?php else: ?>

			<?php echo do_shortcode( "[top_rated_products per_page=\"$product_count\" columns=\"$columns\" category=\"$category\"]" ) ?>

		<?php endif; ?>

			<div class="clearfix"></div>
		</div>


			<?php
		}

		protected function content_template() {
			?>


			<?php
		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Widget_ved_Product_Grid() );
	