<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Slider_Script extends Widget_Base {

	public function get_name() {
		return 'ved-slider-script';
	}

	public function get_title() {
		return __( 'Ved Slider Script', 'elementor' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {

		/**
		 * Slider Script Settings
		 */
		$this->start_controls_section(
		'ved_section_slider_script_settings', [
			'label' => esc_html__( 'Slider Script Settings', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_slider_script_id', [
			'label'		 => __( 'Slider Script ID', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'dynamic'	 => [
				'active' => true,
			],
			'placeholder'	 => __( 'Enter your slider ID', 'vedanta' ),
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_slider_script_autoplay', [
			'label'		 => __( 'Autoplay', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'false',
			'label_on'	 => esc_html__( 'Yes', 'vedanta' ),
			'label_off'	 => esc_html__( 'No', 'vedanta' ),
			'return_value'	 => 'true',
		]
		);

		$this->add_control(
		'ved_slider_script_pause_on_hover', [
			'label'		 => __( 'Pause On Hover', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'true',
			'label_on'	 => esc_html__( 'Yes', 'vedanta' ),
			'label_off'	 => esc_html__( 'No', 'vedanta' ),
			'return_value'	 => 'true',
		]
		);

		$this->add_control(
		'ved_slider_script_dots', [
			'label'		 => __( 'Slider Dots', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'true',
			'label_on'	 => esc_html__( 'Yes', 'vedanta' ),
			'label_off'	 => esc_html__( 'No', 'vedanta' ),
			'return_value'	 => 'true',
		]
		);

		$this->add_control(
		'ved_slider_script_button', [
			'label'		 => __( 'Slider Navigator', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'true',
			'label_on'	 => esc_html__( 'Yes', 'vedanta' ),
			'label_off'	 => esc_html__( 'No', 'vedanta' ),
			'return_value'	 => 'true',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Slider Script Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_slider_script_style_settings', [
			'label'	 => esc_html__( 'Slider Script Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_responsive_control(
		'ved_slider_script_container_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_slider_script_container_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_slider_script_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-slider-script',
		]
		);

		$this->add_control(
		'ved_slider_script_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 4,
			],
			'range'		 => [
				'px' => [
					'max' => 500,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script' => 'border-radius: {{SIZE}}px;',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_slider_script_shadow',
			'selector'	 => '{{WRAPPER}} .ved-slider-script',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Slider Script Navigator Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_filp_carousel_custom_nav_settings', [
			'label'	 => esc_html__( 'Navigator Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_slider_script_custom_nav_size', [
			'label'		 => esc_html__( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => '18'
			],
			'range'		 => [
				'px' => [
					'max' => 100,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script .owl-buttons i' => 'font-size: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_slider_script_custom_nav_color', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script .owl-buttons i' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_slider_script_custom_nav_bg_size', [
			'label'		 => esc_html__( 'Background Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 46,
			],
			'range'		 => [
				'px' => [
					'max' => 80,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script .owl-buttons .owl-prev'	 => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
				'{{WRAPPER}} .ved-slider-script .owl-buttons .owl-next'	 => 'width: {{SIZE}}px; height: {{SIZE}}px; line-height: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_slider_script_custom_nav_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 3,
			],
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script .owl-buttons .owl-prev'	 => 'border-radius: {{SIZE}}px;',
				'{{WRAPPER}} .ved-slider-script .owl-buttons .owl-next'	 => 'border-radius: {{SIZE}}px;',
			],
		]
		);

		$this->add_control(
		'ved_slider_script_custom_nav_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#fff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-slider-script .owl-buttons .owl-prev'	 => 'background: {{VALUE}};',
				'{{WRAPPER}} .ved-slider-script .owl-buttons .owl-next'	 => 'background: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_slider_script_custom_nav_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-slider-script .owl-buttons .owl-prev, {{WRAPPER}} .ved-slider-script .owl-buttons .owl-next',
		]
		);

		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_slider_script_custom_navl_shadow',
			'selector'	 => '{{WRAPPER}} .ved-slider-script .owl-buttons .owl-prev, {{WRAPPER}} .ved-slider-script .owl-buttons .owl-next',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings();
?>
			<script type="text/javascript">
				jQuery(document).ready(function ($) {
				    $("<?php echo "#".$settings[ 'ved_slider_script_id' ] ?>").owlCarousel($.extend({
							stopOnHover: <?php echo $settings[ 'ved_slider_script_pause_on_hover' ] ? 'true' : 'false'; ?>,
							navigation: <?php echo $settings[ 'ved_slider_script_button' ] ? 'true' : 'false'; ?>,
							pagination: <?php echo $settings[ 'ved_slider_script_dots' ] ? 'true' : 'false'; ?>,
							autoPlay: <?php echo $settings[ 'ved_slider_script_autoplay' ] ? 'true' : 'false'; ?>,
							loop: true,
							items: 1,
							navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'], 
							margin: 20,
							nav:true,
							responsiveClass:true,
							responsive:{
							    0:{
								items:1,
								nav:true
							    },
							    600:{
								items:2,
								nav:false
							    },
							    1000:{
								items:3,
							    }
							}
						}
				});
			</script>
			<?php
		}

		protected function content_template() {
			
		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Widget_Slider_Script() );
	