<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

class Widget_Ved_Post_Block extends Widget_Base {

    public function get_name() {
        return 'ved-post-block';
    }

    public function get_title() {
        return esc_html__( 'Ved Post Block', 'vedanta' );
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
        'ved_section_post_block_filters', [
            'label' => esc_html__( 'Post Settings', 'vedanta' )
        ]
        );

        $this->add_control(
        'ved_section_post_block_title', [
            'label'       => esc_html__( 'Title', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Title Here', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_post_category', [
            'label'       => esc_html__( 'Categories', 'vedanta' ),
            'type'        => Controls_Manager::SELECT2,
            'label_block' => true,
            'multiple'    => true,
            'options'     => ved_post_type_categories(),
        ]
        );
        
        $this->add_control(
        'ved_post_type', [
            'label'   => esc_html__( 'Layout Type', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'slider',
            'options' => [
                'grid'   => esc_html__( 'grid', 'vedanta' ),
                'slider' => esc_html__( 'Slider', 'vedanta' ),
            ],
        ]
        );

        $this->add_control(
        'ved_post_column', [
            'label'   => esc_html__( 'Number of Column', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                '1' => 'One Column',
                '2' => 'Two Column',
                '3' => 'Three Column',
                '4' => 'Four Column',
            ],
            'default' => '3',
            'condition'   => [
                'ved_post_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_posts_count', [
            'label'   => esc_html__( 'Number of Posts', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => '4'
        ]
        );


        $this->add_control(
        'ved_post_offset', [
            'label'   => esc_html__( 'Post Offset', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => '0'
        ]
        );

        $this->add_control(
        'ved_post_orderby', [
            'label'   => esc_html__( 'Order By', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'options' => ved_get_post_orderby_options(),
            'default' => 'date',
        ]
        );

        $this->add_control(
        'ved_post_order', [
            'label'   => esc_html__( 'Order', 'vedanta' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'asc'  => 'Ascending',
                'desc' => 'Descending'
            ],
            'default' => 'desc',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_post_block_layout', [
            'label' => esc_html__( 'Layout Settings', 'vedanta' )
        ]
        );

        $this->add_control(
        'ved_post_block_show_read_more', [
            'label'   => esc_html__( 'Show Read More Button', 'vedanta' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'vedanta' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'vedanta' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '0',
            'condition'   => [
                'ved_post_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_show_read_more_text', [
            'label'       => esc_html__( 'Label Text', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => false,
            'default'     => esc_html__( 'Read all news', 'vedanta' ),
            'condition'   => [
                'ved_post_block_show_read_more' => '1',
                'ved_post_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_show_image', [
            'label'   => esc_html__( 'Show Image', 'vedanta' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'vedanta' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'vedanta' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );

        $this->add_group_control(
        Group_Control_Image_Size::get_type(), [
            'name'      => 'image',
            'exclude'   => [ 'custom' ],
            'default'   => 'large',
            'condition' => [
                'ved_show_image' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_show_title', [
            'label'   => esc_html__( 'Show Title', 'vedanta' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'vedanta' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'vedanta' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );

        $this->add_control(
        'ved_show_excerpt', [
            'label'   => esc_html__( 'Show excerpt', 'vedanta' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'vedanta' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'vedanta' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );


        $this->add_control(
        'ved_excerpt_length', [
            'label'     => esc_html__( 'Excerpt Words', 'vedanta' ),
            'type'      => Controls_Manager::NUMBER,
            'default'   => '30',
            'condition' => [
                'ved_show_excerpt' => '1',
            ]
        ]
        );


        $this->add_control(
        'ved_show_meta', [
            'label'   => esc_html__( 'Show Meta', 'vedanta' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'vedanta' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'vedanta' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );


        $this->add_control(
        'ved_post_block_meta_position', [
            'label'     => esc_html__( 'Meta Position', 'vedanta' ),
            'type'      => Controls_Manager::SELECT,
            'default'   => 'meta-entry-header',
            'options'   => [
                'meta-entry-header' => esc_html__( 'Entry Header', 'vedanta' ),
                'meta-entry-footer' => esc_html__( 'Entry Footer', 'vedanta' ),
            ],
            'condition' => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_date', [
            'label'        => esc_html__( 'Display Meta Dates', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'vedanta' ),
            'label_off'    => esc_html__( 'no', 'vedanta' ),
            'default'      => 'yes',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_author', [
            'label'        => esc_html__( 'Display Meta Author', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'vedanta' ),
            'label_off'    => esc_html__( 'no', 'vedanta' ),
            'default'      => 'yes',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_avtar', [
            'label'        => esc_html__( 'Display Meta Avtar', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'vedanta' ),
            'label_off'    => esc_html__( 'no', 'vedanta' ),
            'default'      => 'no',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_tags', [
            'label'        => esc_html__( 'Display Meta Tags', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'vedanta' ),
            'label_off'    => esc_html__( 'no', 'vedanta' ),
            'default'      => 'no',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_comments', [
            'label'        => esc_html__( 'Display Meta Comments', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'vedanta' ),
            'label_off'    => esc_html__( 'no', 'vedanta' ),
            'default'      => 'no',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_post_slider_settings', [
            'label' => esc_html__( 'Post Slider Settings', 'vedanta' ),
            'condition'    => [
                'ved_post_type' => 'slider',
            ]
        ]
        );

        $this->add_control(
        'ved_post_slider_items', [
            'label'   => esc_html__( 'Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_post_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_post_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_post_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_post_block_style', [
            'label' => esc_html__( 'Post Block Style', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );


        $this->add_control(
        'ved_post_block_bg_color', [
            'label'     => esc_html__( 'Post Background Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f8f8f8',
            'selectors' => [
                '{{WRAPPER}} .ved-post-item' => 'background-color: {{VALUE}}',
            ]
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_post_block_border',
            'label'    => esc_html__( 'Border', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-post-item',
        ]
        );

        $this->add_control(
        'ved_post_block_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'vedanta' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .ved-post-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'     => 'ved_post_block_box_shadow',
            'selector' => '{{WRAPPER}} .ved-post-item',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_typography', [
            'label' => esc_html__( 'Color & Typography', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_post_block_title_style', [
            'label'     => esc_html__( 'Title Style', 'vedanta' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
        );

        $this->add_control(
        'ved_post_block_title_color', [
            'label'     => esc_html__( 'Title Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-post-title, {{WRAPPER}} .ved-post-title a' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_title_hover_color', [
            'label'     => esc_html__( 'Title Hover Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#3ab54a',
            'selectors' => [
                '{{WRAPPER}} .ved-post-title:hover, {{WRAPPER}} .ved-post-title a:hover' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_title_alignment', [
            'label'     => esc_html__( 'Title Alignment', 'vedanta' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [
                    'title' => esc_html__( 'Left', 'vedanta' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'vedanta' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'  => [
                    'title' => esc_html__( 'Right', 'vedanta' ),
                    'icon'  => 'fa fa-align-right',
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-title' => 'text-align: {{VALUE}};',
            ]
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_title_typography',
            'label'    => esc_html__( 'Typography', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-post-title',
        ]
        );

        $this->add_control(
        'ved_post_block_excerpt_style', [
            'label'     => esc_html__( 'Excerpt Style', 'vedanta' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
        );

        $this->add_control(
        'ved_post_block_excerpt_color', [
            'label'     => esc_html__( 'Excerpt Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#777777',
            'selectors' => [
                '{{WRAPPER}} .ved-post-excerpt p' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_excerpt_alignment', [
            'label'     => esc_html__( 'Excerpt Alignment', 'vedanta' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'    => [
                    'title' => esc_html__( 'Left', 'vedanta' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center'  => [
                    'title' => esc_html__( 'Center', 'vedanta' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'   => [
                    'title' => esc_html__( 'Right', 'vedanta' ),
                    'icon'  => 'fa fa-align-right',
                ],
                'justify' => [
                    'title' => esc_html__( 'Justified', 'vedanta' ),
                    'icon'  => 'fa fa-align-justify',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-excerpt p' => 'text-align: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_excerpt_typography',
            'label'    => esc_html__( 'excerpt Typography', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-post-excerpt p',
        ]
        );


        $this->add_control(
        'ved_post_block_meta_style', [
            'label'     => esc_html__( 'Meta Style', 'vedanta' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
        );

        $this->add_control(
        'ved_post_block_meta_color', [
            'label'     => esc_html__( 'Meta Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#999',
            'selectors' => [
                '{{WRAPPER}} .ved-post-meta > li' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_meta_alignment', [
            'label'     => esc_html__( 'Meta Alignment', 'vedanta' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'    => [
                    'title' => esc_html__( 'Left', 'vedanta' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center'  => [
                    'title' => esc_html__( 'Center', 'vedanta' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'   => [
                    'title' => esc_html__( 'Right', 'vedanta' ),
                    'icon'  => 'fa fa-align-right',
                ],
                'justify' => [
                    'title' => esc_html__( 'Justified', 'vedanta' ),
                    'icon'  => 'fa fa-align-justify',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-meta' => 'text-align: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_meta_typography',
            'label'    => esc_html__( 'Excerpt Typography', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-post-meta ul li a',
        ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_read_more_btn', [
            'label'     => esc_html__( 'Load More Button Style', 'vedanta' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [
                'ved_post_block_show_read_more' => '1'
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_read_more_btn_padding', [
            'label'      => esc_html__( 'Padding', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-read-more-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_read_more_btn_margin', [
            'label'      => esc_html__( 'Margin', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-read-more-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_read_more_btn_typography',
            'selector' => '{{WRAPPER}} .ved-read-more-button',
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_read_more_btn_alignment', [
            'label'     => esc_html__( 'Button Alignment', 'vedanta' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [
                    'title' => esc_html__( 'Left', 'vedanta' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'vedanta' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'  => [
                    'title' => esc_html__( 'Right', 'vedanta' ),
                    'icon'  => 'fa fa-align-right',
                ]
            ],
            'default'   => 'center',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button-wrap' => 'text-align: {{VALUE}};',
            ]
        ]
        );

        $this->start_controls_tabs( 'ved_post_block_read_more_btn_tabs' );

        // Normal State Tab
        $this->start_controls_tab( 'ved_post_block_read_more_btn_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );

        $this->add_control(
        'ved_post_block_read_more_btn_normal_text_color', [
            'label'     => esc_html__( 'Text Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#fff',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_cta_btn_normal_bg_color', [
            'label'     => esc_html__( 'Background Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#3ab54a',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button' => 'background: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_post_block_read_more_btn_normal_border',
            'label'    => esc_html__( 'Border', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-read-more-button',
        ]
        );

        $this->add_control(
        'ved_post_block_read_more_btn_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'vedanta' ),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button' => 'border-radius: {{SIZE}}px;',
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'      => 'ved_post_block_read_more_btn_shadow',
            'selector'  => '{{WRAPPER}} .ved-read-more-button',
            'separator' => 'before'
        ]
        );
        $this->end_controls_tab();

        // Hover State Tab
        $this->start_controls_tab( 'ved_post_block_read_more_btn_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );

        $this->add_control(
        'ved_post_block_read_more_btn_hover_text_color', [
            'label'     => esc_html__( 'Text Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#fff',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button:hover' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_post_block_read_more_btn_hover_bg_color', [
            'label'     => esc_html__( 'Background Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#3ab54a',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button:hover' => 'background: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_post_block_read_more_btn_hover_border_color', [
            'label'     => esc_html__( 'Border Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button:hover' => 'border-color: {{VALUE}};',
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'      => 'ved_post_block_read_more_btn_hover_shadow',
            'selector'  => '{{WRAPPER}} .ved-read-more-button:hover',
            'separator' => 'before'
        ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();

        $post_block_title      = $settings[ 'ved_section_post_block_title' ];

        // Slider Options
        $items      = $settings[ 'ved_post_slider_items' ];
        $autoplay   = $settings[ 'ved_post_slider_autoplay' ];
        $navigation = $settings[ 'ved_post_slider_navigation' ];
        $pagination = $settings[ 'ved_post_slider_pagination' ];

        $post_args = ved_get_post_settings( $settings );

        $posts = ved_get_post_data( $post_args );

        $post_column       = (12 / $settings[ 'ved_post_column' ]);
        $post_column_class = 'col-sm-' . $post_column . ' col-md-' . $post_column . ' col-lg-' . $post_column . '';
        
        $post_layout  = ( ($settings[ 'ved_post_type' ] == 'slider') ? "ved-post-slider" : "ved-post-grid" );

        /* Get Post Categories */
        $post_categories = $this->get_settings( 'ved_post_category' );
        if ( ! empty( $post_categories ) ) {
            foreach ( $post_categories as $key => $value ) {
                $categories[] = $value;
            }
            $categories_id_string = implode( ',', $categories );

            /* Get All Post Count */
            $total_post = 0;
            foreach ( $categories as $cat ) {
                $category   = get_category( $cat );
                $total_post = $total_post + $category->category_count;
            }
        } else {
            $categories_id_string = '';
            $total_post           = wp_count_posts( 'post' )->publish;
        }
        ?>

        <?php if ( isset( $post_block_title ) && $post_block_title ) {
            ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $post_block_title ); ?></h3>
            </div>
        <?php }
        ?>

        <div class="row">
            <div id="ved-post-block-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-post-block ved-post-columns multi-columns-row <?php echo esc_attr( $post_layout ); ?>">
                <?php
                if ( count( $posts ) ) {
                    global $post;
                    ?>
                    <?php
                    foreach ( $posts as $post ) {
                        setup_postdata( $post );
                        ?>
                        <div class="<?php echo esc_attr( $post_column_class ); ?>">
                            <article class="ved-post-item">
                                <?php if ( $settings[ 'ved_show_image' ] == 1 ) { ?>
                                    <div class="ved-post-preview">
                                        <?php if ( $thumbnail_exists = has_post_thumbnail() ): ?>
                                            <a class="ved-post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true"><img alt src="<?php echo esc_url( wp_get_attachment_image_url( get_post_thumbnail_id(), $settings[ 'image_size' ] ) ) ?>"> </a>
                                            <span class="blogicons">
                                                <a href="<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'full' ) ); ?>" class="icon zoom ti-search"></a> 
                                                <a title="Click to view Read More" href="<?php the_permalink(); ?>" class="icon readmore ti-link"></a>
                                            </span>
                                            <?php if ( $settings[ 'ved_post_block_meta_date' ] == 'yes' ) { ?>
                                            <p class="meta_date"> <span class="day_date"><?php the_time( 'j' ) ?></span><span class="day_month"><?php the_time( 'M' ) ?></span></p>
                                           <?php } ?>
                                        <?php endif; ?>
                                    </div>
                                <?php } ?>

                                <div class="ved-post-content">
                                    <?php if ( $settings[ 'ved_show_title' ] ) { ?>
                                        <h2 class="ved-post-title"><a class="ved-post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true"><?php the_title(); ?></a></h2>
                                    <?php } ?>
                                    <?php if ( $settings[ 'ved_show_meta' ] && $settings[ 'ved_post_block_meta_position' ] == 'meta-entry-header' ) { ?>	
                                        <ul class="ved-post-meta">
                                            <?php ved_post_metadata( $settings ); ?> 
                                        </ul>
                                    <?php } ?>

                                    <div class="ved-post-excerpt">
                                        <?php if ( $settings[ 'ved_show_excerpt' ] ) { ?>
                                            <p><?php echo ved_get_excerpt_by_id( get_the_ID(), $settings[ 'ved_excerpt_length' ] ); ?></p>
                                        <?php } ?>
                                    </div>

                                    <?php if ( $settings[ 'ved_show_meta' ] && $settings[ 'ved_post_block_meta_position' ] == 'meta-entry-footer' ) { ?>	
                                        <ul class="ved-post-meta">
                                            <?php ved_post_metadata( $settings ); ?> 
                                        </ul>
                                    <?php } ?>

                                    <div class="ved-post-link">
                                        <?php ved_post_readmore(); ?>
                                    </div>
                                </div>
                            </article>
                        </div>
                        <?php
                    }
                    wp_reset_postdata();
                    ?>
                    <?php
                }
                ?>
            </div>
        </div>

        <?php
        if ( $settings[ 'ved_post_type' ] == 'grid' && $settings[ 'ved_post_block_show_read_more' ] == 1 ) :
            $read_more_button = get_option( 'page_for_posts' );
            if ( $read_more_button ) {
                $read_more_button = get_permalink( get_option( 'page_for_posts' ) );
            } else {
                $read_more_button = home_url();
            }
            ?>
            <!-- Read More Button -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="ved-read-more-button-wrap">
                        <a href="<?php echo esc_url( $read_more_button ); ?>" class="ved-read-more-button"><?php echo esc_html__( $settings[ 'ved_post_block_show_read_more_text' ], 'vedanta' ); ?></a>
                    </div>
                </div>
            </div>
        <?php 
        endif; 
        if ( $settings[ 'ved_post_type' ] == 'slider' ) :
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                var ved_post_sld = $("#ved-post-block-<?php echo esc_attr( $this->get_id() ); ?>.ved-post-slider");
                ved_post_sld.owlCarousel({
                    autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                    navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                    pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                    items: <?php echo $items; ?>,
                    loop:false,
                    autoplay:false,
                    navigationText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                    itemsDesktop : [1199,2],
                    itemsDesktopSmall : [992,2],
                    itemsTablet: [768,2],
                    itemsTabletSmall: false,
                    itemsMobile : [649,1]            
                });
            });
        </script>
        <?php
        endif; 
    }

    protected function content_template() {
        ?>

        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Post_Block() );
