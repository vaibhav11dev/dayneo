<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

class Widget_ved_Testimonial_Slider extends Widget_Base {

    public function get_name() {
        return 'ved-testimonial-slider';
    }

    public function get_title() {
        return esc_html__( 'Ved Testimonial Slider', 'vedanta' );
    }

    public function get_icon() {
        return 'fa fa-comments-o';
    }

    public function get_categories() {
        return [ 'vedanta' ];
    }

    protected function _register_controls() {


        $this->start_controls_section(
        'ved_section_testimonial_content', [
            'label' => esc_html__( 'Testimonial Content', 'vedanta' )
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_title', [
            'label'       => esc_html__( 'Title', 'vedanta' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Testimonial Title Here', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_item', [
            'type'        => Controls_Manager::REPEATER,
            'default'     => [
                [
                    'ved_testimonial_name' => 'John Doe',
                ],
                [
                    'ved_testimonial_name' => 'Jane Doe',
                ],
            ],
            'fields'      => [
                [
                    'name'    => 'ved_testimonial_enable_avatar',
                    'label'   => esc_html__( 'Display Avatar?', 'vedanta' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                ],
                [
                    'name'      => 'ved_testimonial_image',
                    'label'     => esc_html__( 'Testimonial Avatar', 'vedanta' ),
                    'type'      => Controls_Manager::MEDIA,
                    'default'   => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'ved_testimonial_enable_avatar' => 'yes',
                    ],
                ],
                [
                    'name'    => 'ved_testimonial_name',
                    'label'   => esc_html__( 'User Name', 'vedanta' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => esc_html__( 'John Doe', 'vedanta' ),
                    'dynamic' => [ 'active' => true ]
                ],
                [
                    'name'    => 'ved_testimonial_company_title',
                    'label'   => esc_html__( 'Company Name', 'vedanta' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => esc_html__( 'themevedanta', 'vedanta' ),
                    'dynamic' => [ 'active' => true ]
                ],
                [
                    'name'    => 'ved_testimonial_description',
                    'label'   => esc_html__( 'Testimonial Description', 'vedanta' ),
                    'type'    => Controls_Manager::WYSIWYG,
                    'default' => esc_html__( 'Add testimonial description here. Edit and place your own text.', 'vedanta' ),
                ],
                [
                    'name'    => 'ved_testimonial_enable_rating',
                    'label'   => esc_html__( 'Display Rating?', 'vedanta' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                ],
                [
                    'name'      => 'ved_testimonial_rating_number',
                    'label'     => __( 'Rating Number', 'your-plugin' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'rating-five',
                    'options'   => [
                        'rating-one'   => __( '1', 'vedanta' ),
                        'rating-two'   => __( '2', 'vedanta' ),
                        'rating-three' => __( '3', 'vedanta' ),
                        'rating-four'  => __( '4', 'vedanta' ),
                        'rating-five'  => __( '5', 'vedanta' ),
                    ],
                    'condition' => [
                        'ved_testimonial_enable_rating' => 'yes',
                    ],
                ],
            ],
            'title_field' => 'Testimonial Item',
        ]
        );



        $this->end_controls_section();



        $this->start_controls_section(
        'ved_section_testimonial_slider_settings', [
            'label' => esc_html__( 'Testimonial Slider Settings', 'vedanta' ),
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_items', [
            'label'   => __( 'Items', 'vedanta' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_autoplay', [
            'label'        => __( 'AutoPlay', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_navigation', [
            'label'        => __( 'Navigation', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_pagination', [
            'label'        => __( 'Pagination', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'vedanta' ),
            'label_off'    => esc_html__( 'No', 'vedanta' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
        'ved_section_testimonial_styles_general', [
            'label' => esc_html__( 'Testimonial Styles', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_testimonial_background', [
            'label'     => esc_html__( 'Testimonial Background Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-item' => 'background-color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_testimonial_alignment', [
            'label'       => esc_html__( 'Set Alignment', 'vedanta' ),
            'type'        => Controls_Manager::CHOOSE,
            'label_block' => true,
            'options'     => [
                'ved-testimonial-align-left'     => [
                    'title' => esc_html__( 'Left', 'vedanta' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'ved-testimonial-align-centered' => [
                    'title' => esc_html__( 'Center', 'vedanta' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'ved-testimonial-align-right'    => [
                    'title' => esc_html__( 'Right', 'vedanta' ),
                    'icon'  => 'fa fa-align-right',
                ],
            ],
            'default'     => 'ved-testimonial-align-centered',
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_margin', [
            'label'       => esc_html__( 'Margin', 'vedanta' ),
            'description' => 'Need to refresh the page to see the change properly',
            'type'        => Controls_Manager::DIMENSIONS,
            'size_units'  => [ 'px', '%', 'em' ],
            'selectors'   => [
                '{{WRAPPER}} .ved-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_padding', [
            'label'      => esc_html__( 'Padding', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_testimonial_border',
            'label'    => esc_html__( 'Border', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-testimonial-item',
        ]
        );

        $this->add_control(
        'ved_testimonial_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'vedanta' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
            ],
        ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
        'ved_section_testimonial_image_styles', [
            'label' => esc_html__( 'Testimonial Image Style', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_image_width', [
            'label'      => esc_html__( 'Image Width', 'vedanta' ),
            'type'       => Controls_Manager::SLIDER,
            'default'    => [
                'size' => 150,
                'unit' => 'px',
            ],
            'range'      => [
                '%'  => [
                    'min' => 0,
                    'max' => 100,
                ],
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'size_units' => [ '%', 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'width:{{SIZE}}{{UNIT}};',
            ],
        ]
        );


        $this->add_responsive_control(
        'ved_testimonial_image_margin', [
            'label'      => esc_html__( 'Margin', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_image_padding', [
            'label'      => esc_html__( 'Padding', 'vedanta' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );


        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_testimonial_image_border',
            'label'    => esc_html__( 'Border', 'vedanta' ),
            'selector' => '{{WRAPPER}} .ved-testimonial-image img',
        ]
        );

        $this->add_control(
        'ved_testimonial_image_rounded', [
            'label'        => esc_html__( 'Rounded Avatar?', 'vedanta' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'testimonial-avatar-rounded',
            'default'      => '',
        ]
        );


        $this->add_control(
        'ved_testimonial_image_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'vedanta' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
            ],
            'condition' => [
                'ved_testimonial_image_rounded!' => 'testimonial-avatar-rounded',
            ],
        ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
        'ved_section_testimonial_typography', [
            'label' => esc_html__( 'Color &amp; Typography', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_testimonial_name_heading', [
            'label' => __( 'User Name', 'vedanta' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_testimonial_name_color', [
            'label'     => esc_html__( 'User Name Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-author-info .ved-testimonial-user' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_testimonial_name_typography',
            'selector' => '{{WRAPPER}} .ved-author-info .ved-testimonial-user',
        ]
        );

        $this->add_control(
        'ved_testimonial_company_heading', [
            'label' => __( 'Company Name', 'vedanta' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );


        $this->add_control(
        'ved_testimonial_company_color', [
            'label'     => esc_html__( 'Company Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-author-info .ved-testimonial-user-company' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_testimonial_position_typography',
            'selector' => '{{WRAPPER}} .ved-author-info .ved-testimonial-user-company',
        ]
        );

        $this->add_control(
        'ved_testimonial_description_heading', [
            'label' => __( 'Testimonial Text', 'vedanta' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_testimonial_description_color', [
            'label'     => esc_html__( 'Testimonial Text Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-content .ved-testimonial-text' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_testimonial_description_typography',
            'selector' => '{{WRAPPER}} .ved-testimonial-content .ved-testimonial-text',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_testimonial_navigation_style', [
            'label' => esc_html__( 'Navigation/Pagination Style', 'vedanta' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );


        $this->add_control(
        'ved_testimonial_navigation_color', [
            'label'     => esc_html__( 'Navigation Color (Arrows & Bullets)', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#fff',
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-slider .owl-prev::before' => 'color: {{VALUE}};',
                '{{WRAPPER}} .ved-testimonial-slider .owl-next::before' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_testimonial_navigation_bg', [
            'label'     => esc_html__( 'Navigation Background Color', 'vedanta' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-slider .owl-prev'                                => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .ved-testimonial-slider .owl-next'                                => 'background-color: {{VALUE}};',
            ],
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings            = $this->get_settings_for_display();
        $testimonial_title      = $settings[ 'ved_testimonial_slider_title' ];
        $testimonial_classes = $this->get_settings( 'ved_testimonial_image_rounded' ) . " " . $this->get_settings( 'ved_testimonial_alignment' );
        $navigation_type     = $this->get_settings( 'ved_testimonial_slider_navigation' );

        // Slider Options
        $items      = $settings[ 'ved_testimonial_slider_items' ];
        $autoplay   = $settings[ 'ved_testimonial_slider_autoplay' ];
        $navigation = $settings[ 'ved_testimonial_slider_navigation' ];
        $pagination = $settings[ 'ved_testimonial_slider_pagination' ];

        if ( isset( $testimonial_title ) && $testimonial_title ) {
            ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $testimonial_title ); ?></h3>
            </div>
        <?php }
        ?>
        <div id="ved-testimonial-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-testimonial-slider">
            <?php foreach ( $settings[ 'ved_testimonial_slider_item' ] as $item ) : ?>
                <div class="ved-testimonial-item clearfix <?php echo esc_attr( $testimonial_classes ); ?>">

                    <div class="ved-testimonial-image">
                        <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == 'yes' ) : ?>
                            <?php
                            $image = $item[ 'ved_testimonial_image' ];
                            ?>
                            <img src="<?php echo esc_url( $image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?>">
                        <?php endif; ?>
                        <div class="ved-author-info">
                            <h5 class="ved-testimonial-user" <?php if ( ! empty( $settings[ 'ved_testimonial_user_display_block' ] ) ) : ?> style="display: block; float: none;"<?php endif; ?>><?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?></h5>
                            <span class="ved-testimonial-user-company"><?php echo esc_attr( $item[ 'ved_testimonial_company_title' ] ); ?></span>
                        </div>
                    </div>

                    <div class="ved-testimonial-content <?php echo esc_attr( $item[ 'ved_testimonial_rating_number' ] ) ?>" <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == '' ) : ?> style="width: 100%;" <?php endif; ?>>
                        <p class="ved-testimonial-text"><?php echo $item[ 'ved_testimonial_description' ]; ?></p>
                        <?php if ( ! empty( $item[ 'ved_testimonial_enable_rating' ] ) ) : ?>
                            <ul class="testimonial-star-rating">
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    $("#ved-testimonial-<?php echo esc_attr( $this->get_id() ); ?>").each(function () {
                        $(this).owlCarousel($.extend({
                            autoPlay: <?php echo $autoplay ? 'true' : 'false'; ?>,
                            navigation: <?php echo $navigation ? 'true' : 'false'; ?>,
                            pagination: <?php echo $pagination ? 'true' : 'false'; ?>,
                            singleItem: true,
                            items: 1,
                            navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']
                        }));
                    });
                });
            </script>

        <?php
    }

    protected function content_template() {
        ?>


        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_ved_Testimonial_Slider() );
