<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Ved_Adv_Progressbar extends Widget_Base {

	public function get_name() {
		return 'ved-adv-progressbar';
	}

	public function get_title() {
		return __( 'Ved Advanced Progressbar', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-skill-bar';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
		'ved_section_progress', [
			'label' => __( 'Advance Progress Bar', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_title', [
			'label'		 => __( 'Title', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'dynamic'	 => [
				'active' => true,
			],
			'placeholder'	 => __( 'Enter your title', 'vedanta' ),
			'default'	 => __( 'Branding', 'vedanta' ),
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_percent', [
			'label'		 => __( 'Percentage', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 50,
				'unit'	 => '%',
			],
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_display_percentage', [
			'label'		 => __( 'Display Percentage', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'show',
			'options'	 => [
				'show'	 => __( 'Show', 'vedanta' ),
				'hide'	 => __( 'Hide', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_display_striped', [
			'label'		 => __( 'Display Striped', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'hide',
			'options'	 => [
				'show'	 => __( 'Show', 'vedanta' ),
				'hide'	 => __( 'Hide', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_striped_active', [
			'label'		 => __( 'Active Striped', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'show',
			'options'	 => [
				'show'	 => __( 'On', 'vedanta' ),
				'hide'	 => __( 'Off', 'vedanta' ),
			],
			'condition'	 => [
				'ved_display_striped' => 'show'
			]
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_progressbar_styling', [
			'label'	 => __( 'Progress Bar', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_progressbar_color', [
			'label'		 => __( 'Progress Bar Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress-bar' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_progressbar_bg_color', [
			'label'		 => __( 'Progress Bar Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_progressbar_height', [
			'label'		 => __( 'Progress Bar Height', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'size_units'	 => [ 'px' ],
			'default'	 => [
				'size' => 10,
			],
			'range'		 => [
				'px' => [
					'min'	 => 1,
					'max'	 => 96,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress' => 'height: {{SIZE}}{{UNIT}};',
			],
		]
		);

		$this->add_control(
		'ved_progressbar_border_radius', [
			'label'		 => __( 'Progress Bar Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_progresstitle', [
			'label'	 => __( 'Progress Title', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_progresstitle_color', [
			'label'		 => __( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress-title' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_progresstitle_typography',
			'selector'	 => '{{WRAPPER}} .ved-adv-progressbar .progress-title',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_progresspercentage', [
			'label'	 => __( 'Progress Percentage', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_progresspercentage_color', [
			'label'		 => __( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress-title span' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_progresspercentage_typography',
			'selector'	 => '{{WRAPPER}} .ved-adv-progressbar .progress-title span',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings		 = $this->get_settings();
		$progress_bar_class	 = '';
		if ( $settings[ 'ved_display_striped' ] == 'show' ) {
			$progress_bar_class .= 'progress-bar-striped';
		}
		if ( $settings[ 'ved_striped_active' ] == 'show' ) {
			$progress_bar_class .= ' active';
		}
		?>
		<div class="ved-adv-progressbar">
			<h6 class="progress-title">
				<?php echo esc_html($settings[ 'ved_title' ]); ?> 
				<?php if ( 'hide' !== $settings[ 'ved_display_percentage' ] ) { ?>
					<span class="pull-right"><span></span>%</span>
				<?php } ?>
			</h6>
			<div class="progress">
				<div class="progress-bar <?php echo esc_attr($progress_bar_class); ?>" aria-valuenow="<?php echo esc_attr($settings[ 'ved_percent' ][ 'size' ]); ?>" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Adv_Progressbar() );
