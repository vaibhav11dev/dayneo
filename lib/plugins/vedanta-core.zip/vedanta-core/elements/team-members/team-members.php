<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Ved_Team_Member extends Widget_Base {

	public function get_name() {
		return 'ved-team-member';
	}

	public function get_title() {
		return esc_html__( 'Ved Team Member', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
		'ved_section_team_member_image', [
			'label' => esc_html__( 'Team Member Image', 'vedanta' )
		]
		);


		$this->add_control(
		'ved_team_member_image', [
			'label'		 => esc_html__( 'Team Member Avatar', 'vedanta' ),
			'type'		 => Controls_Manager::MEDIA,
			'default'	 => [
				'url' => Utils::get_placeholder_image_src(),
			],
		]
		);


		$this->add_group_control(
		Group_Control_Image_Size::get_type(), [
			'name'		 => 'thumbnail',
			'default'	 => 'full',
			'condition'	 => [
				'ved_team_member_image[url]!' => '',
			],
		]
		);


		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_team_member_content', [
			'label' => esc_html__( 'Team Member Content', 'vedanta' )
		]
		);


		$this->add_control(
		'ved_team_member_name', [
			'label'		 => esc_html__( 'Name', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'default'	 => esc_html__( 'Michael Thomas', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_team_member_job_title', [
			'label'		 => esc_html__( 'Job Position', 'vedanta' ),
			'type'		 => Controls_Manager::TEXT,
			'default'	 => esc_html__( 'Creative Director', 'vedanta' ),
		]
		);

		$this->add_control(
		'ved_team_member_description', [
			'label'		 => esc_html__( 'Description', 'vedanta' ),
			'type'		 => Controls_Manager::TEXTAREA,
			'default'	 => esc_html__( 'Add team member description here. Remove the text if not necessary.', 'vedanta' ),
		]
		);


		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_team_member_social_profiles', [
			'label' => esc_html__( 'Social Profiles', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_team_member_enable_social_profiles', [
			'label'		 => esc_html__( 'Display Social Profiles?', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'yes',
		]
		);


		$this->add_control(
		'ved_team_member_social_profile_links', [
			'type'		 => Controls_Manager::REPEATER,
			'condition'	 => [
				'ved_team_member_enable_social_profiles!' => '',
			],
			'default'	 => [
					[
					'social' => 'fa fa-facebook',
				],
					[
					'social' => 'fa fa-twitter',
				],
					[
					'social' => 'fa fa-google-plus',
				],
					[
					'social' => 'fa fa-linkedin',
				],
			],
			'fields'	 => [
					[
					'name'		 => 'social',
					'label'		 => esc_html__( 'Icon', 'vedanta' ),
					'type'		 => Controls_Manager::ICON,
					'label_block'	 => true,
					'default'	 => 'fa fa-wordpress',
					'include'	 => [
						'fa fa-apple',
						'fa fa-behance',
						'fa fa-bitbucket',
						'fa fa-codepen',
						'fa fa-delicious',
						'fa fa-digg',
						'fa fa-dribbble',
						'fa fa-envelope',
						'fa fa-facebook',
						'fa fa-flickr',
						'fa fa-foursquare',
						'fa fa-github',
						'fa fa-google-plus',
						'fa fa-houzz',
						'fa fa-instagram',
						'fa fa-jsfiddle',
						'fa fa-linkedin',
						'fa fa-medium',
						'fa fa-pinterest',
						'fa fa-product-hunt',
						'fa fa-reddit',
						'fa fa-shopping-cart',
						'fa fa-slideshare',
						'fa fa-snapchat',
						'fa fa-soundcloud',
						'fa fa-spotify',
						'fa fa-stack-overflow',
						'fa fa-tripadvisor',
						'fa fa-tumblr',
						'fa fa-twitch',
						'fa fa-twitter',
						'fa fa-vimeo',
						'fa fa-vk',
						'fa fa-whatsapp',
						'fa fa-wordpress',
						'fa fa-xing',
						'fa fa-yelp',
						'fa fa-youtube',
					],
				],
					[
					'name'		 => 'link',
					'label'		 => esc_html__( 'Link', 'vedanta' ),
					'type'		 => Controls_Manager::URL,
					'label_block'	 => true,
					'default'	 => [
						'url'		 => '',
						'is_external'	 => 'true',
					],
					'placeholder'	 => esc_html__( 'Place URL here', 'vedanta' ),
				],
			],
			'title_field'	 => '<i class="{{ social }}"></i> {{{ social.replace( \'fa fa-\', \'\' ).replace( \'-\', \' \' ).replace( /\b\w/g, function( letter ){ return letter.toUpperCase() } ) }}}',
		]
		);

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_team_members_styles_general', [
			'label'	 => esc_html__( 'Team Member Styles', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);


		$this->add_control(
		'ved_team_members_preset', [
			'label'		 => esc_html__( 'Style Preset', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'ved-team-members-default',
			'options'	 => [
				'ved-team-members-default'	 => esc_html__( 'Default Style', 'vedanta' ),
				'ved-team-members-simple'	 => esc_html__( 'Simple Style', 'vedanta' ),
				'ved-team-members-overlay'	 => esc_html__( 'Overlay Style', 'vedanta' ),
				'ved-team-members-circle'	 => esc_html__( 'Circle Style', 'vedanta' ),
				'ved-team-members-social-bottom' => esc_html__( 'Social on Bottom', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_team_members_overlay_background', [
			'label'		 => esc_html__( 'Overlay Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => 'rgba(255,255,255,0.8)',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-members-overlay .ved-team-content'	 => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .ved-team-members-default .ved-team-social'	 => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_team_members_preset' => [ 'ved-team-members-default', 'ved-team-members-overlay' ],
			]
		]
		);

		$this->add_control(
		'ved_team_members_background', [
			'label'		 => esc_html__( 'Content Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item .ved-team-content' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_team_members_alignment', [
			'label'		 => esc_html__( 'Set Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'default'	 => [
					'title'	 => esc_html__( 'Default', 'vedanta' ),
					'icon'	 => 'fa fa-ban',
				],
				'left'		 => [
					'title'	 => esc_html__( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'centered'	 => [
					'title'	 => esc_html__( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'		 => [
					'title'	 => esc_html__( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				],
			],
			'default'	 => 'ved-team-align-default',
			'prefix_class'	 => 'ved-team-align-',
		]
		);

		$this->add_responsive_control(
		'ved_team_members_padding', [
			'label'		 => esc_html__( 'Content Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', '%', 'em' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item .ved-team-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_team_members_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-team-item',
		]
		);

		$this->add_control(
		'ved_team_members_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
			],
		]
		);

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_team_members_image_styles', [
			'label'	 => esc_html__( 'Team Member Image Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_responsive_control(
		'ved_team_members_image_width', [
			'label'		 => esc_html__( 'Image Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => '100',
				'unit'	 => '%',
			],
			'range'		 => [
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
				],
			],
			'size_units'	 => [ '%', 'px' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item figure img' => 'width:{{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_team_members_preset!' => 'ved-team-members-circle'
			]
		]
		);

		$this->add_responsive_control(
		'ved_team_members_circle_image_width', [
			'label'		 => esc_html__( 'Image Width', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 150,
				'unit'	 => 'px',
			],
			'range'		 => [
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
				],
			],
			'size_units'	 => [ 'px' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item.ved-team-members-circle figure img' => 'width:{{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_team_members_preset' => 'ved-team-members-circle'
			]
		]
		);

		$this->add_responsive_control(
		'ved_team_members_circle_image_height', [
			'label'		 => esc_html__( 'Image Height', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 150,
				'unit'	 => 'px',
			],
			'range'		 => [
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
				],
			],
			'size_units'	 => [ 'px' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item.ved-team-members-circle figure img' => 'height:{{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_team_members_preset' => 'ved-team-members-circle'
			]
		]
		);


		$this->add_responsive_control(
		'ved_team_members_image_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item figure img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_team_members_image_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', '%', 'em' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item figure img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);


		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_team_members_image_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-team-item figure img',
		]
		);

		$this->add_control(
		'ved_team_members_image_rounded', [
			'label'		 => esc_html__( 'Rounded Avatar?', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'return_value'	 => 'team-avatar-rounded',
			'default'	 => '',
		]
		);


		$this->add_control(
		'ved_team_members_image_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item figure img' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
			],
			'condition'	 => [
				'ved_team_members_image_rounded!' => 'team-avatar-rounded',
			],
		]
		);

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_team_members_typography', [
			'label'	 => esc_html__( 'Color &amp; Typography', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_team_members_name_heading', [
			'label'	 => esc_html__( 'Member Name', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_team_members_name_color', [
			'label'		 => esc_html__( 'Member Name Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item .ved-team-member-name' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_team_members_name_typography',
			'selector'	 => '{{WRAPPER}} .ved-team-item .ved-team-member-name',
		]
		);

		$this->add_control(
		'ved_team_members_position_heading', [
			'label'	 => esc_html__( 'Member Job Position', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_team_members_position_color', [
			'label'		 => esc_html__( 'Job Position Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item .ved-team-member-position' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_team_members_position_typography',
			'selector'	 => '{{WRAPPER}} .ved-team-item .ved-team-member-position',
		]
		);

		$this->add_control(
		'ved_team_members_description_heading', [
			'label'	 => esc_html__( 'Member Description', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		$this->add_control(
		'ved_team_members_description_color', [
			'label'		 => esc_html__( 'Description Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-item .ved-team-content .ved-team-text' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_team_members_description_typography',
			'selector'	 => '{{WRAPPER}} .ved-team-item .ved-team-content .ved-team-text',
		]
		);


		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_team_members_social_profiles_styles', [
			'label'	 => esc_html__( 'Social Profiles Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);


		$this->add_control(
		'ved_team_members_social_icon_size', [
			'label'		 => esc_html__( 'Icon Size', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 200,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link a i' => 'font-size: {{SIZE}}px;',
			],
		]
		);

		$this->add_responsive_control(
		'ved_team_members_social_profiles_padding', [
			'label'		 => esc_html__( 'Social Profiles Spacing', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', '%', 'em' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-content > .ved-team-member-social-profiles' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);


		$this->start_controls_tabs( 'ved_team_members_social_icons_style_tabs' );

		$this->start_controls_tab( 'normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );

		$this->add_control(
		'ved_team_members_social_icon_color', [
			'label'		 => esc_html__( 'Icon Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#333333',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link > a' => 'color: {{VALUE}};',
			],
		]
		);


		$this->add_control(
		'ved_team_members_social_icon_background', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link > a' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_team_members_social_icon_border',
			'selector'	 => '{{WRAPPER}} .ved-team-member-social-link > a',
		]
		);

		$this->add_control(
		'ved_team_members_social_icon_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'max' => 100,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link > a' => 'border-radius: {{SIZE}}px;',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_team_members_social_icon_typography',
			'selector'	 => '{{WRAPPER}} .ved-team-member-social-link > a',
		]
		);


		$this->end_controls_tab();

		$this->start_controls_tab( 'ved_team_members_social_icon_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );

		$this->add_control(
		'ved_team_members_social_icon_hover_color', [
			'label'		 => esc_html__( 'Icon Hover Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#333333',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link > a:hover' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_team_members_social_icon_hover_background', [
			'label'		 => esc_html__( 'Hover Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link > a:hover' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_team_members_social_icon_hover_border_color', [
			'label'		 => esc_html__( 'Hover Border Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-team-member-social-link > a:hover' => 'border-color: {{VALUE}};',
			],
		]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();


		$this->end_controls_section();
	}

	protected function render() {

		$settings		 = $this->get_settings();
		$team_member_image	 = $this->get_settings( 'ved_team_member_image' );
		$team_member_image_url	 = Group_Control_Image_Size::get_attachment_image_src( $team_member_image[ 'id' ], 'thumbnail', $settings );
		if ( empty( $team_member_image_url ) ) : $team_member_image_url = $team_member_image[ 'url' ];
		else: $team_member_image_url = $team_member_image_url;
		endif;
		$team_member_classes = $this->get_settings( 'ved_team_members_preset' ) . " " . $this->get_settings( 'ved_team_members_image_rounded' );
		?>


		<div id="ved-team-member-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-team-item <?php echo esc_attr($team_member_classes); ?>">
			<div class="ved-team-item-inner">
				<div class="ved-team-image">
					<figure>
						<img src="<?php echo esc_url( $team_member_image_url ); ?>" alt="<?php echo esc_attr($settings[ 'ved_team_member_name' ]); ?>">
					</figure>
		<?php if ( ( 'ved-team-members-default' === $settings[ 'ved_team_members_preset' ] ) && ( ! empty( $settings[ 'ved_team_member_enable_social_profiles' ] ) ) ): ?>
						<div class="ved-team-social">
							<ul class="ved-team-member-social-profiles">
			<?php foreach ( $settings[ 'ved_team_member_social_profile_links' ] as $item ) : ?>
				<?php if ( ! empty( $item[ 'social' ] ) ) : ?>
					<?php $target = $item[ 'link' ][ 'is_external' ] ? ' target="_blank"' : ''; ?>
										<li class="ved-team-member-social-link">
											<a href="<?php echo esc_url( $item[ 'link' ][ 'url' ] ); ?>"<?php echo esc_attr($target); ?>><i class="<?php echo esc_attr( $item[ 'social' ] ); ?>"></i></a>
										</li>
				<?php endif; ?>
			<?php endforeach; ?>
							</ul>
						</div>
		<?php endif; ?>
				</div>

				<div class="ved-team-content">
					<?php if ( 'ved-team-members-overlay' === $settings[ 'ved_team_members_preset' ] ) : ?>
						<div class="valign-middle">
					<?php endif; ?>
					<h6 class="ved-team-member-name"><?php echo esc_html($settings[ 'ved_team_member_name' ]); ?></h6>
					<span class="ved-team-member-position"><?php echo esc_html($settings[ 'ved_team_member_job_title' ]); ?></span>
		<?php if ( 'ved-team-members-social-bottom' === $settings[ 'ved_team_members_preset' ] ) : ?>
						<p class="ved-team-text"><?php echo $settings[ 'ved_team_member_description' ]; ?></p>
			<?php if ( ! empty( $settings[ 'ved_team_member_enable_social_profiles' ] ) ): ?>
							<ul class="ved-team-member-social-profiles">
				<?php foreach ( $settings[ 'ved_team_member_social_profile_links' ] as $item ) : ?>
					<?php if ( ! empty( $item[ 'social' ] ) ) : ?>
						<?php $target = $item[ 'link' ][ 'is_external' ] ? ' target="_blank"' : ''; ?>
										<li class="ved-team-member-social-link">
											<a href="<?php echo esc_url( $item[ 'link' ][ 'url' ] ); ?>"<?php echo esc_attr($target); ?>><i class="<?php echo esc_attr( $item[ 'social' ] ); ?>"></i></a>
										</li>
					<?php endif; ?>
				<?php endforeach; ?>
							</ul>
			<?php endif; ?>
		<?php elseif ( 'ved-team-members-default' !== $settings[ 'ved_team_members_preset' ] ) : ?>
			<?php if ( ! empty( $settings[ 'ved_team_member_enable_social_profiles' ] ) ): ?>
							<ul class="ved-team-member-social-profiles">
				<?php foreach ( $settings[ 'ved_team_member_social_profile_links' ] as $item ) : ?>
					<?php if ( ! empty( $item[ 'social' ] ) ) : ?>
						<?php $target = $item[ 'link' ][ 'is_external' ] ? ' target="_blank"' : ''; ?>
										<li class="ved-team-member-social-link">
											<a href="<?php echo esc_url( $item[ 'link' ][ 'url' ] ); ?>"<?php echo esc_attr($target); ?>><i class="<?php echo esc_attr( $item[ 'social' ] ); ?>"></i></a>
										</li>
					<?php endif; ?>
				<?php endforeach; ?>
							</ul>
			<?php endif; ?>
						<p class="ved-team-text"><?php echo $settings[ 'ved_team_member_description' ]; ?></p>
		<?php endif; ?>

				</div>
				<?php if ( 'ved-team-members-overlay' === $settings[ 'ved_team_members_preset' ] ) : ?>
					</div>
				<?php endif; ?>
			</div>
		</div>


							<?php
						}

						protected function content_template() {
							?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Team_Member() );
