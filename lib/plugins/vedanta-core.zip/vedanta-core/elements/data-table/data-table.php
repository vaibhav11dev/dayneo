<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

class Widget_Ved_Data_Table extends Widget_Base {

	public $unique_id = null;

	public function get_name() {
		return 'ved-data-table';
	}

	public function get_title() {
		return esc_html__( 'Ved Data Table', 'vedanta' );
	}

	public function get_icon() {
		return 'eicon-table';
	}

	public function get_categories() {
		return [ 'vedanta' ];
	}

	protected function _register_controls() {

		/**
		 * Data Table Header
		 */
		$this->start_controls_section(
		'ved_section_data_table_header', [
			'label' => esc_html__( 'Header', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_section_data_table_enabled', [
			'label'		 => esc_html__( 'Enable Table Sorting', 'vedanta' ),
			'type'		 => Controls_Manager::SWITCHER,
			'default'	 => 'false',
			'label_on'	 => esc_html__( 'Yes', 'vedanta' ),
			'label_off'	 => esc_html__( 'No', 'vedanta' ),
			'return_value'	 => 'true',
		]
		);

		$this->add_control(
		'ved_data_table_header_cols_data', [
			'type'		 => Controls_Manager::REPEATER,
			'seperator'	 => 'before',
			'default'	 => [
					[ 'ved_data_table_header_col' => 'Table Header' ],
					[ 'ved_data_table_header_col' => 'Table Header' ],
					[ 'ved_data_table_header_col' => 'Table Header' ],
					[ 'ved_data_table_header_col' => 'Table Header' ],
			],
			'fields'	 => [
					[
					'name'		 => 'ved_data_table_header_col',
					'label'		 => esc_html__( 'Column Name', 'vedanta' ),
					'default'	 => 'Table Header',
					'type'		 => Controls_Manager::TEXT,
					'label_block'	 => false,
				],
					[
					'name'		 => 'ved_data_table_header_col_icon_enabled',
					'label'		 => esc_html__( 'Enable Header Icon', 'vedanta' ),
					'type'		 => Controls_Manager::SWITCHER,
					'label_on'	 => esc_html__( 'yes', 'vedanta' ),
					'label_off'	 => esc_html__( 'no', 'vedanta' ),
					'default'	 => 'false',
					'return_value'	 => 'true',
				],
					[
					'name'		 => 'ved_data_table_header_col_icon',
					'label'		 => esc_html__( 'Icon', 'vedanta' ),
					'type'		 => Controls_Manager::ICON,
					'default'	 => '',
					'condition'	 => [
						'ved_data_table_header_col_icon_enabled' => 'true'
					]
				],
					[
					'name'		 => 'ved_data_table_header_col_img_enabled',
					'label'		 => esc_html__( 'Enable Header Image', 'vedanta' ),
					'type'		 => Controls_Manager::SWITCHER,
					'label_on'	 => esc_html__( 'yes', 'vedanta' ),
					'label_off'	 => esc_html__( 'no', 'vedanta' ),
					'default'	 => 'false',
					'return_value'	 => 'true',
				],
					[
					'name'		 => 'ved_data_table_header_col_img',
					'label'		 => esc_html__( 'Image', 'vedanta' ),
					'type'		 => Controls_Manager::MEDIA,
					'default'	 => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'condition'	 => [
						'ved_data_table_header_col_img_enabled' => 'true',
					]
				],
					[
					'name'		 => 'ved_data_table_header_col_img_size',
					'label'		 => esc_html__( 'Image Size(px)', 'vedanta' ),
					'default'	 => '25',
					'type'		 => Controls_Manager::TEXT,
					'label_block'	 => false,
					'condition'	 => [
						'ved_data_table_header_col_img_enabled' => 'true',
					]
				],
			],
			'title_field'	 => '{{ved_data_table_header_col}}',
		]
		);

		$this->end_controls_section();

		/**
		 * Data Table Content
		 */
		$this->start_controls_section(
		'ved_section_data_table_cotnent', [
			'label' => esc_html__( 'Content', 'vedanta' )
		]
		);

		$this->add_control(
		'ved_data_table_content_rows', [
			'type'		 => Controls_Manager::REPEATER,
			'seperator'	 => 'before',
			'default'	 => [
					[ 'ved_data_table_content_row_type' => 'row' ],
					[ 'ved_data_table_content_row_type' => 'col' ],
					[ 'ved_data_table_content_row_type' => 'col' ],
					[ 'ved_data_table_content_row_type' => 'col' ],
					[ 'ved_data_table_content_row_type' => 'col' ],
			],
			'fields'	 => [
					[
					'name'		 => 'ved_data_table_content_row_type',
					'label'		 => esc_html__( 'Row Type', 'vedanta' ),
					'type'		 => Controls_Manager::SELECT,
					'default'	 => 'row',
					'label_block'	 => false,
					'options'	 => [
						'row'	 => esc_html__( 'Row', 'vedanta' ),
						'col'	 => esc_html__( 'Column', 'vedanta' ),
					]
				],
					[
					'name'		 => 'ved_data_table_content_row_title',
					'label'		 => esc_html__( 'Cell Text', 'vedanta' ),
					'type'		 => Controls_Manager::TEXTAREA,
					'label_block'	 => false,
					'default'	 => esc_html__( 'Content', 'vedanta' ),
					'condition'	 => [
						'ved_data_table_content_row_type' => 'col'
					]
				],
					[
					'name'		 => 'ved_data_table_content_row_title_link',
					'label'		 => esc_html__( 'Link', 'vedanta' ),
					'type'		 => Controls_Manager::URL,
					'label_block'	 => true,
					'default'	 => [
						'url'		 => '',
						'is_external'	 => '',
					],
					'show_external'	 => true,
					'separator'	 => 'before',
					'condition'	 => [
						'ved_data_table_content_row_type' => 'col'
					]
				],
					[
					'name'		 => 'ved_data_table_content_row_colspan',
					'label'		 => esc_html__( 'Colspan', 'vedanta' ),
					'type'		 => Controls_Manager::NUMBER,
					'default'	 => 1,
					'min'		 => 1,
					'condition'	 => [
						'ved_data_table_content_row_type' => 'col'
					]
				]
			],
			'title_field'	 => '{{ved_data_table_content_row_type}}::{{ved_data_table_content_row_title}}',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Data Table Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_data_table_style_settings', [
			'label'	 => esc_html__( 'General Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_data_table_style', [
			'label'		 => esc_html__( 'Data Table Style', 'vedanta' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'ved-data-table-basic',
			'options'	 => [
				'ved-data-table-basic'		 => esc_html__( 'Default Style', 'vedanta' ),
				'ved-data-table-striped'	 => esc_html__( 'Striped Style', 'vedanta' ),
				'ved-data-table-bordered'	 => esc_html__( 'Bordered Style', 'vedanta' ),
				'ved-data-table-hover'		 => esc_html__( 'Hover Style', 'vedanta' ),
			],
		]
		);

		$this->add_control(
		'ved_data_table_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table-wrap' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_data_table_container_padding', [
			'label'		 => esc_html__( 'Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_data_table_container_margin', [
			'label'		 => esc_html__( 'Margin', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_data_table_border',
			'label'		 => esc_html__( 'Border', 'vedanta' ),
			'selector'	 => '{{WRAPPER}} .ved-data-table-wrap .table-bordered',
			'{{WRAPPER}} .ved-data-table-wrap .table-bordered > thead > tr > th',
			'{{WRAPPER}} .ved-data-table-wrap .table-bordered > tbody > tr > th',
			'{{WRAPPER}} .ved-data-table-wrap .table-bordered > tfoot > tr > th',
			'{{WRAPPER}} .ved-data-table-wrap .table-bordered > thead > tr > td',
			'{{WRAPPER}} .ved-data-table-wrap .table-bordered > tbody > tr > td',
			'{{WRAPPER}} .ved-data-table-wrap .table-bordered > tfoot > tr > td',
			'condition'	 => [
				'ved_data_table_style' => 'ved-data-table-bordered'
			]
		]
		);

		$this->add_control(
		'ved_data_table_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table-wrap .table-bordered' => 'border-radius: {{SIZE}}px;',
			],
			'condition'	 => [
				'ved_data_table_style' => 'ved-data-table-bordered'
			]
		]
		);

		$this->add_responsive_control(
		'ved_data_table_th_padding', [
			'label'		 => esc_html__( 'Table Header Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table thead tr th' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_responsive_control(
		'ved_data_table_td_padding', [
			'label'		 => esc_html__( 'Table Data Padding', 'vedanta' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', 'em', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table tbody tr td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Box_Shadow::get_type(), [
			'name'		 => 'ved_data_table_shadow',
			'selector'	 => '{{WRAPPER}} .ved-data-table-wrap',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Data Table Header Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_data_table_title_style_settings', [
			'label'	 => esc_html__( 'Header Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);


		$this->add_control(
		'ved_section_data_table_header_radius', [
			'label'		 => esc_html__( 'Header Border Radius', 'vedanta' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table thead tr th:first-child'	 => 'border-radius: {{SIZE}}px 0px 0px 0px;',
				'{{WRAPPER}} .ved-data-table thead tr th:last-child'	 => 'border-radius: 0px {{SIZE}}px 0px 0px;',
			],
		]
		);

		$this->add_control(
		'ved_data_table_header_title_color', [
			'label'		 => esc_html__( 'Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#222222',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table thead tr th'		 => 'color: {{VALUE}};',
				'{{WRAPPER}} table.dataTable thead .sorting:after'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} table.dataTable thead .sorting_asc:after'	 => 'color: {{VALUE}};',
				'{{WRAPPER}} table.dataTable thead .sorting_desc:after'	 => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_data_table_header_title_bg_color', [
			'label'		 => esc_html__( 'Background Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table thead tr th' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_data_table_header_title_typography',
			'selector'	 => '{{WRAPPER}} .ved-data-table thead tr th',
		]
		);

		$this->add_responsive_control(
		'ved_data_table_header_title_alignment', [
			'label'		 => esc_html__( 'Title Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'left'	 => [
					'title'	 => esc_html__( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => esc_html__( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => esc_html__( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				],
			],
			'default'	 => 'left',
			'prefix_class'	 => 'ved-dt-th-align-',
		]
		);

		$this->end_controls_section();

		/**
		 * -------------------------------------------
		 * Tab Style (Data Table Content Style)
		 * -------------------------------------------
		 */
		$this->start_controls_section(
		'ved_section_data_table_content_style_settings', [
			'label'	 => esc_html__( 'Content Style', 'vedanta' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_data_table_content_color_odd', [
			'label'		 => esc_html__( 'Color ( Odd Row )', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table tbody > tr:nth-child(2n) td' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_data_table_content_bg_odd_color', [
			'label'		 => esc_html__( 'Background Color (Odd Row)', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table tbody > tr:nth-child(2n) td' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_data_table_content_color_even', [
			'label'		 => esc_html__( 'Color ( Even Row )', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table tbody > tr:nth-child(2n+1) td' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_data_table_content_bg_even_color', [
			'label'		 => esc_html__( 'Background Color (Even Row)', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table tbody > tr:nth-child(2n+1) td' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_data_table_content_typography',
			'selector'	 => '{{WRAPPER}} .ved-data-table tbody tr td',
		]
		);

		$this->add_control(
		'ved_data_table_content_link_typo', [
			'label'	 => esc_html__( 'Link Color', 'vedanta' ),
			'type'	 => Controls_Manager::HEADING,
		]
		);

		/* Table Content Link */
		$this->start_controls_tabs( 'ved_data_table_link_tabs' );

		// Normal State Tab
		$this->start_controls_tab( 'ved_data_table_link_normal', [ 'label' => esc_html__( 'Normal', 'vedanta' ) ] );

		$this->add_control(
		'ved_data_table_link_normal_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#777777',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table-wrap table td a' => 'color: {{VALUE}};',
			],
		]
		);

		$this->end_controls_tab();

		// Hover State Tab
		$this->start_controls_tab( 'ved_data_table_link_hover', [ 'label' => esc_html__( 'Hover', 'vedanta' ) ] );

		$this->add_control(
		'ved_data_table_link_hover_text_color', [
			'label'		 => esc_html__( 'Text Color', 'vedanta' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-data-table-wrap table td a:hover' => 'color: {{VALUE}};',
			],
		]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
		'ved_data_table_content_alignment', [
			'label'		 => esc_html__( 'Content Alignment', 'vedanta' ),
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'left'	 => [
					'title'	 => esc_html__( 'Left', 'vedanta' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => esc_html__( 'Center', 'vedanta' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => esc_html__( 'Right', 'vedanta' ),
					'icon'	 => 'fa fa-align-right',
				],
			],
			'default'	 => 'left',
			'prefix_class'	 => 'ved-dt-td-align-',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings();

		$table_tr	 = [];
		$table_td	 = [];

		$data_table_style = '';
		if ( $settings[ 'ved_data_table_style' ] == 'ved-data-table-striped' ) {
			$data_table_style .= 'table-striped';
		} elseif ( $settings[ 'ved_data_table_style' ] == 'ved-data-table-bordered' ) {
			$data_table_style .= 'table-bordered';
		} elseif ( $settings[ 'ved_data_table_style' ] == 'ved-data-table-hover' ) {
			$data_table_style .= 'table-hover';
		}

		// Storing Data table content values
		foreach ( $settings[ 'ved_data_table_content_rows' ] as $content_row ) {

			$row_id = rand( 10, 1000 );
			if ( $content_row[ 'ved_data_table_content_row_type' ] == 'row' ) {
				$table_tr[] = [
					'id'	 => $row_id,
					'type'	 => $content_row[ 'ved_data_table_content_row_type' ],
				];
			}
			if ( $content_row[ 'ved_data_table_content_row_type' ] == 'col' ) {
				$target		 = $content_row[ 'ved_data_table_content_row_title_link' ][ 'is_external' ] ? 'target="_blank"' : '';
				$nofollow	 = $content_row[ 'ved_data_table_content_row_title_link' ][ 'nofollow' ] ? 'rel="nofollow"' : '';

				$table_tr_keys	 = array_keys( $table_tr );
				$last_key	 = end( $table_tr_keys );

				$table_td[] = [
					'row_id'	 => $table_tr[ $last_key ][ 'id' ],
					'type'		 => $content_row[ 'ved_data_table_content_row_type' ],
					'title'		 => $content_row[ 'ved_data_table_content_row_title' ],
					'link_url'	 => $content_row[ 'ved_data_table_content_row_title_link' ][ 'url' ],
					'link_target'	 => $target,
					'nofollow'	 => $nofollow,
					'colspan'	 => $content_row[ 'ved_data_table_content_row_colspan' ]
				];
			}
		}

		$table_th_count = count( $settings[ 'ved_data_table_header_cols_data' ] );
		?>
		<div class="ved-data-table-wrap">
			<table id="ved-data-table-<?php echo esc_attr($this->get_id()); ?>" class="table tablesorter ved-data-table <?php echo esc_attr($data_table_style); ?>">
				<thead>
					<tr class="table-header">
		<?php foreach ( $settings[ 'ved_data_table_header_cols_data' ] as $header_title ) : ?>
							<th class="sorting">
			<?php if ( $header_title[ 'ved_data_table_header_col_icon_enabled' ] == 'true' ) : ?>
									<i class="data-header-icon <?php echo esc_attr( $header_title[ 'ved_data_table_header_col_icon' ] ); ?>"></i>
			<?php endif; ?>
			<?php if ( $header_title[ 'ved_data_table_header_col_img_enabled' ] == 'true' ) : ?>
									<img src="<?php echo esc_url( $header_title[ 'ved_data_table_header_col_img' ][ 'url' ] ) ?>" class="ved-data-table-th-img" style="width:<?php echo esc_attr($header_title[ 'ved_data_table_header_col_img_size' ]); ?>px" alt="<?php echo esc_attr( $header_title[ 'ved_data_table_header_col' ] ); ?>">
			<?php endif; ?>
			<?php echo esc_html__( $header_title[ 'ved_data_table_header_col' ], 'vedanta' ); ?>
							</th>
		<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
		<?php for ( $i = 0; $i < count( $table_tr ); $i ++ ) : ?>
						<tr>
			<?php
			for ( $j = 0; $j < count( $table_td ); $j ++ ) {
				if ( $table_tr[ $i ][ 'id' ] == $table_td[ $j ][ 'row_id' ] ) {
					?>
					<?php if ( ! empty( $table_td[ $j ][ 'link_url' ] ) ) : ?>
										<td<?php echo $table_td[ $j ][ 'colspan' ] > 1 ? ' colspan="' . esc_attr($table_td[ $j ][ 'colspan' ]) . '"' : ''; ?>>
											<a href="<?php echo esc_url( $table_td[ $j ][ 'link_url' ] ); ?>" <?php echo esc_attr($table_td[ $j ][ 'link_target' ]) ?> <?php echo esc_attr($table_td[ $j ][ 'nofollow' ]) ?>><?php echo esc_html($table_td[ $j ][ 'title' ]); ?></a>
										</td>
					<?php else: ?>
										<td<?php echo $table_td[ $j ][ 'colspan' ] > 1 ? ' colspan="' . esc_attr($table_td[ $j ][ 'colspan' ]) . '"' : ''; ?>><?php echo esc_html($table_td[ $j ][ 'title' ]); ?></td>
					<?php endif; ?>
					<?php
				}
			}
			?>
						</tr>
							<?php endfor; ?>
				</tbody>
			</table>

			<script type="text/javascript">
				jQuery(document).ready(function ($) {
							<?php if ( $settings[ 'ved_section_data_table_enabled' ] == 'true' ) : ?>
						$("#ved-data-table-<?php echo esc_js($this->get_id()); ?>").tablesorter();
						<?php endif; ?>
				});
			</script>
		<?php if ( $settings[ 'ved_section_data_table_enabled' ] != 'true' ) : ?>
				<style>
					table#ved-data-table-<?php echo esc_attr($this->get_id()); ?> .sorting:after,
					table#ved-data-table-<?php echo esc_attr($this->get_id()); ?> .sorting_desc:after,
					table#ved-data-table-<?php echo esc_attr($this->get_id()); ?> .sorting_asc:after {
						display: none;
					}
				</style>
						<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>


						<?php
					}

				}

				Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Data_Table() );
				