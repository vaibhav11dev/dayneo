<?php
/**
 * @version	1.0.0
 * @package	 ThemeVedanta Core
 * @author	 ThemeVedanta
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ThemeVedanta_Slider' ) ) {

	class ThemeVedanta_Slider {

		function __construct() {
			add_action( 'init', array( $this, 'init' ) );
			add_action( 'admin_init', array( $this, 'admin_init' ) );
			add_action( 'admin_menu', array( $this, 'admin_menu' ) );

			// Add settings
			add_action( 'slide-page_add_form_fields', array( $this, 'slider_add_new_meta_fields' ), 10, 2 );
			add_action( 'slide-page_edit_form_fields', array( $this, 'slider_edit_meta_fields' ), 10, 2 );
			add_action( 'edited_slide-page', array( $this, 'slider_save_taxonomy_custom_meta' ), 10, 2 );
			add_action( 'create_slide-page', array( $this, 'slider_save_taxonomy_custom_meta' ), 10, 2 );
		}

		function init() {

			register_post_type(
			'slide', array(
				'public'	 => true,
				'has_archive'	 => false,
				'rewrite'	 => array( 'slug' => 'slide' ),
				'supports'	 => array( 'title', 'thumbnail' ),
				'can_export'	 => true,
				'menu_position'	 => 100,
				'hierarchical'	 => false,
				'labels'	 => array(
					'name'			 => _x( 'ThemeVedanta Sliders', 'Post Type General Name', 'vedanta' ),
					'singular_name'		 => _x( 'ThemeVedanta Slider', 'Post Type Singular Name', 'vedanta' ),
					'menu_name'		 => __( 'ThemeVedanta Slider', 'vedanta' ),
					'parent_item_colon'	 => __( 'Parent Slide:', 'vedanta' ),
					'all_items'		 => __( 'Add or Edit Slides', 'vedanta' ),
					'view_item'		 => __( 'View Slides', 'vedanta' ),
					'add_new_item'		 => __( 'Add New Slide', 'vedanta' ),
					'add_new'		 => __( 'Add New Slide', 'vedanta' ),
					'edit_item'		 => __( 'Edit Slide', 'vedanta' ),
					'update_item'		 => __( 'Update Slide', 'vedanta' ),
					'search_items'		 => __( 'Search Slide', 'vedanta' ),
					'not_found'		 => __( 'Not found', 'vedanta' ),
					'not_found_in_trash'	 => __( 'Not found in Trash', 'vedanta' ),
				)
			)
			);

			register_taxonomy( 'slide-page', 'slide', array(
				'hierarchical'		 => true,
				'label'			 => 'Slider',
				'query_var'		 => true,
				'rewrite'		 => true,
				'hierarchical'		 => true,
				'show_in_nav_menus'	 => false,
				'show_tagcloud'		 => false,
				'labels'		 => array(
					'name'				 => _x( 'Sliders', 'Taxonomy General Name', 'vedanta' ),
					'singular_name'			 => _x( 'Slider', 'Taxonomy Singular Name', 'vedanta' ),
					'menu_name'			 => __( 'Add or Edit Sliders', 'vedanta' ),
					'all_items'			 => __( 'All Sliders', 'vedanta' ),
					'parent_item'			 => __( 'Parent Slider', 'vedanta' ),
					'parent_item_colon'		 => __( 'Parent Slider:', 'vedanta' ),
					'new_item_name'			 => __( 'New Slider Name', 'vedanta' ),
					'add_new_item'			 => __( 'Add Slider', 'vedanta' ),
					'edit_item'			 => __( 'Edit Slider', 'vedanta' ),
					'update_item'			 => __( 'Update Slider', 'vedanta' ),
					'separate_items_with_commas'	 => __( 'Separate sliders with commas', 'vedanta' ),
					'search_items'			 => __( 'Search Sliders', 'vedanta' ),
					'add_or_remove_items'		 => __( 'Add or remove sliders', 'vedanta' ),
					'choose_from_most_used'		 => __( 'Choose from the most used sliders', 'vedanta' ),
					'not_found'			 => __( 'Not Found', 'vedanta' ),
				),
			)
			);
		}

		function admin_init() {
			$post_type	 = '';
			$theme_prefix	 = 'daydream_';

			if ( isset( $_GET[ 'post' ] ) && $_GET[ 'post' ] ) {
				$post_type = get_post_type( $_GET[ 'post' ] );
			}

			if ( ( isset( $_GET[ 'taxonomy' ] ) && $_GET[ 'taxonomy' ] == 'slide-page' ) || ( isset( $_GET[ 'post_type' ] ) && $_GET[ 'post_type' ] == 'slide' ) || $post_type == 'slide' ) {
				wp_enqueue_script( 'ved-slider', plugin_dir_url( __FILE__ ) . 'assets/js/ved-slider.js', false, '1.0', false );

				$js_local_variables = array(
					'prefix' => $theme_prefix,
				);
				wp_localize_script( 'ved-slider', 'js_local_variables', $js_local_variables );
			}

			if ( isset( $_GET[ 'page' ] ) && $_GET[ 'page' ] == 'ved_export_import' ) {
				$this->export_sliders();
			}
		}

		function admin_menu() {
			global $submenu;
			unset( $submenu[ 'edit.php?post_type=slide' ][ 10 ] );

			add_submenu_page( 'edit.php?post_type=slide', __( 'Export / Import', 'vedanta' ), __( 'Export / Import', 'vedanta' ), 'manage_options', 'ved_export_import', array( $this, 'ved_export_import_settings' ) );
		}

		// Add term page
		function slider_add_new_meta_fields() {
			// this will add the custom meta field to the add new term page
			?>
			<div class="form-field form-field-checkbox">
				<label for="term_meta[nav_arrows]"><?php esc_html_e( 'Display Navigation Arrows', 'vedanta' ); ?></label>
				<input type="hidden" name="term_meta[nav_arrows]" id="term_meta[nav_arrows]" value="0">
				<input type="checkbox" name="term_meta[nav_arrows]" id="term_meta[nav_arrows]" value="1" checked="checked">
				<p class="description"><?php esc_html_e( 'Check this box to display the navigation arrows.', 'vedanta' ); ?></p>
			</div>

			<div class="form-field form-field-checkbox">
				<label for="term_meta[pagination_circles]"><?php esc_html_e( 'Display Pagination Circles', 'vedanta' ); ?></label>
				<input type="hidden" name="term_meta[pagination_circles]" id="term_meta[pagination_circles]" value="0">
				<input type="checkbox" name="term_meta[pagination_circles]" id="term_meta[pagination_circles]" value="1">
				<p class="description"><?php esc_html_e( 'Check this box to display the pagination circles.', 'vedanta' ); ?></p>
			</div>

			<div class="form-field form-field-checkbox">
				<label for="term_meta[autoplay]"><?php esc_html_e( 'Autoplay', 'vedanta' ); ?></label>
				<input type="hidden" name="term_meta[autoplay]" id="term_meta[autoplay]" value="0">
				<input type="checkbox" name="term_meta[autoplay]" id="term_meta[autoplay]" value="1" checked="checked">
				<p class="description"><?php esc_html_e( 'Check this box to autoplay the slides.', 'vedanta' ); ?></p>
			</div>

			<div class="form-field form-field-checkbox">
				<label for="term_meta[loop]"><?php esc_html_e( 'Slide Loop', 'vedanta' ); ?></label>
				<input type="hidden" name="term_meta[loop]" id="term_meta[loop]" value="0">
				<input type="checkbox" name="term_meta[loop]" id="term_meta[loop]" value="1">
				<p class="description"><?php esc_html_e( 'Check this box to have the slider loop infinitely.', 'vedanta' ); ?></p>
			</div>

			<div class="form-field">
				<label for="term_meta[animation]"><?php esc_html_e( 'Animation', 'vedanta' ); ?></label>
				<select name="term_meta[animation]" id="term_meta[animation]">
					<option value="fade">Fade</option>
					<option value="slide">Slide</option>
				</select>
				<p class="description"><?php esc_html_e( 'The type of animation when slides rotate.', 'vedanta' ); ?></p>
			</div>

			<div class="form-field">
				<label for="term_meta[slideshow_speed]"><?php esc_html_e( 'Slideshow Speed', 'vedanta' ); ?></label>
				<input type="text" name="term_meta[slideshow_speed]" id="term_meta[slideshow_speed]" value="7000">
				<p class="description"><?php esc_html_e( 'Controls the speed of the slideshow. 1000 = 1 second.', 'vedanta' ); ?></p>
			</div>

			<div class="form-field">
				<label for="term_meta[animation_speed]"><?php esc_html_e( 'Animation Speed', 'vedanta' ); ?></label>
				<input type="text" name="term_meta[animation_speed]" id="term_meta[animation_speed]" value="600">
				<p class="description"><?php esc_html_e( 'Controls the speed of the slide transition from slide to slide. 1000 = 1 second.', 'vedanta' ); ?></p>
			</div>
			<?php
		}

		// Edit term page
		function slider_edit_meta_fields( $term ) {
			// put the term ID into a variable
			$t_id = $term->term_id;

			// retrieve the existing value(s) for this meta field. This returns an array
			$term_meta = get_option( "taxonomy_$t_id" );
			?>
			<tr class="form-field form-field-checkbox">
				<th scope="row" valign="top"><label for="term_meta[nav_arrows]"><?php esc_html_e( 'Display Navigation Arrows', 'vedanta' ); ?></label></th>
				<td>
					<input type="hidden" name="term_meta[nav_arrows]" id="term_meta[nav_arrows]" value="0">
					<input type="checkbox" name="term_meta[nav_arrows]" id="term_meta[nav_arrows]" value="1" <?php echo esc_attr( $term_meta[ 'nav_arrows' ] ) ? 'checked="checked"' : ''; ?>>
					<p class="description"><?php esc_html_e( 'Check this box to display the navigation arrows.', 'vedanta' ); ?></p>
				</td>
			</tr>

			<tr class="form-field form-field-checkbox">
				<th scope="row" valign="top"><label for="term_meta[pagination_circles]"><?php esc_html_e( 'Display Pagination Circles', 'vedanta' ); ?></label></th>
				<td>
					<input type="hidden" name="term_meta[pagination_circles]" id="term_meta[pagination_circles]" value="0">
					<input type="checkbox" name="term_meta[pagination_circles]" id="term_meta[pagination_circles]" value="1" <?php echo esc_attr( $term_meta[ 'pagination_circles' ] ) ? 'checked="checked"' : ''; ?>>
					<p class="description"><?php esc_html_e( 'Check this box to display the pagination circles.', 'vedanta' ); ?></p>
				</td>
			</tr>

			<tr class="form-field form-field-checkbox">
				<th scope="row" valign="top"><label for="term_meta[autoplay]"><?php esc_html_e( 'Autoplay', 'vedanta' ); ?></label></th>
				<td>
					<input type="hidden" name="term_meta[autoplay]" id="term_meta[autoplay]" value="0">
					<input type="checkbox" name="term_meta[autoplay]" id="term_meta[autoplay]" value="1" <?php echo esc_attr( $term_meta[ 'autoplay' ] ) ? 'checked="checked"' : ''; ?>>
					<p class="description"><?php esc_html_e( 'Check this box to autoplay the slides.', 'vedanta' ); ?></p>
				</td>
			</tr>

			<tr class="form-field form-field-checkbox">
				<th scope="row" valign="top"><label for="term_meta[loop]"><?php esc_html_e( 'Slide Loop', 'vedanta' ); ?></label></th>
				<td>
					<input type="hidden" name="term_meta[loop]" id="term_meta[loop]" value="0">
					<input type="checkbox" name="term_meta[loop]" id="term_meta[loop]" value="1" <?php echo esc_attr( $term_meta[ 'loop' ] ) ? 'checked="checked"' : ''; ?>>
					<p class="description"><?php esc_html_e( 'Check this box to have the slider loop infinitely.', 'vedanta' ); ?></p>
				</td>
			</tr>

			<tr class="form-field">
				<th scope="row" valign="top"><label for="term_meta[animation]"><?php esc_html_e( 'Animation', 'vedanta' ); ?></label></th>
				<td>
					<select name="term_meta[animation]" id="term_meta[animation]">
						<option value="fade" <?php echo ( esc_attr( $term_meta[ 'animation' ] ) == 'fade' ) ? 'selected="selected"' : ''; ?>>Fade</option>
						<option value="slide" <?php echo ( esc_attr( $term_meta[ 'animation' ] ) == 'slide' ) ? 'selected="selected"' : ''; ?>>Slide</option>
					</select>
					<p class="description"><?php esc_html_e( 'The type of animation when slides rotate.', 'vedanta' ); ?></p>
				</td>
			</tr>

			<tr class="form-field">
				<th scope="row" valign="top"><label for="term_meta[slideshow_speed]"><?php esc_html_e( 'Slideshow Speed', 'vedanta' ); ?></label></th>
				<td>
					<input type="text" name="term_meta[slideshow_speed]" id="term_meta[slideshow_speed]" value="<?php echo esc_attr( $term_meta[ 'slideshow_speed' ] ) ? esc_attr( $term_meta[ 'slideshow_speed' ] ) : ''; ?>">
					<p class="description"><?php esc_html_e( 'Controls the speed of the slideshow. 1000 = 1 second.', 'vedanta' ); ?></p>
				</td>
			</tr>

			<tr class="form-field">
				<th scope="row" valign="top"><label for="term_meta[animation_speed]"><?php esc_html_e( 'Animation Speed', 'vedanta' ); ?></label></th>
				<td>
					<input type="text" name="term_meta[animation_speed]" id="term_meta[animation_speed]" value="<?php echo esc_attr( $term_meta[ 'animation_speed' ] ) ? esc_attr( $term_meta[ 'animation_speed' ] ) : ''; ?>">
					<p class="description"><?php esc_html_e( 'Controls the speed of the slide transition from slide to slide. 1000 = 1 second.', 'vedanta' ); ?></p>
				</td>
			</tr>
			<?php
		}

		// Save extra taxonomy fields callback function.
		function slider_save_taxonomy_custom_meta( $term_id ) {
			if ( isset( $_POST[ 'term_meta' ] ) ) {
				$t_id		 = $term_id;
				$term_meta	 = get_option( "taxonomy_$t_id" );
				$cat_keys	 = array_keys( $_POST[ 'term_meta' ] );
				foreach ( $cat_keys as $key ) {
					if ( isset( $_POST[ 'term_meta' ][ $key ] ) ) {
						$term_meta[ $key ] = $_POST[ 'term_meta' ][ $key ];
					}
				}
				// Save the option array.
				update_option( "taxonomy_$t_id", $term_meta );
			}
		}

		// Export / Import Settings Page
		function ved_export_import_settings() {
			if ( $_FILES ) {
				$this->import_sliders( $_FILES[ 'import' ][ 'tmp_name' ] );
			}
			?>
			<div class="wrap">
				<h2><?php esc_html_e( 'Export and Import ThemeVedanta Sliders', 'vedanta' ); ?></h2>
				<form enctype="multipart/form-data" method="post" action="">
					<table class="form-table">
						<tr valign="top">
							<th scope="row"><?php esc_html_e( 'Export', 'vedanta' ); ?></th>
							<td><input type="submit" class="button button-primary" name="export_button" value="<?php esc_attr( 'Export All Sliders', 'vedanta' ); ?>" /></td>
						</tr>
						<tr valign="top">
							<th>
								<label for="upload"><?php esc_html_e( 'Choose a file from your computer:', 'vedanta' ); ?></label>
							</th>
							<td>
								<input type="file" id="upload" name="import" size="25" />
								<input type="hidden" name="action" value="save" />
								<input type="hidden" name="max_file_size" value="33554432" />
								<p class="submit"><input type="submit" name="upload" id="submit" class="button" value="Upload file and import"  /></p>
							</td>
						</tr>
					</table>
				</form>
			</div>
			<?php
		}

		function export_sliders() {
			if ( isset( $_POST[ 'export_button' ] ) && $_POST[ 'export_button' ] ) {
				// Load Importer API
				require_once ABSPATH . 'wp-admin/includes/export.php';

				ob_start();
				export_wp( array(
					'content' => 'slide',
				) );
				$export = ob_get_contents();
				ob_get_clean();

				$terms = get_terms( 'slide-page', array(
					'hide_empty' => 1
				) );

				foreach ( $terms as $term ) {
					$term_meta			 = get_option( 'taxonomy_' . $term->term_id );
					$export_terms[ $term->slug ]	 = $term_meta;
				}

				$json_export_terms = json_encode( $export_terms );

				$upload_dir	 = wp_upload_dir();
				$base_dir	 = trailingslashit( $upload_dir[ 'basedir' ] );
				$ved_dir	 = $base_dir . 'ved_slider/';

				$loop = new WP_Query( array( 'post_type' => 'slide', 'posts_per_page' => -1, 'meta_key' => '_thumbnail_id' ) );

				while ( $loop->have_posts() ) {
					$loop->the_post();
					$post_image_id	 = get_post_thumbnail_id( get_the_ID() );
					$image_path	 = get_attached_file( $post_image_id );
					if ( isset( $image_path ) && $image_path ) {
						$ext = pathinfo( $image_path, PATHINFO_EXTENSION );
						@copy( $image_path, $ved_dir . $post_image_id . '.' . $ext );
					}
				}

				wp_reset_query();

				$url	 = wp_nonce_url( 'edit.php?post_type=slide&page=ved_export_import' );
				if ( false === ($creds	 = request_filesystem_credentials( $url, '', false, false, null ) ) ) {
					return; // stop processing here
				}

				wp_mkdir_p( $ved_dir );

				if ( WP_Filesystem( $creds ) ) {
					global $wp_filesystem;

					if ( ! $wp_filesystem->put_contents( $ved_dir . 'sliders.xml', $export, FS_CHMOD_FILE ) || ! $wp_filesystem->put_contents( $ved_dir . 'settings.json', $json_export_terms, FS_CHMOD_FILE ) ) {
						echo 'Couldn\'t export sliders, make sure wp-content/uploads is writeable.';
					} else {
						// Initialize archive object
						$zip = new ZipArchive;
						$zip->open( 'ved_slider.zip', ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE );

						foreach ( new DirectoryIterator( $ved_dir ) as $file ) {
							if ( $file->isDot() ) {
								continue;
							}

							$zip->addFile( $ved_dir . $file->getFilename(), $file->getFilename() );
						}

						$zip_file = $zip->filename;

						// Zip archive will be created only after closing object
						$zip->close();

						header( 'Content-type: application/zip' );
						header( 'Content-Disposition: attachment; filename="ved_slider.zip"' );
						header( 'Content-length: ' . filesize( $zip_file ) );
						header( 'Pragma: no-cache' );
						header( 'Expires: 0' );
						readfile( $zip_file );

						foreach ( new DirectoryIterator( $ved_dir ) as $file ) {
							if ( $file->isDot() ) {
								continue;
							}

							@unlink( $ved_dir . $file->getFilename() );
						}
					}
				}
			}
		}

		function import_sliders( $zip_file ) {
			$upload_dir	 = wp_upload_dir();
			$base_dir	 = trailingslashit( $upload_dir[ 'basedir' ] );
			$ved_dir	 = $base_dir . 'ved_slider_exports/';

			@unlink( $ved_dir . 'sliders.xml' );
			@unlink( $ved_dir . 'settings.json' );

			$zip = new ZipArchive();
			$zip->open( $zip_file );
			$zip->extractTo( $ved_dir );
			$zip->close();

			if ( ! defined( 'WP_LOAD_IMPORTERS' ) ) {
				define( 'WP_LOAD_IMPORTERS', true );
			}

			if ( class_exists( 'WP_Importer' ) ) {
				$importer			 = new Vedanta_Theme_Import();
				$xml				 = $ved_dir . 'sliders.xml';
				$importer->fetch_attachments	 = true;
				$flag = 'content';
				ob_start();
				$importer->import( $xml, $flag );
				ob_end_clean();

				$loop = new WP_Query( array( 'post_type' => 'slide', 'posts_per_page' => -1, 'meta_key' => '_thumbnail_id' ) );

				while ( $loop->have_posts() ) {
					$loop->the_post();
					$thumbnail_ids[ get_post_meta( get_the_ID(), '_thumbnail_id', true ) ] = get_the_ID();
				}

				foreach ( new DirectoryIterator( $ved_dir ) as $file ) {
					if ( $file->isDot() || $file->getFilename() == '.DS_Store' ) {
						continue;
					}

					$image_path = pathinfo( $ved_dir . $file->getFilename() );
					if ( $image_path[ 'extension' ] != 'xml' && $image_path[ 'extension' ] != 'json' ) {
						$filename	 = $image_path[ 'filename' ];
						$new_image_path	 = $upload_dir[ 'path' ] . '/' . $image_path[ 'basename' ];
						$new_image_url	 = $upload_dir[ 'url' ] . '/' . $image_path[ 'basename' ];
						@copy( $ved_dir . $file->getFilename(), $new_image_path );

						// Check the type of tile. We'll use this as the 'post_mime_type'.
						$filetype = wp_check_filetype( basename( $new_image_path ), null );

						// Prepare an array of post data for the attachment.
						$attachment = array(
							'guid'		 => $new_image_url,
							'post_mime_type' => $filetype[ 'type' ],
							'post_title'	 => preg_replace( '/\.[^.]+$/', '', basename( $new_image_path ) ),
							'post_content'	 => '',
							'post_status'	 => 'inherit'
						);

						// Insert the attachment.
						$attach_id = wp_insert_attachment( $attachment, $new_image_path, $thumbnail_ids[ $filename ] );

						// Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
						require_once( ABSPATH . 'wp-admin/includes/image.php' );

						// Generate the metadata for the attachment, and update the database record.
						$attach_data = wp_generate_attachment_metadata( $attach_id, $new_image_path );
						wp_update_attachment_metadata( $attach_id, $attach_data );

						set_post_thumbnail( $thumbnail_ids[ $filename ], $attach_id );
					}
				}

				$url	 = wp_nonce_url( 'edit.php?post_type=slide&page=ved_export_import' );
				if ( false === ($creds	 = request_filesystem_credentials( $url, '', false, false, null ) ) ) {
					return; // stop processing here
				}

				if ( WP_Filesystem( $creds ) ) {
					global $wp_filesystem;

					$settings = $wp_filesystem->get_contents( $ved_dir . 'settings.json' );

					$decode = json_decode( $settings, TRUE );

					foreach ( $decode as $slug => $settings ) {
						$get_term = get_term_by( 'slug', $slug, 'slide-page' );

						if ( $get_term ) {
							update_option( 'taxonomy_' . $get_term->term_id, $settings );
						}
					}
				}
			}
		}

	}

	$ved_slider = new ThemeVedanta_Slider();
}