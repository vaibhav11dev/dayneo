<?php
namespace Elementor;

function ved_elementor_init() {
	Plugin::instance()->elements_manager->add_category(
	'vedanta', [
		'title'	 => 'Vedanta Addons',
		'icon'	 => 'font'
	], 1
	);
}
add_action( 'elementor/init', 'Elementor\ved_elementor_init' );

function ved_enable_elementor(){
    add_post_type_support( 'ved_templates', 'elementor' );
}
add_action('elementor/init','Elementor\ved_enable_elementor');

function ved_vedanta_template($atts) {
    if(!class_exists('Elementor\Plugin')){
        return '';
    }
    if(!isset($atts['id']) || empty($atts['id'])){
        return '';
    }

    $post_id = $atts['id'];
    $response = Plugin::instance()->frontend->get_builder_content_for_display($post_id);
    return $response;
}
add_shortcode('VEDANTA_TEMPLATE','Elementor\ved_vedanta_template');





