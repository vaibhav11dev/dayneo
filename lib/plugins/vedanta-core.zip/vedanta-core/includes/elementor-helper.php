<?php

namespace Elementor;

function ved_elementor_init() {
	Plugin::instance()->elements_manager->add_category(
	'vedanta', [
		'title'	 => 'Vedanta Addons',
		'icon'	 => 'font'
	], 1
	);
}

add_action( 'elementor/init', 'Elementor\ved_elementor_init' );



