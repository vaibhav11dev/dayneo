<?php

/**
 * Get Post Data
 * @param  array $args
 * @return array
 */
function ved_get_post_data( $args ) {
	$defaults = array(
		'posts_per_page'	 => 5,
		'offset'			 => 0,
		'category'			 => '',
		'category_name'		 => '',
		'orderby'			 => 'date',
		'order'				 => 'DESC',
		'include'			 => '',
		'exclude'			 => '',
		'meta_key'			 => '',
		'meta_value'		 => '',
		'post_type'			 => 'post',
		'post_mime_type'	 => '',
		'post_parent'		 => '',
		'author'			 => '',
		'author_name'		 => '',
		'post_status'		 => 'publish',
		'suppress_filters'	 => true
	);

	$atts = wp_parse_args( $args, $defaults );

	$posts = get_posts( $atts );

	return $posts;
}

/**
 * Get All POst Types
 * @return array
 */
function ved_get_post_types() {

	$ved_cpts			 = get_post_types( array( 'public' => true, 'show_in_nav_menus' => true ) );
	$ved_exclude_cpts	 = array( 'elementor_library', 'attachment', 'product' );

	foreach ( $ved_exclude_cpts as $exclude_cpt ) {
		unset( $ved_cpts[ $exclude_cpt ] );
	}

	$post_types = array_merge( $ved_cpts );
	return $post_types;
}

/**
 * Add REST API support to an already registered post type.
 */
add_action( 'init', 'ved_custom_post_type_rest_support', 25 );

function ved_custom_post_type_rest_support() {
	global $wp_post_types;

	$post_types = ved_get_post_types();
	foreach ( $post_types as $post_type ) {
		if ( $post_type === 'post' ) : $post_type = 'posts';
		endif;
		if ( $post_type === 'page' ) : $post_type = 'pages';
		endif;
		$post_type_name = $post_type;
		if ( isset( $wp_post_types[ $post_type_name ] ) ) {
			$wp_post_types[ $post_type_name ]->show_in_rest			 = true;
			$wp_post_types[ $post_type_name ]->rest_base			 = $post_type_name;
			$wp_post_types[ $post_type_name ]->rest_controller_class = 'WP_REST_Posts_Controller';
		}
	}
}

/**
 * Post Settings Parameter
 * @param  array $settings
 * @return array
 */
function ved_get_post_settings( $settings ) {

	$post_args[ 'category' ]		 = $settings[ 'ved_post_category' ];
	$post_args[ 'posts_per_page' ]	 = $settings[ 'ved_posts_count' ];
	$post_args[ 'offset' ]			 = $settings[ 'ved_post_offset' ];
	$post_args[ 'orderby' ]			 = $settings[ 'ved_post_orderby' ];
	$post_args[ 'order' ]			 = $settings[ 'ved_post_order' ];

	return $post_args;
}

/**
 * Recent Work Settings Parameter
 * @param  array $settings
 * @return array
 */
function ved_get_recent_work_settings( $settings ) {
	$recent_work_args = array(
		'post_type'		 => 'vedanta_portfolio',
		'posts_per_page' => $settings[ 'ved_recent_work_count' ],
		'offset'		 => $settings[ 'ved_ved_posts_count_offset' ],
		'orderby'		 => $settings[ 'ved_ved_posts_count_orderby' ],
		'order'			 => $settings[ 'ved_ved_posts_count_order' ],
	);

	return $recent_work_args;
}

/**
 * Getting Excerpts By Post Id
 * @param  int $post_id
 * @param  int $excerpt_length
 * @return string
 */
function ved_get_excerpt_by_id( $post_id, $excerpt_length ) {
	$the_post = get_post( $post_id ); //Gets post ID

	$the_excerpt = null;
	if ( $the_post ) {
		$the_excerpt = $the_post->post_excerpt ? $the_post->post_excerpt : $the_post->post_content;
	}

	$the_excerpt = strip_tags( strip_shortcodes( $the_excerpt ) ); //Strips tags and images
	$words		 = explode( ' ', $the_excerpt, $excerpt_length + 1 );

	if ( count( $words ) > $excerpt_length ) :
		array_pop( $words );
		array_push( $words, '…' );
		$the_excerpt = implode( ' ', $words );
	endif;

	return $the_excerpt;
}

/**
 * Get Post Thumbnail Size
 * @return array
 */
function ved_get_thumbnail_sizes() {
	$sizes = get_intermediate_image_sizes();
	foreach ( $sizes as $s ) {
		$ret[ $s ] = $s;
	}

	return $ret;
}

/**
 * POst Orderby Options
 * @return array
 */
function ved_get_post_orderby_options() {
	$orderby = array(
		'ID'			 => 'Post ID',
		'author'		 => 'Post Author',
		'title'			 => 'Title',
		'date'			 => 'Date',
		'modified'		 => 'Last Modified Date',
		'parent'		 => 'Parent Id',
		'rand'			 => 'Random',
		'comment_count'	 => 'Comment Count',
		'menu_order'	 => 'Menu Order',
	);

	return $orderby;
}

/**
 * Get Post Categories
 * @return array
 */
function ved_post_type_categories() {
	$terms = get_terms( array(
		'taxonomy'	 => 'category',
		'hide_empty' => true,
	) );

	if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
	}
	if ( !empty( $options ) )
		return $options;
}

/**
 * Get Dynamic Post Categories
 * @return array
 */
function ved_all_post_type_categories() {
	global $wpdb;

	$results = array();

	foreach ( $wpdb->get_results( "
        SELECT terms.slug AS 'slug', terms.name AS 'label', termtaxonomy.taxonomy AS 'type'
        FROM $wpdb->terms AS terms
        JOIN $wpdb->term_taxonomy AS termtaxonomy ON terms.term_id = termtaxonomy.term_id
        LIMIT 100
    " ) as $result ) {
		$results[ $result->type . ':' . $result->slug ] = $result->type . ':' . $result->label;
	}
	return $results;
}

/**
 * WooCommerce Product Query
 * @return array
 */
function ved_woocommerce_product_categories() {
	$terms = get_terms( array(
		'taxonomy'	 => 'product_cat',
		'hide_empty' => true,
	) );

	if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->slug ] = $term->name;
		}
		return $options;
	}
}

/**
 * WooCommerce Get Product By Id
 * @return array
 */
function ved_woocommerce_product_get_product_by_id() {
	$postlist	 = get_posts( array(
		'post_type'	 => 'product',
		'showposts'	 => 9999,
	) );
	$posts		 = array();

	if ( !empty( $postlist ) && !is_wp_error( $postlist ) ) {
		foreach ( $postlist as $post ) {
			$options[ $post->ID ] = $post->post_title;
		}
		return $options;
	}
}

/**
 * WooCommerce Get Product Category By Id
 * @return array
 */
function ved_woocommerce_product_categories_by_id() {
	$terms = get_terms( array(
		'taxonomy'	 => 'product_cat',
		'hide_empty' => true,
	) );

	if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
		return $options;
	}
}

function ved_get_category_post_count() {
	global $post;
	$categories	 = explode( ',', $_POST[ 'catId' ] );
	$post_count	 = 0;
	foreach ( $categories as $cat ) {
		$category	 = get_category( $cat );
		$post_count	 = $post_count + $category->category_count;
	}

	$return_array = array(
		'post_count' => $post_count,
		'cat'		 => $categories
	);

	wp_send_json( $return_array );
	die();
}

add_action( 'wp_ajax_get_category_post_count', 'ved_get_category_post_count' );


// Get all elementor page templates
if ( !function_exists( 'ved_get_page_templates' ) ) {

	function ved_get_page_templates() {
		$page_templates = get_posts( array(
			'post_type'		 => 'elementor_library',
			'posts_per_page' => -1
		) );

		$options = array();

		if ( !empty( $page_templates ) && !is_wp_error( $page_templates ) ) {
			foreach ( $page_templates as $post ) {
				$options[ $post->ID ] = $post->post_title;
			}
		}
		return $options;
	}

}

/* vedanta-core read more button */
if ( !function_exists( 'ved_post_readmore' ) ) {

	function ved_post_readmore() {
		?>
		<a href="<?php the_permalink() ?>" class="read-more"><?php esc_html_e( 'Read more', 'vedanta' ) ?><i class="fa fa-angle-right"></i></a>
		<?php
	}

}

/* vedanta-core post metadata */
if ( !function_exists( 'ved_post_metadata' ) ) {

	function ved_post_metadata( $settings ) {
		global $authordata;

		if ( $settings[ 'ved_post_block_meta_author' ] == 'yes' ) {
			?>
			<li class="author vcard">
				<?php
				esc_html_e( 'By ', 'vedanta' );

				if ( $settings[ 'ved_post_block_meta_avtar' ] == 'yes' ) {
					echo get_avatar( get_the_author_meta( 'email' ), '30' );
				}

				printf( '<a class="url fn" href="' . esc_url( get_author_posts_url( $authordata->ID, $authordata->user_nicename ) ) . '" title="' . sprintf( 'View all posts by %s', 'vedanta', esc_attr( $authordata->display_name ) ) . '">' . get_the_author() . '</a>' )
				?>
			</li>
			<?php
		}

		if ( ved_get_terms( 'tags' ) && $settings[ 'ved_post_block_meta_tags' ] == 'yes' ) :
			?>
			<li class="meta-tags">
				<?php echo ved_get_terms( 'tags' ); ?>
			</li>
			<?php
		endif;

		if ( comments_open() && $settings[ 'ved_post_block_meta_comments' ] == 'yes' ) :
			?>
			<li class="comment-count">
				<?php comments_popup_link( esc_html__( 'Leave a Comment', 'vedanta' ), esc_html__( '1 Comment', 'vedanta' ), esc_html__( '% Comments', 'vedanta' ) ); ?>
			</li>
			<?php
		endif;
	}

}

if ( !function_exists( 'ved_get_terms' ) ) {

	function ved_get_terms( $term = NULL, $glue = ', ' ) {
		if ( !$term ) {
			return;
		}

		$separator = "\n";

		switch ( $term ):
			case 'cats':
				$current = single_cat_title( '', false );
				$terms	 = get_the_category_list( $separator );
				break;
			case 'tags':
				$current = single_tag_title( '', '', false );
				$terms	 = get_the_tag_list( '', "$separator", '' );
				break;
		endswitch;

		if ( empty( $terms ) ) {
			return;
		}

		$thing = explode( $separator, $terms );

		if ( empty( $thing ) ) {
			return false;
		}

		return trim( join( $glue, $thing ) );
	}

}


/*
 * WP Kses Allowed HTML Tags Array in function
 * @Since Version 0.1
 * @param ar
 * Use: ved_kses($raw_string);
 * */

function ved_kses( $raw ) {

	$allowed_tags = array(
		'a'								 => array(
			'class'	 => array(),
			'href'	 => array(),
			'rel'	 => array(),
			'title'	 => array(),
		),
		'abbr'							 => array(
			'title' => array(),
		),
		'b'								 => array(),
		'blockquote'					 => array(
			'cite' => array(),
		),
		'cite'							 => array(
			'title' => array(),
		),
		'code'							 => array(),
		'del'							 => array(
			'datetime'	 => array(),
			'title'		 => array(),
		),
		'dd'							 => array(),
		'div'							 => array(
			'class'	 => array(),
			'title'	 => array(),
			'style'	 => array(),
		),
		'dl'							 => array(),
		'dt'							 => array(),
		'em'							 => array(),
		'h1'							 => array(),
		'h2'							 => array(),
		'h3'							 => array(),
		'h4'							 => array(),
		'h5'							 => array(),
		'h6'							 => array(),
		'i'								 => array(
			'class' => array(),
		),
		'img'							 => array(
			'alt'	 => array(),
			'class'	 => array(),
			'height' => array(),
			'src'	 => array(),
			'width'	 => array(),
		),
		'li'							 => array(
			'class' => array(),
		),
		'ol'							 => array(
			'class' => array(),
		),
		'p'								 => array(
			'class' => array(),
		),
		'q'								 => array(
			'cite'	 => array(),
			'title'	 => array(),
		),
		'span'							 => array(
			'class'	 => array(),
			'title'	 => array(),
			'style'	 => array(),
		),
		'strike'						 => array(),
		'br'							 => array(),
		'strong'						 => array(),
		'data-wow-duration'				 => array(),
		'data-wow-delay'				 => array(),
		'data-wallpaper-options'		 => array(),
		'data-stellar-background-ratio'	 => array(),
		'ul'							 => array(
			'class' => array(),
		),
	);

	if ( function_exists( 'wp_kses' ) ) { // WP is here
		$allowed = wp_kses( $raw, $allowed_tags );
	} else {
		$allowed = $raw;
	}


	return $allowed;
}

if ( !function_exists( 'ved_resize' ) ) {

	function ved_resize( $id, $width = false, $height = false, $crop = false ) {
		if ( function_exists( 'fw_resize' ) ) {
			$url = wp_get_attachment_image_src( $id, 'full' );

			return fw_resize( $url[ 0 ], $width, $height, $crop );
		} else {
			$response = wp_get_attachment_image_src( $id, array( $width, $height ) );
			if ( !empty( $response ) ) {
				return $response[ 0 ];
			}
		}
	}

}

// simply echos the variable
function ved_return( $s ) {
	return $s;
}

function ved_get_sell_price( $ved_id ) {
	$ved_product = wc_get_product( $ved_id );
	if ( $ved_product->is_type( 'variable' ) ) {
		$var_regular_price		 = array();
		$var_sale_price			 = array();
		$var_diff_price			 = array();
		$available_variations	 = $ved_product->get_available_variations();
		foreach ( $available_variations as $key => $available_variation ) {
			$variation_id		 = $available_variation[ 'variation_id' ]; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
			$variable_product	 = new WC_Product_Variation( $variation_id );

			$variable_product_regular_price	 = $variable_product->get_regular_price();
			$variable_product_sale_price	 = $variable_product->get_sale_price();

			if ( !empty( $variable_product_regular_price ) ) {
				$var_regular_price[] = $variable_product_regular_price;
			} else {
				$var_regular_price[] = 0;
			}
			if ( !empty( $variable_product_sale_price ) ) {
				$var_sale_price[] = $variable_product_sale_price;
			} else {
				$var_sale_price[] = 0;
			}
		}

		foreach ( $var_regular_price as $key => $reg_price ) {
			if ( isset( $var_sale_price[ $key ] ) && $var_sale_price[ $key ] !== 0 ) {
				$var_diff_price[] = $reg_price - $var_sale_price[ $key ];
			} else {
				$var_diff_price[] = 0;
			}
		}

		$best_key = array_search( max( $var_diff_price ), $var_diff_price );

		$regular_price	 = $var_regular_price[ $best_key ];
		$sale_price		 = $var_sale_price[ $best_key ];
	} else {
		$regular_price	 = $ved_product->get_regular_price();
		$sale_price		 = $ved_product->get_sale_price();
	}

	$regular_price	 = wc_get_price_to_display( $ved_product, array( 'qty' => 1, 'price' => $regular_price ) );
	$sale_price		 = wc_get_price_to_display( $ved_product, array( 'qty' => 1, 'price' => $sale_price ) );

	$savings = ceil( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 ) . '%';

	return $savings;
}

function ved_get_template_part( $slug, $name = null ) {
	ob_start();
	get_template_part( $slug, $name );
	$content = ob_get_contents();
	ob_end_clean();
	echo $content;
}

/**
 * List all products on sale.
 *
 * @param array $atts
 * @return string
 */
function vedanta_sale_products( $atts ) {
	$atts = shortcode_atts( array(
		'per_page'	 => '12',
		'columns'	 => '4',
		'orderby'	 => 'title',
		'order'		 => 'asc',
		'post__in'	 => ''
	), $atts );

	$post_in = wc_get_product_ids_on_sale();

	if ( !empty( $atts[ 'post__in' ] ) ) {
		$atts[ 'post__in' ]	 = is_array( $atts[ 'post__in' ] ) ? $atts[ 'post__in' ] : explode( ',', $atts[ 'post__in' ] );
		$atts[ 'post__in' ]	 = array_map( 'trim', $atts[ 'post__in' ] );
		$post_in			 = array_intersect( $post_in, $atts[ 'post__in' ] );
	}

	$query_args = array(
		'posts_per_page' => $atts[ 'per_page' ],
		'orderby'		 => $atts[ 'orderby' ],
		'order'			 => $atts[ 'order' ],
		'no_found_rows'	 => 1,
		'post_status'	 => 'publish',
		'post_type'		 => 'product',
		'meta_query'	 => WC()->query->get_meta_query(),
		'post__in'		 => array_merge( array( 0 ), $post_in )
	);

	return new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $query_args, $atts ) );
}

/**
 * Check for discount value and percentage.
 *
 * @param array $atts
 * @return string
 */
function vedanta_get_savings_on_sale( $product, $in = 'amount' ) {

	if ( !$product->is_on_sale() ) {
		return 0;
	}

	if ( $product->is_type( 'variable' ) ) {
		$var_regular_price		 = array();
		$var_sale_price			 = array();
		$var_diff_price			 = array();
		$available_variations	 = $product->get_available_variations();
		foreach ( $available_variations as $key => $available_variation ) {
			$variation_id		 = $available_variation[ 'variation_id' ]; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
			$variable_product	 = new WC_Product_Variation( $variation_id );

			$variable_product_regular_price	 = $variable_product->get_regular_price();
			$variable_product_sale_price	 = $variable_product->get_sale_price();

			if ( !empty( $variable_product_regular_price ) ) {
				$var_regular_price[] = $variable_product_regular_price;
			} else {
				$var_regular_price[] = 0;
			}
			if ( !empty( $variable_product_sale_price ) ) {
				$var_sale_price[] = $variable_product_sale_price;
			} else {
				$var_sale_price[] = 0;
			}
		}

		foreach ( $var_regular_price as $key => $reg_price ) {
			if ( isset( $var_sale_price[ $key ] ) && $var_sale_price[ $key ] !== 0 ) {
				$var_diff_price[] = $reg_price - $var_sale_price[ $key ];
			} else {
				$var_diff_price[] = 0;
			}
		}

		$best_key = array_search( max( $var_diff_price ), $var_diff_price );

		$regular_price	 = $var_regular_price[ $best_key ];
		$sale_price		 = $var_sale_price[ $best_key ];
	} else {
		$regular_price	 = $product->get_regular_price();
		$sale_price		 = $product->get_sale_price();
	}

	$regular_price	 = wc_get_price_to_display( $product, array( 'qty' => 1, 'price' => $regular_price ) );
	$sale_price		 = wc_get_price_to_display( $product, array( 'qty' => 1, 'price' => $sale_price ) );

	if ( 'amount' === $in ) {

		$savings = wc_price( $regular_price - $sale_price );
	} elseif ( 'percentage' === $in ) {

		$savings = '<span class="percentage">' . round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 ) . '%</span>';
	}

	return $savings;
}

/**
 * Share link socials
 *
 * @since  1.0
 */
if ( !function_exists( 'vedanta_share_link_socials' ) ) :

	function vedanta_share_link_socials( $tooltip_position, $title, $link, $media ) {
		$ved_sharing_twitter = bigbo_get_option( 'ved_sharing_twitter', '0' );
		$ved_sharing_facebook = bigbo_get_option( 'ved_sharing_facebook', '0' );
		$ved_sharing_google = bigbo_get_option( 'ved_sharing_google', '0' );
		$ved_sharing_pinterest = bigbo_get_option( 'ved_sharing_pinterest', '0' );
		$ved_sharing_linkedin = bigbo_get_option( 'ved_sharing_linkedin', '0' );
		$ved_sharing_email = bigbo_get_option( 'ved_sharing_email', '0' );
		$ved_sharing_more_options = bigbo_get_option( 'ved_sharing_more_options', '0' );

		$socials_html		 = '';
		if ( $ved_sharing_twitter ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://twitter.com/share?text=%s&url=%s" target="_blank"><i class="fa fa-twitter"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Twitter', 'vedanta' ), urlencode( $title ), urlencode( $link )
			);
		}

		if ( $ved_sharing_facebook ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.facebook.com/sharer.php?u=%s&t=%s" target="_blank"><i class="fa fa-facebook"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Facebook', 'vedanta' ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_google ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="https://plus.google.com/share?url=%s&text=%s" target="_blank"><i class="fa fa-google-plus"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Google Plus', 'vedanta' ), urlencode( $link ), \ urlencode( $title )
			);
		}

		if ( $ved_sharing_pinterest ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://pinterest.com/pin/create/button?media=%s&url=%s&description=%s" target="_blank"><i class="fa fa-pinterest"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Pinterest', 'vedanta' ), urlencode( $media ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_linkedin ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.linkedin.com/shareArticle?url=%s&title=%s" target="_blank"><i class="fa fa-linkedin-square"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Linkedin', 'vedanta' ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_email ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.addtoany.com/email?linkurl=%s&linkname=%s" target="_blank"><i class="fa fa-envelope-o"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Email', 'vedanta' ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_more_options ) {
			$socials_html .= sprintf(
			'<a data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.addtoany.com/share_save#url=%s&linkname=%s" target="_blank"><i class="icon-action-redo icons ti-plus"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'More options', 'vedanta' ), urlencode( $link ), urlencode( $title )
			);
		}
		
		if ( $socials_html ) {
			printf( '<div class="share-this">%s</div>', $socials_html );
		}
	}

endif;
