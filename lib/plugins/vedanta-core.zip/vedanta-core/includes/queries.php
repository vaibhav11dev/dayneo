<?php

/**
 * Get Post Data
 * @param  array $args
 * @return array
 */
function ved_get_post_data( $args ) {
	$defaults = array(
		'posts_per_page'	 => 5,
		'offset'		 => 0,
		'category'		 => '',
		'category_name'		 => '',
		'orderby'		 => 'date',
		'order'			 => 'DESC',
		'include'		 => '',
		'exclude'		 => '',
		'meta_key'		 => '',
		'meta_value'		 => '',
		'post_type'		 => 'post',
		'post_mime_type'	 => '',
		'post_parent'		 => '',
		'author'		 => '',
		'author_name'		 => '',
		'post_status'		 => 'publish',
		'suppress_filters'	 => true
	);

	$atts = wp_parse_args( $args, $defaults );

	$posts = get_posts( $atts );

	return $posts;
}

/**
 * Get All POst Types
 * @return array
 */
function ved_get_post_types() {

	$ved_cpts		 = get_post_types( array( 'public' => true, 'show_in_nav_menus' => true ) );
	$ved_exclude_cpts	 = array( 'elementor_library', 'attachment', 'product' );

	foreach ( $ved_exclude_cpts as $exclude_cpt ) {
		unset( $ved_cpts[ $exclude_cpt ] );
	}

	$post_types = array_merge( $ved_cpts );
	return $post_types;
}

/**
 * Add REST API support to an already registered post type.
 */
add_action( 'init', 'ved_custom_post_type_rest_support', 25 );

function ved_custom_post_type_rest_support() {
	global $wp_post_types;

	$post_types = ved_get_post_types();
	foreach ( $post_types as $post_type ) {
		if ( $post_type === 'post' ) : $post_type = 'posts';
		endif;
		if ( $post_type === 'page' ) : $post_type = 'pages';
		endif;
		$post_type_name = $post_type;
		if ( isset( $wp_post_types[ $post_type_name ] ) ) {
			$wp_post_types[ $post_type_name ]->show_in_rest		 = true;
			$wp_post_types[ $post_type_name ]->rest_base		 = $post_type_name;
			$wp_post_types[ $post_type_name ]->rest_controller_class = 'WP_REST_Posts_Controller';
		}
	}
}

/**
 * Post Settings Parameter
 * @param  array $settings
 * @return array
 */
function ved_get_post_settings( $settings ) {

	$post_args[ 'category' ]	 = $settings[ 'ved_post_category' ];
	$post_args[ 'posts_per_page' ]	 = $settings[ 'ved_posts_count' ];
	$post_args[ 'offset' ]		 = $settings[ 'ved_post_offset' ];
	$post_args[ 'orderby' ]		 = $settings[ 'ved_post_orderby' ];
	$post_args[ 'order' ]		 = $settings[ 'ved_post_order' ];

	return $post_args;
}

/**
 * Recent Work Settings Parameter
 * @param  array $settings
 * @return array
 */
function ved_get_recent_work_settings( $settings ) {
	$recent_work_args		 = array(
		'post_type'	 => 'daydream_portfolio',
		'posts_per_page' => $settings[ 'ved_recent_work_count' ],
		'offset'	 => $settings[ 'ved_ved_posts_count_offset' ],
		'orderby'	 => $settings[ 'ved_ved_posts_count_orderby' ],
		'order'		 => $settings[ 'ved_ved_posts_count_order' ],
	);

	return $recent_work_args;
}

/**
 * Getting Excerpts By Post Id
 * @param  int $post_id
 * @param  int $excerpt_length
 * @return string
 */
function ved_get_excerpt_by_id( $post_id, $excerpt_length ) {
	$the_post = get_post( $post_id ); //Gets post ID

	$the_excerpt = null;
	if ( $the_post ) {
		$the_excerpt = $the_post->post_excerpt ? $the_post->post_excerpt : $the_post->post_content;
	}

	$the_excerpt	 = strip_tags( strip_shortcodes( $the_excerpt ) ); //Strips tags and images
	$words		 = explode( ' ', $the_excerpt, $excerpt_length + 1 );

	if ( count( $words ) > $excerpt_length ) :
		array_pop( $words );
		array_push( $words, '…' );
		$the_excerpt = implode( ' ', $words );
	endif;

	return $the_excerpt;
}

/**
 * Get Post Thumbnail Size
 * @return array
 */
function ved_get_thumbnail_sizes() {
	$sizes = get_intermediate_image_sizes();
	foreach ( $sizes as $s ) {
		$ret[ $s ] = $s;
	}

	return $ret;
}

/**
 * POst Orderby Options
 * @return array
 */
function ved_get_post_orderby_options() {
	$orderby = array(
		'ID'		 => 'Post ID',
		'author'	 => 'Post Author',
		'title'		 => 'Title',
		'date'		 => 'Date',
		'modified'	 => 'Last Modified Date',
		'parent'	 => 'Parent Id',
		'rand'		 => 'Random',
		'comment_count'	 => 'Comment Count',
		'menu_order'	 => 'Menu Order',
	);

	return $orderby;
}

/**
 * Get Post Categories
 * @return array
 */
function ved_post_type_categories() {
	$terms = get_terms( array(
		'taxonomy'	 => 'category',
		'hide_empty'	 => true,
	) );

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
	}
	if ( ! empty( $options ) )
		return $options;
}

/**
 * Get Dynamic Post Categories
 * @return array
 */
function ved_all_post_type_categories() {
	global $wpdb;

	$results = array();

	foreach ( $wpdb->get_results( "
        SELECT terms.slug AS 'slug', terms.name AS 'label', termtaxonomy.taxonomy AS 'type'
        FROM $wpdb->terms AS terms
        JOIN $wpdb->term_taxonomy AS termtaxonomy ON terms.term_id = termtaxonomy.term_id
        LIMIT 100
    " ) as $result ) {
		$results[ $result->type . ':' . $result->slug ] = $result->type . ':' . $result->label;
	}
	return $results;
}

/**
 * WooCommerce Product Query
 * @return array
 */
function ved_woocommerce_product_categories() {
	$terms = get_terms( array(
		'taxonomy'	 => 'product_cat',
		'hide_empty'	 => true,
	) );

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->slug ] = $term->name;
		}
		return $options;
	}
}

/**
 * WooCommerce Get Product By Id
 * @return array
 */
function ved_woocommerce_product_get_product_by_id() {
	$postlist	 = get_posts( array(
		'post_type'	 => 'product',
		'showposts'	 => 9999,
	) );
	$posts		 = array();

	if ( ! empty( $postlist ) && ! is_wp_error( $postlist ) ) {
		foreach ( $postlist as $post ) {
			$options[ $post->ID ] = $post->post_title;
		}
		return $options;
	}
}

/**
 * WooCommerce Get Product Category By Id
 * @return array
 */
function ved_woocommerce_product_categories_by_id() {
	$terms = get_terms( array(
		'taxonomy'	 => 'product_cat',
		'hide_empty'	 => true,
	) );

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
		return $options;
	}
}

function ved_get_category_post_count() {
	global $post;
	$categories	 = explode( ',', $_POST[ 'catId' ] );
	$post_count	 = 0;
	foreach ( $categories as $cat ) {
		$category	 = get_category( $cat );
		$post_count	 = $post_count + $category->category_count;
	}

	$return_array = array(
		'post_count'	 => $post_count,
		'cat'		 => $categories
	);

	wp_send_json( $return_array );
	die();
}

add_action( 'wp_ajax_get_category_post_count', 'ved_get_category_post_count' );


// Get all elementor page templates
if ( ! function_exists( 'ved_get_page_templates' ) ) {

	function ved_get_page_templates() {
		$page_templates = get_posts( array(
			'post_type'	 => 'elementor_library',
			'posts_per_page' => -1
		) );

		$options = array();

		if ( ! empty( $page_templates ) && ! is_wp_error( $page_templates ) ) {
			foreach ( $page_templates as $post ) {
				$options[ $post->ID ] = $post->post_title;
			}
		}
		return $options;
	}

}

/* vedanta-core read more button */
if ( ! function_exists( 'ved_post_readmore' ) ) {

	function ved_post_readmore() {
		?>
		<a href="<?php the_permalink() ?>" class="read-more btn btn-lg btn-link btn-base"><?php _e( 'Read more &raquo;', 'daydream' ) ?></a>
		<?php
	}

}

/* vedanta-core post metadata */
if ( ! function_exists( 'ved_post_metadata' ) ) {

	function ved_post_metadata( $settings ) {
		global $authordata;

		if ( $settings[ 'ved_post_block_meta_date' ] == 'yes' ) {
			?>
			<li class="published updated">
				<a href="<?php the_permalink() ?>"><?php the_time( get_option( 'date_format' ) ); ?></a>
			</li>
			<?php
		}

		if ( $settings[ 'ved_post_block_meta_author' ] == 'yes' ) {
			?>
			<li class="author vcard">
				<?php
				_e( 'By ', 'daydream' );

				if ( $settings[ 'ved_post_block_meta_avtar' ] == 'yes' ) {
					echo get_avatar( get_the_author_meta( 'email' ), '30' );
				}

				printf( '<a class="url fn" href="' . esc_url(get_author_posts_url( $authordata->ID, $authordata->user_nicename )) . '" title="' . sprintf( 'View all posts by %s', 'daydream', esc_attr($authordata->display_name) ) . '">' . get_the_author() . '</a>' )
				?>
			</li>
			<?php
		}

		if ( ved_get_terms( 'tags' ) && $settings[ 'ved_post_block_meta_tags' ] == 'yes' ) :
			?>
			<li class="meta-tags">
				<?php echo daydream_get_terms( 'tags' ); ?>
			</li>
			<?php
		endif;

		if ( comments_open() && $settings[ 'ved_post_block_meta_comments' ] == 'yes' ) :
			?>
			<li class="comment-count">
				<?php comments_popup_link( __( 'Leave a Comment', 'daydream' ), __( '1 Comment', 'daydream' ), __( '% Comments', 'daydream' ) ); ?>
			</li>
			<?php
		endif;
	}

}

if ( ! function_exists( 'ved_get_terms' ) ) {

	function ved_get_terms( $term = NULL, $glue = ', ' ) {
		if ( ! $term ) {
			return;
		}

		$separator = "\n";

		switch ( $term ):
			case 'cats':
				$current = single_cat_title( '', false );
				$terms	 = get_the_category_list( $separator );
				break;
			case 'tags':
				$current = single_tag_title( '', '', false );
				$terms	 = get_the_tag_list( '', "$separator", '' );
				break;
		endswitch;

		if ( empty( $terms ) ) {
			return;
		}

		$thing = explode( $separator, $terms );

		if ( empty( $thing ) ) {
			return false;
		}

		return trim( join( $glue, $thing ) );
	}

}