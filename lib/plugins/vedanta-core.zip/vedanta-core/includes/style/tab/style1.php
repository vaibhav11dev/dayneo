<?php
if ( is_array( $product_tab ) && count( $product_tab ) > 0 ):
    foreach ( $product_tab as $key => $tabs_content ):
        $product_filter = $tabs_content[ 'product_content' ];
        $active         = ($key == 0) ? 'active in' : '';
        $tabs_id        = 'ved-tabs-' . $key;
        ?>
        <div class="tab-pane fade <?php echo esc_attr( $active ) ?>" id="<?php echo esc_attr( $rand_id . $key ); ?>" role="tabpanel">
            <div class="ved-tab-single-product-slider">
            <?php
            switch ( $product_filter ) {
                case 'recent':
                    echo do_shortcode( "[recent_products per_page=\"$product_count\" columns=\"$columns\" ]" );
                    break;

                case 'featured':
                    echo do_shortcode( "[featured_products per_page=\"$product_count\" columns=\"$columns\" ]" );
                    break;

                case 'best_sell':
                    echo do_shortcode( "[best_selling_products per_page=\"$product_count\" columns=\"$columns\" ]" );
                    break;

                case 'on_sell':
                    echo do_shortcode( "[sale_products per_page=\"$product_count\" columns=\"$columns\" ]" );
                    break;

                case 'top_rate':
                    echo do_shortcode( "[top_rated_products per_page=\"$product_count\" columns=\"$columns\" ]" );
                    break;
            }
            ?>
            </div>
        </div>
        <?php
    endforeach;
                endif;