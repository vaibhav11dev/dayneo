<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function bigbo_admin_menu() {
	add_menu_page( esc_html__( 'About bigbo', 'vedanta' ), esc_html__( 'Bigbo', 'vedanta' ), 'manage_options', 'bigbo-menu', 'bigbo_welcome', VEDANTA_CORE_URL . '/admin/assets/images/admin-icon.png', 2 );
}

add_action( 'admin_menu', 'bigbo_admin_menu' );

function bigbo_admin_submenu() {
	if ( in_array( 'vedanta-core/vedanta-core.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		add_submenu_page( 'bigbo-menu', esc_html__( 'Install Demos', 'vedanta' ), esc_html__( 'Install Demos', 'vedanta' ), 'manage_options', 'bigbo_demos', 'bigbo_demo' );
	}

	add_submenu_page( 'bigbo-menu', esc_html__( 'Theme Options', 'vedanta' ), esc_html__( 'Theme Options', 'vedanta' ), 'manage_options', 'bigbo_options', 'bigbo_option' );

	global $submenu;
	$submenu[ 'bigbo-menu' ][ 0 ][ 0 ] = esc_html__( 'About bigbo', 'vedanta' );
}

add_action( 'admin_menu', 'bigbo_admin_submenu' );

function bigbo_welcome() {
        include_once( VEDANTA_CORE_PATH . 'admin/bigbo_menu/bigbo-welcome.php' );
}

function bigbo_demo() {
        include_once( VEDANTA_CORE_PATH . 'admin/bigbo_menu/bigbo-install_demo.php' );
}

function bigbo_option() {
        include_once( VEDANTA_CORE_PATH . 'admin/bigbo_menu/bigbo-options.php' );
}
