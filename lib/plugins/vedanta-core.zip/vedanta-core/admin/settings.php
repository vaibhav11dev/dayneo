<?php
/**
 * Admin Settings Page
 */
if ( ! defined( 'ABSPATH' ) )
    exit(); // Exit if accessed directly

class ved_Admin_Settings {

    /**
     * Contains Default Component keys
     * @var array
     * @since 1.0.0
     */
    public $ved_default_keys = [ 'modalbox', 'data-table', 'image-slider', 'slider-script', 'post-block', 'recent-work', 'team-members', 'testimonial-slider', 'testimonials', 'price-table', 'price-list', 'tooltip', 'adv-tabs', 'adv-accordion', 'adv-progressbar', 'piechart', 'slider', 'woo-product', 'woo-cat-slider', 'woo-product-tab' ];

    /**
     * Will Contain All Components Default Values
     * @var array
     * @since 1.0.0
     */
    private $ved_default_settings;

    /**
     * Will Contain User End Settings Value
     * @var array
     * @since 1.0.0
     */
    private $ved_settings;

    /**
     * Will Contains Settings Values Fetched From DB
     * @var array
     * @since 1.0.0
     */
    private $ved_get_settings;

    /**
     * Initializing all default hooks and functions
     * @param
     * @return void
     * @since 1.0.0
     */
    public function __construct() {

        add_action( 'admin_menu', array( $this, 'create_ved_admin_menu' ), 600 );
        add_action( 'init', array( $this, 'enqueue_ved_admin_scripts' ) );
        add_action( 'wp_ajax_save_settings_with_ajax', array( $this, 'ved_save_settings_with_ajax' ) );
    }

    /**
     * Loading all vedanta scripts
     * @param
     * @return void
     * @since 1.0.0
     */
    public function enqueue_ved_admin_scripts() {

        if ( isset( $_GET[ 'page' ] ) && ( $_GET[ 'page' ] == 'ved-settings' || $_GET[ 'page' ] == 'vedanta-addons-elementor-license' ) ) {
            wp_enqueue_style( 'vedanta_addons_elementor-admin-css', plugins_url( '/', __FILE__ ) . 'assets/css/admin.css' );
            wp_enqueue_style( 'font-awesome-css', plugins_url( '/', __FILE__ ) . 'assets/vendor/font-awesome/css/font-awesome.min.css' );
            // wp_enqueue_style( 'vedanta_addons_elementor-sweetalert2-css', plugins_url( '/', __FILE__ ).'assets/vendor/sweetalert2/css/sweetalert2.min.css' );
            wp_enqueue_script( 'vedanta_addons_elementor-admin-js', plugins_url( '/', __FILE__ ) . 'assets/js/admin.js', array( 'jquery', 'jquery-ui-tabs' ), '1.0', true );
            wp_enqueue_script( 'vedanta_addons_core-js', plugins_url( '/', __FILE__ ) . 'assets/vendor/sweetalert2/js/core.js', array( 'jquery' ), '1.0', true );
            wp_enqueue_script( 'vedanta_addons_sweetalert2-js', plugins_url( '/', __FILE__ ) . 'assets/vendor/sweetalert2/js/sweetalert2.min.js', array( 'jquery', 'vedanta_addons_core-js' ), '1.0', true );
        }
    }

    /**
     * Create an admin menu.
     * @param
     * @return void
     * @since 1.0.0
     */
    public function create_ved_admin_menu() {

        add_submenu_page(
        'bigbo-menu', 'Vedanta Addons', 'Vedanta Addons', 'manage_options', 'ved-settings', array( $this, 'ved_admin_settings_page' )
        );
    }

    /**
     * Create settings page.
     * @param
     * @return void
     * @since 1.0.0
     */
    public function ved_admin_settings_page() {

        $js_info = array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
        );
        wp_localize_script( 'vedanta_addons_elementor-admin-js', 'js_ved_pro_settings', $js_info );

        /**
         * This section will handle the "ved_save_settings" array. If any new settings options is added
         * then it will matches with the older array and then if it founds anything new then it will update the entire array.
         */
        $this->ved_default_settings = array_fill_keys( $this->ved_default_keys, true );
        $this->ved_get_settings     = get_option( 'ved_save_settings', $this->ved_default_settings );
        $ved_new_settings           = array_diff_key( $this->ved_default_settings, $this->ved_get_settings );
        if ( ! empty( $ved_new_settings ) ) {
            $ved_updated_settings = array_merge( $this->ved_get_settings, $ved_new_settings );
            update_option( 'ved_save_settings', $ved_updated_settings );
        }
        $this->ved_get_settings = get_option( 'ved_save_settings', $this->ved_default_settings );

        global $submenu;

        if (isset($submenu['bigbo-menu'])) {
            $menu_items = $submenu['bigbo-menu'];
        }

        if (is_array($menu_items)) {
            settings_errors();
        ?>
        <div class="about-wrap wrap">
        <div class="def-bg">
          <div class="container head-contain">        
            <div class="theme_content">
              <h1><?php esc_html_e('Welcome to Bigbo Theme', 'bigbo'); ?></h1>
              <?php $bigbo_theme = wp_get_theme(); ?>
                <p><?php printf(esc_html__('Version %s', 'bigbo'), $bigbo_theme->get('Version')); ?></p>
                <div class="wp-badge" style="background-image: url('<?php echo esc_url(get_template_directory_uri()); ?>/admin/assets/images/dark-logo.png');box-shadow: none;"></div>
            </div>
            <div class="nav-tab-wrapper">
                <?php
                foreach ($menu_items as $menu_item) {
                    ?>
                    <a href="?page=<?php echo esc_attr($menu_item[2]) ?>" class="nav-tab <?php
                       if (isset($_GET['page']) and $_GET['page'] == $menu_item[2]) {
                           echo 'nav-tab-active';
                       }
                       ?>"><?php echo esc_attr($menu_item[0]) ?></a>
                       <?php
                   }
                   ?>
                <span class="clear"></span>
            </div>
          </div>
        </div>
        </div>
        <?php
        }
        if ( ! empty( $this->parent->args['display_name'] ) ) { ?>        
        <?php } ?>
        <div class="ved-settings-wrap container">
            <div class="box">
            <form action="" method="POST" id="ved-settings" name="ved-settings">

                <div class="response-wrap"></div>

                <div id="elements" class="ved-settings-tab ved-elements-list">
                        <div class="col-full">
                            <!-- Content Element Starts -->
                            <h4>Content Elements</h4>
                            <div class="ved-checkbox-container">

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="team-members" name="team-members" <?php checked( 1, $this->ved_get_settings[ 'team-members' ], true ); ?> >
                                    <label for="team-members"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Team Member', 'vedanta' ) ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="tooltip" name="tooltip" <?php checked( 1, $this->ved_get_settings[ 'tooltip' ], true ); ?> >
                                    <label for="tooltip"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Tooltip', 'vedanta' ); ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="testimonial-slider" name="testimonial-slider" <?php checked( 1, $this->ved_get_settings[ 'testimonial-slider' ], true ); ?> >
                                    <label for="testimonial-slider"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Testimonial Slider', 'vedanta' ) ?></p>
                                </div>
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="testimonials" name="testimonials" <?php checked( 1, $this->ved_get_settings[ 'testimonials' ], true ); ?> >
                                    <label for="testimonials"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Testimonials', 'vedanta' ) ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="adv-tabs" name="adv-tabs" <?php checked( 1, $this->ved_get_settings[ 'adv-tabs' ], true ); ?> >
                                    <label for="adv-tabs"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Advanced Tabs', 'vedanta' ) ?></p>
                                </div>
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="adv-accordion" name="adv-accordion" <?php checked( 1, $this->ved_get_settings[ 'adv-accordion' ], true ); ?> >
                                    <label for="adv-accordion"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Advanced Accordion', 'vedanta' ) ?></p>
                                </div>
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="adv-progressbar" name="adv-progressbar" <?php checked( 1, $this->ved_get_settings[ 'adv-progressbar' ], true ); ?> >
                                    <label for="adv-progressbar"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Advanced Progress Bar', 'vedanta' ) ?></p>
                                </div>
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="piechart" name="piechart" <?php checked( 1, $this->ved_get_settings[ 'piechart' ], true ); ?> >
                                    <label for="piechart"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Piechart', 'vedanta' ) ?></p>
                                </div>
                            </div>
                            <!-- Content Element Ends -->
                            <!-- Dynamic Content Element Starts -->
                            <h4>Dynamic Content Elements</h4>
                            <div class="ved-checkbox-container">
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="post-block" name="post-block" <?php checked( 1, $this->ved_get_settings[ 'post-block' ], true ); ?> >
                                    <label for="post-block"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Post Block', 'vedanta' ); ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="recent-work" name="recent-work" <?php checked( 1, $this->ved_get_settings[ 'recent-work' ], true ); ?> >
                                    <label for="recent-work"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Recent Works', 'vedanta' ); ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="recent-work" name="slider" <?php checked( 1, $this->ved_get_settings[ 'slider' ], true ); ?> >
                                    <label for="slider"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Content Slider', 'vedanta' ); ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="data-table" name="data-table" <?php checked( 1, $this->ved_get_settings[ 'data-table' ], true ); ?> >
                                    <label for="data-table"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Data Table', 'vedanta' ) ?></p>
                                </div>
                            </div>
                            <!-- Dynamic Content Element Ends -->
                            <!-- Creative Element Starts -->
                            <h4>Creative Elements</h4>
                            <div class="ved-checkbox-container">
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="modalbox" name="modalbox" <?php checked( 1, $this->ved_get_settings[ 'modalbox' ], true ); ?> >
                                    <label for="modalbox"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Modalbox', 'vedanta' ); ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="image-slider" name="image-slider" <?php checked( 1, $this->ved_get_settings[ 'image-slider' ], true ); ?> >
                                    <label for="image-slider"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Image Slider', 'vedanta' ); ?></p>
                                </div>

                                <div class="ved-checkbox">
                                    <input type="checkbox" id="slider-script" name="slider-script" <?php checked( 1, $this->ved_get_settings[ 'slider-script' ], true ); ?> >
                                    <label for="slider-script"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Slider Script', 'vedanta' ); ?></p>
                                </div>
                            </div>
                            <!-- Creative Element Ends -->
                            <!-- Marketing Elements Starts -->
                            <h4>Marketing Elements</h4>
                            <div class="ved-checkbox-container">
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="price-table" name="price-table" <?php checked( 1, $this->ved_get_settings[ 'price-table' ], true ); ?> >
                                    <label for="price-table"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Pricing Table', 'vedanta' ) ?></p>
                                </div>
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="price-list" name="price-list" <?php checked( 1, $this->ved_get_settings[ 'price-list' ], true ); ?> >
                                    <label for="price-list"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Pricing List', 'vedanta' ) ?></p>
                                </div>
                            </div>
                            <!-- Marketing Elements Ends -->
                            <!-- WooCommerce Element Starts -->
                            <h4>WooCommerce Elements</h4>
                            <div class="ved-checkbox-container">
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="woo-product" name="woo-product" <?php checked( 1, $this->ved_get_settings[ 'woo-product' ], true ); ?> >
                                    <label for="woo-product"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Woo Product', 'vedanta' ) ?></p>
                                </div>
                                
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="woo-cat-slider" name="woo-cat-slider" <?php checked( 1, $this->ved_get_settings[ 'woo-cat-slider' ], true ); ?> >
                                    <label for="woo-cat-slider"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Woo Product Cat Slider', 'vedanta' ) ?></p>
                                </div>
                                
                                <div class="ved-checkbox">
                                    <input type="checkbox" id="woo-product-tab" name="woo-product-tab" <?php checked( 1, $this->ved_get_settings[ 'woo-product-tab' ], true ); ?> >
                                    <label for="woo-product-tab"></label>
                                    <p class="ved-el-title"><?php esc_html_e( 'Woo Product Tab', 'vedanta' ) ?></p>
                                </div>
                            </div>
                            <!-- WooCommerce Element Ends -->

                            <div class="ved-save-btn-wrap">
                                <input type="submit" value="Save settings" class="button ved-btn js-ved-settings-save"/>
                            </div>
                        </div>
                </div>

            </form>
            </div>
        </div>
        <?php
    }

    /**
     * Saving data with ajax request
     * @param
     * @return  array
     * @since 1.0.0
     */
    public function ved_save_settings_with_ajax() {

        if ( isset( $_POST[ 'fields' ] ) ) {
			parse_str( sanitize_text_field($_POST[ 'fields' ]), $settings );
        } else {
            return;
        }
        $this->ved_settings = array(
            'modalbox'           => intval( $settings[ 'modalbox' ] ? 1 : 0 ),
            'image-slider'       => intval( $settings[ 'image-slider' ] ? 1 : 0 ),
            'slider-script'      => intval( $settings[ 'slider-script' ] ? 1 : 0 ),
            'post-block'         => intval( $settings[ 'post-block' ] ? 1 : 0 ),
            'recent-work'        => intval( $settings[ 'recent-work' ] ? 1 : 0 ),
            'slider'           => intval( $settings[ 'slider' ] ? 1 : 0 ),
            'team-members'       => intval( $settings[ 'team-members' ] ? 1 : 0 ),
            'testimonial-slider' => intval( $settings[ 'testimonial-slider' ] ? 1 : 0 ),
            'testimonials'       => intval( $settings[ 'testimonials' ] ? 1 : 0 ),
            'price-table'        => intval( $settings[ 'price-table' ] ? 1 : 0 ),
            'price-list'         => intval( $settings[ 'price-list' ] ? 1 : 0 ),
            'data-table'         => intval( $settings[ 'data-table' ] ? 1 : 0 ),
            'tooltip'            => intval( $settings[ 'tooltip' ] ? 1 : 0 ),
            'adv-tabs'           => intval( $settings[ 'adv-tabs' ] ? 1 : 0 ),
            'adv-accordion'      => intval( $settings[ 'adv-accordion' ] ? 1 : 0 ),
            'adv-progressbar'    => intval( $settings[ 'adv-progressbar' ] ? 1 : 0 ),
            'piechart'           => intval( $settings[ 'piechart' ] ? 1 : 0 ),
            'woo-product'           => intval( $settings[ 'woo-product' ] ? 1 : 0 ),
            'woo-cat-slider'           => intval( $settings[ 'woo-cat-slider' ] ? 1 : 0 ),
            'woo-product-tab'           => intval( $settings[ 'woo-product-tab' ] ? 1 : 0 ),
        );
        update_option( 'ved_save_settings', $this->ved_settings );

        return true;
        die();
    }

}

new ved_Admin_Settings();
