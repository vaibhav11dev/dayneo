/**
 * ved Admin Script
 *
 * @since 1.0.0
 */

;
(function ($) {
	'use strict';
	/**
	 * ved Tabs
	 */
	$('.ved-tabs li a').on('click', function (e) {
		e.preventDefault();
		$('.ved-tabs li a').removeClass('active');
		$(this).addClass('active');
		var tab = $(this).attr('href');
		$('.ved-settings-tab').removeClass('active');
		$('.ved-settings-tabs').find(tab).addClass('active');
	});

	/**
	 * Save Button Reacting on Any Changes
	 */
	var headerSaveBtn = $('.ved-header-bar .ved-btn');
	var footerSaveBtn = $('.ved-save-btn-wrap .ved-btn');
	$('.ved-checkbox input[type="checkbox"]').on('click', function () {
		headerSaveBtn.addClass('save-now');
		footerSaveBtn.addClass('save-now');
	});

	/**
	 * Saving Data With Ajax Request
	 */
	$('.js-ved-settings-save').on('click', function (e) {
		e.preventDefault();
		ved_save_settings_with_ajax(js_ved_pro_settings, headerSaveBtn, footerSaveBtn);
	});

	/**
	 * Ajax Save
	 */
	function ved_save_settings_with_ajax(js_ved_pro_settings, headerSaveBtn, footerSaveBtn) {
		$.ajax({
			url: js_ved_pro_settings.ajaxurl,
			type: 'post',
			data: {
				action: 'save_settings_with_ajax',
				fields: $('form#ved-settings').serialize(),
			},
			success: function (response) {
				swal({
					title: 'Settings Saved!',
					test: 'Click OK to continue',
					type: 'success',
				});
				headerSaveBtn.removeClass('save-now');
				footerSaveBtn.removeClass('save-now');
			},
			error: function () {
				swal({
					title: 'Opps..',
					test: 'Something went wrong!',
					type: 'error',
				});
			}
		});
	}
})(jQuery);
