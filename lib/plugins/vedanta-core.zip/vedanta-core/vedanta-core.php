<?php
/**
 *
 * Plugin Name: Vedanta Core
 * Plugin URI: http://www.themevedanta.com
 * Description: Core functionality of ThemeVedanta Themes
 * Version: 1.0.0
 * Author: ThemeVedanta
 * Author URI: http://www.themevedanta.com
 *
 */
if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

// Define path to this plugin file
define( 'VEDANTA_CORE_URL', plugins_url( '/', __FILE__ ) );
define( 'VEDANTA_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'VEDANTA_CORE_ROOT', __FILE__ );
define( 'VEDANTA_VERSION', '1.0.0' );

require_once VEDANTA_CORE_PATH . 'includes/parsers.php';
require_once VEDANTA_CORE_PATH . 'includes/ved-slider.php';
require_once VEDANTA_CORE_PATH . 'includes/elementor-helper.php';
require_once VEDANTA_CORE_PATH . 'includes/queries.php';
require_once VEDANTA_CORE_PATH . 'admin/settings.php';

if ( ! class_exists( 'Vedanta_Core_Plugin' ) ) :

	/**
	 *
	 * Initialize ThemeVedanta Core
	 * @package ThemeVedanta Core
	 * @since    1.0.0
	 *
	 */
	class Vedanta_Core_Plugin {
	
		/**
		 *
		 * Unique identifier for your plugin.
		 *
		 *
		 * The variable name is used as the text domain when internationalizing strings
		 * of text. Its value should match the Text Domain file header in the main
		 * plugin file.
		 *
		 * @since    1.0.0
		 *
		 * @var      string
		 */
		protected $plugin_slug = 'vedanta-core';

		/**
		 * Initialize the plugin by setting localization and loading public scripts
		 * and styles.
		 *
		 * @since     1.0.0
		 */
		public function __construct() {
			add_action( 'init', array( $this, 'init' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'vedanta_addons_el_enqueue' ) );
			add_action( 'after_setup_theme', array( $this, 'load_ved_core_text_domain' ) );
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'add_ved_elements' ) );
		}

		public static function init() {
			global $evl_options;

			if ( ! isset( $evl_options[ 'evl_portfolio_slug' ] ) ) {
				$evl_options[ 'evl_portfolio_slug' ] = 'portfolio-items';
			}

			register_post_type(
			'daydream_portfolio', array(
				'labels'	 => array(
					'name'		 => 'Portfolio',
					'singular_name'	 => 'Portfolio'
				),
				'public'	 => true,
				'has_archive'	 => false,
				'rewrite'	 => array(
					'slug' => $evl_options[ 'evl_portfolio_slug' ]
				),
				'supports'	 => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', 'page-attributes' ),
				'can_export'	 => true,
			)
			);

			register_taxonomy( 'portfolio_category', 'daydream_portfolio', array( 'hierarchical' => true, 'label' => 'Categories', 'query_var' => true, 'rewrite' => true ) );

			register_taxonomy( 'portfolio_skills', 'daydream_portfolio', array( 'hierarchical' => true, 'label' => 'Skills', 'query_var' => true, 'rewrite' => true ) );

			register_taxonomy( 'portfolio_tags', 'daydream_portfolio', array( 'hierarchical' => false, 'label' => 'Tags', 'query_var' => true, 'rewrite' => true ) );
		}

		/**
		 * Load module's scripts and styles if any module is active.
		 *
		 * @since 1.0.0
		 */
		public static function vedanta_addons_el_enqueue() {
			$is_component_active = self::ved_activated_modules();

			wp_enqueue_style( 'vedanta_addons_elementor-slick-css', VEDANTA_CORE_URL . 'assets/slick/slick.css' );
			wp_enqueue_style( 'vedanta_addons_elementor-css', VEDANTA_CORE_URL . 'assets/css/vedanta-addons-elementor.css' );
			wp_enqueue_style( 'vedanta_addons_modalbox-css', VEDANTA_CORE_URL . 'assets/css/lity.min.css' );

			wp_enqueue_script( 'ved-scripts', VEDANTA_CORE_URL . 'assets/js/ved-scripts.js', array( 'jquery' ), '1.0', true );

			if ( $is_component_active[ 'modalbox' ] ) {
				wp_enqueue_script( 'vedanta_addons_elementor-modalbox-js', VEDANTA_CORE_URL . 'assets/js/lity.min.js', array( 'jquery' ), '1.0', true );
			}

			if ( $is_component_active[ 'testimonial-slider' ] ) {
				wp_enqueue_script( 'vedanta_addons_elementor-slick-js', VEDANTA_CORE_URL . 'assets/slick/slick.min.js', array( 'jquery' ), '1.0', true );
			}

			if ( $is_component_active[ 'data-table' ] ) {
				wp_enqueue_script( 'vedanta_addons_elementor-data-table-js', VEDANTA_CORE_URL . 'assets/js/jquery.tablesorter.min.js', array( 'jquery' ), '1.0', true );
			}
		}

		/**
		 * Register the plugin text domain
		 *
		 * @return void
		 */
		public static function load_ved_core_text_domain() {
			load_plugin_textdomain( 'vedanta', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

		/**
		 * Acivate or Deactivate Modules
		 *
		 * @since 1.0.0
		 */
		public static function add_ved_elements() {

			$is_component_active = self::ved_activated_modules();
			// load elements

			if ( $is_component_active[ 'post-block' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/post-block/post-block.php';
			}

			if ( $is_component_active[ 'recent-work' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/recent-work/recent-work.php';
			}

			if ( $is_component_active[ 'modalbox' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/modalbox/modalbox.php';
			}

			if ( $is_component_active[ 'team-members' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/team-members/team-members.php';
			}

			if ( $is_component_active[ 'testimonials' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/testimonials/testimonials.php';
			}

			if ( $is_component_active[ 'testimonial-slider' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/testimonial-slider/testimonial-slider.php';
			}

			if ( function_exists( 'WC' ) && $is_component_active[ 'product-grid' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/product-grid/product-grid.php';
			}

			if ( $is_component_active[ 'price-table' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/pricing-table/pricing-table.php';
			}

                        if ( $is_component_active[ 'price-list' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/pricing-list/pricing-list.php';
			}

                        if ( $is_component_active[ 'slider-script' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/slider-script/slider-script.php';
			}

			if ( $is_component_active[ 'image-slider' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/image-slider/image-slider.php';
			}

			if ( $is_component_active[ 'data-table' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/data-table/data-table.php';
			}

			if ( $is_component_active[ 'tooltip' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/tooltip/tooltip.php';
			}

			if ( $is_component_active[ 'adv-tabs' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/advance-tabs/advance-tabs.php';
			}

			if ( $is_component_active[ 'adv-accordion' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/advance-accordion/advance-accordion.php';
			}

			if ( $is_component_active[ 'adv-progressbar' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/advance-progressbar/advance-progressbar.php';
			}

			if ( $is_component_active[ 'piechart' ] ) {
				require_once VEDANTA_CORE_PATH . 'elements/piechart/piechart.php';
			}
		}

		/**
		 * This function will return true for all activated modules
		 *
		 * @since 1.0.0
		 */
		public static function ved_activated_modules() {

			$ved_default_keys = array( 'modalbox', 'image-slider', 'post-block', 'recent-work', 'product-grid', 'team-members', 'testimonial-slider', 'testimonials', 'price-table', 'data-table', 'tooltip', 'adv-tabs', 'adv-accordion', 'adv-progressbar', 'piechart' );

			$ved_default_settings	 = array_fill_keys( $ved_default_keys, true );
			$ved_get_settings	 = get_option( 'ved_save_settings', $ved_default_settings );
			$ved_new_settings	 = array_diff_key( $ved_default_settings, $ved_get_settings );

			if ( ! empty( $ved_new_settings ) ) {
				$ved_updated_settings = array_merge( $ved_get_settings, $ved_new_settings );
				update_option( 'ved_save_settings', $ved_updated_settings );
			}

			return $ved_get_settings = get_option( 'ved_save_settings', $ved_default_settings );
		}

	}

	$vedanta_core_plugin = new Vedanta_Core_Plugin();
endif;

add_action( 'plugins_loaded', 'ved_elementor_addons' );

function ved_elementor_addons() {
	if ( class_exists( 'Caldera_Forms' ) ) {
		add_filter( 'caldera_forms_force_enqueue_styles_early', '__return_true' );
	}
	/**
	 * Check if Elementor is Installed or not
	 */
	if ( ! function_exists( 'ved_is_elementor_active' ) ) :

		function ved_is_elementor_active() {
			$file_path		 = 'elementor/elementor.php';
			$installed_plugins	 = get_plugins();
			return isset( $installed_plugins[ $file_path ] );
		}

	endif;

	/**
	 * This notice will appear if Elementor is not installed or activated or both
	 */
	function ved_is_failed_to_load() {
		$elementor = 'elementor/elementor.php';
		if ( ved_is_elementor_active() ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			$activation_url	 = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $elementor . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $elementor );
			$message	 = __( '<strong>Vedanta Core</strong> requires Elementor plugin to be active. Please activate Elementor to continue.', 'vedanta' );
			$button_text	 = __( 'Activate Elementor', 'vedanta' );
		} else {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			$activation_url	 = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
			$message	 = sprintf( __( '<strong>Vedanta Core</strong> requires %1$s"Elementor"%2$s plugin to be installed and activated. Please install Elementor to continue.', 'vedanta' ), '<strong>', '</strong>' );
			$button_text	 = __( 'Install Elementor', 'vedanta' );
		}
		$button = '<p><a href="' . esc_url($activation_url) . '" class="button-primary">' . esc_html($button_text) . '</a></p>';
		printf( '<div class="error"><p>%1$s</p>%2$s</div>', esc_html( $message ), $button );
	}

	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'ved_is_failed_to_load' );
	}
}
